package com.des.xarvoth;

import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Per-player, per-ability cooldowns. Stored as epoch millis and persisted on the player so relogging never resets them. */
public final class CooldownManager {
    private final Map<UUID, Map<String, Long>> until = new HashMap<>();
    private final NamespacedKey key;

    public CooldownManager(XarvothPlugin plugin) { this.key = new NamespacedKey(plugin, "cooldowns"); }

    public long remainingMs(UUID u, String id) {
        Map<String, Long> m = until.get(u);
        if (m == null) return 0;
        Long t = m.get(id);
        return t == null ? 0 : Math.max(0, t - System.currentTimeMillis());
    }

    public void start(UUID u, String id, long ms) {
        until.computeIfAbsent(u, k -> new HashMap<>()).put(id, System.currentTimeMillis() + ms);
    }

    public void reset(UUID u) { until.remove(u); }

    public void load(Player p) {
        Map<String, Long> m = new HashMap<>();
        String raw = p.getPersistentDataContainer().get(key, PersistentDataType.STRING);
        long now = System.currentTimeMillis();
        if (raw != null && !raw.isEmpty()) {
            for (String part : raw.split(";")) {
                int i = part.indexOf('=');
                if (i <= 0) continue;
                try {
                    long t = Long.parseLong(part.substring(i + 1));
                    if (t > now) m.put(part.substring(0, i), t);
                } catch (NumberFormatException ignored) { }
            }
        }
        until.put(p.getUniqueId(), m);
    }

    public void save(Player p) {
        Map<String, Long> m = until.get(p.getUniqueId());
        long now = System.currentTimeMillis();
        StringBuilder sb = new StringBuilder();
        if (m != null) {
            for (Map.Entry<String, Long> e : m.entrySet()) {
                if (e.getValue() > now) sb.append(e.getKey()).append('=').append(e.getValue()).append(';');
            }
        }
        if (sb.length() == 0) p.getPersistentDataContainer().remove(key);
        else p.getPersistentDataContainer().set(key, PersistentDataType.STRING, sb.toString());
    }
}

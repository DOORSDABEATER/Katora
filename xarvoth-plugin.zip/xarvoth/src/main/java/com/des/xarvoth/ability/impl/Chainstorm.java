package com.des.xarvoth.ability.impl;

import com.des.xarvoth.RavageMeter;
import com.des.xarvoth.XarvothPlugin;
import com.des.xarvoth.ability.AbilityCategory;
import com.des.xarvoth.ability.AbilityContext;
import com.des.xarvoth.blade.BladeId;
import com.des.xarvoth.blade.ChainStrand;
import com.des.xarvoth.blade.PlayerSession;
import com.des.xarvoth.blade.Script;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * CHAIN 5 - CHAINSTORM. Six chains whip around the wielder in a widening, breathing pattern. The tips hit on contact and the
 * chain bodies sweep a wide ring; every target has a fixed hit interval and a hard cap on total hits, and knocks outward so
 * the wielder is not stuck in a stun-lock of their own making.
 */
public final class Chainstorm extends BaseAbility {
    private static final int N = 6;

    public Chainstorm(XarvothPlugin plugin) { super(plugin, "chainstorm", "CHAINSTORM", AbilityCategory.CHAIN); }

    @Override
    protected String start(AbilityContext ctx) {
        Player p = ctx.owner();
        PlayerSession s = ctx.session();
        World w = p.getWorld();
        int dur = ctx.cfgI("duration-ticks", 50);
        int interval = ctx.cfgI("hit-interval", 6);
        int maxHits = ctx.cfgI("max-hits-per-target", 6);
        double dmg = ctx.baseDamage(2.6);

        int[] tk = {0};
        Map<UUID, Integer> next = new HashMap<>();
        Map<UUID, Integer> count = new HashMap<>();
        List<ChainStrand> strands = new ArrayList<>();
        Script sc = new Script().exclusive(true);
        sc.run(() -> {
            for (int k = 0; k < N; k++) {
                final int kk = k;
                BladeId hand = k % 2 == 0 ? BladeId.VORTH : BladeId.ZYRATH;
                strands.add(sc.own(s.strand(() -> s.handAnchor(hand), () -> tip(p, kk, tk[0]), 1.08, dur + 10, 6)));
            }
            plugin.fx().sound(w, p.getLocation().toVector(), "storm_start", "xarvoth:storm.start", 1.4f, 1.0f);
        });
        sc.during(dur, i -> {
            tk[0] = i;
            for (int k = 0; k < N; k++) {
                Vector tp = tip(p, k, i);
                plugin.fx().dust(w, tp, 1, 0.05, 1.3f, plugin.fx().energy(p));
                for (LivingEntity e : w.getNearbyLivingEntities(new Location(w, tp.getX(), tp.getY(), tp.getZ()), 1.5)) hitOnce(ctx, e, tp, dmg, i, interval, maxHits, next, count);
            }
            if (i % 4 == 0) {
                for (ChainStrand st : strands) for (LivingEntity e : st.sweep(0.8)) hitOnce(ctx, e, p.getLocation().toVector(), dmg * 0.7, i, interval, maxHits, next, count);
            }
        });
        return Kit.begin(ctx, sc);
    }

    private void hitOnce(AbilityContext ctx, LivingEntity e, Vector from, double dmg, int tick, int interval, int maxHits,
                         Map<UUID, Integer> next, Map<UUID, Integer> count) {
        Player p = ctx.owner();
        if (!plugin.damage().canTarget(p, e)) return;
        UUID id = e.getUniqueId();
        if (count.getOrDefault(id, 0) >= maxHits || tick < next.getOrDefault(id, 0)) return;
        next.put(id, tick + interval);
        if (ctx.hit(null, e, dmg, RavageMeter.Source.CHAIN_HIT, Kit.kb(p.getLocation().toVector(), e.getLocation().toVector(), 0.7, 0.25))) {
            count.merge(id, 1, Integer::sum);
            plugin.fx().spark(p.getWorld(), Kit.center(e), 8, 0.25);
            plugin.fx().sound(p.getWorld(), Kit.center(e), "chain_hit", "xarvoth:chain.hit", 0.8f, 1.0f);
        }
    }

    private Vector tip(Player p, int k, int t) {
        double ang = t * 0.32 + k * (Math.PI * 2 / N);
        double r = 3.2 + 3.0 * (0.5 + 0.5 * Math.sin(t * 0.12 + k));
        double h = 0.8 + 0.9 * Math.sin(t * 0.25 + k * 1.3);
        return p.getLocation().toVector().add(new Vector(Math.cos(ang) * r, h, Math.sin(ang) * r));
    }
}

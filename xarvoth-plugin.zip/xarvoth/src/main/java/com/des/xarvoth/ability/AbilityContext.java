package com.des.xarvoth.ability;

import com.des.xarvoth.ComboTracker;
import com.des.xarvoth.RavageMeter;
import com.des.xarvoth.XarvothPlugin;
import com.des.xarvoth.blade.BladeId;
import com.des.xarvoth.blade.PlayerSession;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Everything one activation needs. All damage an ability deals goes through {@link #hit}, which is where
 * the meter rules (blade/chain hit, combo flow, aerial, coordinated two-blade hit) are applied exactly once per target.
 */
public final class AbilityContext {
    private final XarvothPlugin plugin;
    private final Player owner;
    private final Ability ability;
    private final PlayerSession session;
    private final ComboTracker.Flow flow;

    private final Set<UUID> flowPaid = new HashSet<>();
    private final Set<UUID> aerialPaid = new HashSet<>();
    private final Set<UUID> coordinatedPaid = new HashSet<>();
    private final Map<UUID, EnumSet<BladeId>> bladesOnVictim = new HashMap<>();

    public AbilityContext(XarvothPlugin plugin, Player owner, Ability ability, PlayerSession session, ComboTracker.Flow flow) {
        this.plugin = plugin;
        this.owner = owner;
        this.ability = ability;
        this.session = session;
        this.flow = flow;
    }

    public XarvothPlugin plugin() { return plugin; }
    public Player owner() { return owner; }
    public Ability ability() { return ability; }
    public PlayerSession session() { return session; }
    public ComboTracker.Flow flow() { return flow; }

    public double cfgD(String key, double def) { return plugin.cfg().ad(ability.id(), key, def); }
    public int cfgI(String key, int def) { return plugin.cfg().ai(ability.id(), key, def); }

    /** Configured base damage for this ability with the combo-flow bonus applied. */
    public double baseDamage(double def) { return cfgD("damage", def) * flow.multiplier(); }

    /** The one way an ability hurts something. Returns true if damage landed. */
    public boolean hit(BladeId blade, LivingEntity victim, double damage, RavageMeter.Source src, Vector knockback) {
        if (!plugin.damage().damage(owner, victim, damage, knockback)) return false;
        RavageMeter m = plugin.meter();
        UUID id = victim.getUniqueId();
        m.gain(owner, victim, src);
        if (flow.links() > 0 && flowPaid.add(id)) m.gain(owner, victim, RavageMeter.Source.COMBO);
        if (!victim.isOnGround() && aerialPaid.add(id)) m.gain(owner, victim, RavageMeter.Source.AERIAL);
        if (blade != null) {
            EnumSet<BladeId> set = bladesOnVictim.computeIfAbsent(id, k -> EnumSet.noneOf(BladeId.class));
            set.add(blade);
            if (set.size() > 1 && coordinatedPaid.add(id)) m.gain(owner, victim, RavageMeter.Source.COORDINATED);
        }
        return true;
    }

    public void gain(RavageMeter.Source src, LivingEntity victim) { plugin.meter().gain(owner, victim, src); }
}

package com.des.xarvoth;

import com.des.xarvoth.blade.BladeId;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

/**
 * Everything visual about XARVOTH is an item_model (not custom_model_data), so the resource pack never has to
 * override a vanilla item definition and merging into the DeS pack cannot collide.
 * Empowered variants are the same key plus item.empowered-suffix.
 */
public final class Models {
    private Models() {}

    private static NamespacedKey key(XarvothPlugin p, String path, String def, boolean empowered) {
        String suffix = p.cfg().s("item.empowered-suffix", "_empowered");
        String base = p.cfg().s(path, def);
        NamespacedKey k = NamespacedKey.fromString(empowered ? base + suffix : base);
        if (k == null) k = NamespacedKey.fromString(empowered ? def + suffix : def);
        return k;
    }

    private static Material mat(XarvothPlugin p, String path, Material def) {
        Material m = Material.matchMaterial(p.cfg().s(path, def.name()));
        return m == null ? def : m;
    }

    public static NamespacedKey weaponKey(XarvothPlugin p, boolean empowered) {
        return key(p, "item.model", "xarvoth:weapon", empowered);
    }

    public static ItemStack blade(XarvothPlugin p, BladeId id, boolean empowered) {
        ItemStack it = new ItemStack(mat(p, "item.blade-material", Material.NETHERITE_SWORD));
        ItemMeta m = it.getItemMeta();
        m.setItemModel(key(p, "item." + id.key + "-model", "xarvoth:" + id.key, empowered));
        it.setItemMeta(m);
        return it;
    }

    public static ItemStack chain(XarvothPlugin p, boolean empowered) {
        ItemStack it = new ItemStack(mat(p, "item.chain-material", Material.CHAIN));
        ItemMeta m = it.getItemMeta();
        m.setItemModel(key(p, "item.chain-model", "xarvoth:chain_link", empowered));
        it.setItemMeta(m);
        return it;
    }

    /** One frame of a model-based VFX (see tools/vfx_pack.py). */
    public static ItemStack vfx(XarvothPlugin p, String name, boolean empowered) {
        ItemStack it = new ItemStack(mat(p, "item.blade-material", Material.NETHERITE_SWORD));
        ItemMeta m = it.getItemMeta();
        String suffix = empowered ? p.cfg().s("item.empowered-suffix", "_empowered") : "";
        NamespacedKey k = NamespacedKey.fromString("xarvoth:" + name + suffix);
        if (k != null) m.setItemModel(k);
        it.setItemMeta(m);
        return it;
    }
}

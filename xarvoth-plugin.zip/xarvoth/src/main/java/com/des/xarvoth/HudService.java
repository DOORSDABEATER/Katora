package com.des.xarvoth;

import com.des.xarvoth.ability.Ability;
import com.des.xarvoth.blade.PlayerSession;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Player feedback. Action bar: selected authority + ability + READY / cooldown. Boss bar: RAVAGE ENCHANTMENT percentage,
 * READY prompt, then the draining empowerment timer. Only wielders currently holding XARVOTH see either.
 * flash() shows a message on the action bar and holds it for a moment before the normal line comes back.
 */
public final class HudService {
    private final XarvothPlugin plugin;
    private final Map<UUID, BossBar> bars = new HashMap<>();
    private final Map<UUID, Long> holdUntil = new HashMap<>();
    private BukkitTask task;

    public HudService(XarvothPlugin plugin) { this.plugin = plugin; }

    public void start() { task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 5L, 4L); }

    public void shutdown() {
        if (task != null) task.cancel();
        for (Player p : Bukkit.getOnlinePlayers()) hide(p);
        bars.clear();
    }

    public void flash(Player p, String legacy, long ms) {
        if (!plugin.cfg().b("hud.actionbar", true)) return;
        holdUntil.put(p.getUniqueId(), System.currentTimeMillis() + ms);
        p.sendActionBar(Text.c(legacy));
    }

    private void tick() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (plugin.meter().pollEnded(p)) {
                flash(p, "&7RAVAGE ENCHANTMENT has faded.", 2000);
                plugin.fx().tell(p, "ravage_end", "minecraft:block.beacon.deactivate", 1.0f, 1.0f);
            }
        }
        for (PlayerSession s : plugin.blades().sessions()) {
            Player p = s.owner();
            if (!s.isHolding()) { hide(p); continue; }
            if (plugin.cfg().b("hud.actionbar", true)) {
                Long until = holdUntil.get(p.getUniqueId());
                if (until == null || until < System.currentTimeMillis()) p.sendActionBar(line(p));
            }
            if (plugin.cfg().b("hud.bossbar", true)) updateBar(p);
        }
    }

    private static final net.kyori.adventure.key.Key FONT = net.kyori.adventure.key.Key.key("xarvoth", "hud");

    private static Component glyph(char c) {
        return Component.text(String.valueOf(c)).font(FONT).color(net.kyori.adventure.text.format.NamedTextColor.WHITE);
    }

    private static char categoryGlyph(com.des.xarvoth.ability.AbilityCategory c) {
        return (char) (0xE000 + c.ordinal());
    }

    /** Ten meter cells, each one of five fill states, built from the resource pack's HUD font. */
    private Component meterGlyphs(Player p) {
        double pct = plugin.meter().displayFraction(p) * 100.0;
        Component bar = Component.empty();
        for (int i = 0; i < 10; i++) {
            double cell = Math.max(0.0, Math.min(10.0, pct - i * 10.0)) / 10.0;
            bar = bar.append(glyph((char) (0xE010 + (int) Math.round(cell * 4))));
        }
        return bar;
    }

    private Component line(Player p) {
        Ability a = plugin.selection().selected(p);
        if (a == null) return Text.c("&7No abilities installed");
        long cd = plugin.cooldowns().remainingMs(p.getUniqueId(), a.id());
        String state = cd > 0 ? "&c" + String.format(Locale.ROOT, "%.1fs", cd / 1000.0) : "&aREADY";
        if (!plugin.cfg().b("hud.glyphs", true)) return Text.c("&8[&b" + a.category().label() + "&8] &f" + a.displayName() + " " + state);
        RavageMeter m = plugin.meter();
        String tail = m.isEmpowered(p)
                ? " &f\u26A1 " + String.format(Locale.ROOT, "%.0fs", m.remainingMs(p) / 1000.0)
                : (m.isReady(p) ? " &aREADY" : " &7" + (int) m.value(p) + "%");
        return glyph(categoryGlyph(a.category())).append(Text.c(" &f" + a.displayName() + " " + state + "  ")).append(meterGlyphs(p)).append(Text.c(tail));
    }

    private void updateBar(Player p) {
        RavageMeter m = plugin.meter();
        boolean emp = m.isEmpowered(p);
        String title;
        if (emp) {
            title = "&f&l\u26A1 RAVAGE ENCHANTMENT &b" + String.format(Locale.ROOT, "%.1fs", m.remainingMs(p) / 1000.0);
        } else {
            title = "&bRAVAGE ENCHANTMENT &f" + (int) m.value(p) + "%" + (m.isReady(p) ? " &a- READY &7(Sneak + F)" : "");
        }
        BossBar bar = bars.get(p.getUniqueId());
        if (bar == null) {
            bar = BossBar.bossBar(Text.c(title), (float) m.displayFraction(p), BossBar.Color.BLUE, BossBar.Overlay.NOTCHED_10);
            bars.put(p.getUniqueId(), bar);
            p.showBossBar(bar);
        }
        bar.name(Text.c(title));
        bar.progress((float) Math.max(0.0, Math.min(1.0, m.displayFraction(p))));
        bar.color(emp ? BossBar.Color.WHITE : BossBar.Color.BLUE);
    }

    public void hide(Player p) {
        BossBar bar = bars.remove(p.getUniqueId());
        if (bar != null) p.hideBossBar(bar);
        holdUntil.remove(p.getUniqueId());
    }

    public void forget(UUID id) {
        bars.remove(id);
        holdUntil.remove(id);
    }
}

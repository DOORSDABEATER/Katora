package com.des.xarvoth.blade;

import com.des.xarvoth.XarvothPlugin;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

/**
 * Something an ability keeps running for a while (a prison, a storm, a scripted ultimate).
 * The session ticks it, caps how many run at once, and ALWAYS calls onCancel if the wielder is interrupted,
 * dies, logs out, changes world or drops the weapon, so strands and restraints can never leak.
 */
public abstract class Effect {
    protected PlayerSession session;
    protected int age;

    void bind(PlayerSession s) { this.session = s; }

    protected XarvothPlugin plugin() { return session.plugin(); }
    protected Player owner() { return session.owner(); }

    /** Exclusive effects (ultimates, big channels) block the wielder from starting other abilities. */
    public boolean exclusive() { return false; }

    public void onStart() {}

    /** @return true when finished. */
    public abstract boolean tick(int age);

    public void onFinish() {}
    public void onCancel() {}

    /** The wielder just landed damage on {@code victim} (amount before armor). */
    public void onHit(LivingEntity victim, double amount) {}

    /** Damage is about to hit the wielder. Return true if this effect consumed (cancelled) it. */
    public boolean onIncoming(EntityDamageByEntityEvent e) { return false; }
}

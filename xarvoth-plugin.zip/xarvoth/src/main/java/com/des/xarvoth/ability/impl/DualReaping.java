package com.des.xarvoth.ability.impl;

import com.des.xarvoth.XarvothPlugin;
import com.des.xarvoth.ability.AbilityCategory;
import com.des.xarvoth.ability.AbilityContext;
import com.des.xarvoth.blade.Barrier;
import com.des.xarvoth.blade.BladeId;
import com.des.xarvoth.blade.BladeUnit;
import com.des.xarvoth.blade.Hitbook;
import com.des.xarvoth.blade.Motions;
import com.des.xarvoth.blade.PlayerSession;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.function.Supplier;

/**
 * BLADE 3 - DUAL REAPING. Both blades swing in from opposite sides of the target, then cut straight through it along
 * crossing lines so their paths form an X on the target. Each blade has its own hit list; when both have passed, a short
 * crossing burst finishes the pattern.
 */
public final class DualReaping extends BaseAbility {
    public DualReaping(XarvothPlugin plugin) { super(plugin, "dual_reaping", "DUAL REAPING", AbilityCategory.BLADE); }

    @Override
    protected String start(AbilityContext ctx) {
        Player p = ctx.owner();
        PlayerSession s = ctx.session();
        String busy = Kit.requireIdle(s, BladeId.VORTH, BladeId.ZYRATH);
        if (busy != null) return busy;
        LivingEntity t = Kit.targetEntity(ctx, ctx.cfgD("range", 16.0));
        if (t == null) return "No target in range.";

        Vector c0 = Kit.center(t);
        Vector toT = c0.clone().subtract(p.getLocation().toVector()).setY(0);
        Vector axis = toT.lengthSquared() > 1e-4 ? new Vector(toT.getZ(), 0, -toT.getX()).normalize() : s.right();
        double dmg = ctx.baseDamage(9.0);
        int limit = ctx.cfgI("target-limit", 5);
        Supplier<Vector> tc = () -> Kit.alive(t) ? Kit.center(t) : c0.clone();
        Barrier finisher = new Barrier(2, () -> burst(ctx, tc.get(), axis));

        for (BladeId id : BladeId.values()) {
            BladeUnit u = s.unit(id);
            double sg = id.side;
            Hitbook book = new Hitbook();
            u.queue(new Motions.Arc(() -> tc.get().add(axis.clone().multiply(3.4 * sg)).add(new Vector(0, 0.9, 0)),
                    axis.clone().multiply(4.0 * sg).add(new Vector(0, 2.0, 0)), 9, Motions.Easing.OUT));
            u.queue(new Motions.Arc(() -> tc.get().add(axis.clone().multiply(-3.4 * sg)).add(new Vector(0, 0.1, 0)),
                    new Vector(0, 0.6, 0), 6, Motions.Easing.IN)
                    .stopOnBlock()
                    .hook(Kit.cut(ctx, id, book, dmg, limit, 1.3))
                    .then(finisher::arrive));
        }
        plugin.fx().sound(p.getWorld(), p.getLocation().toVector(), "reap_launch", "xarvoth:reap.launch", 1.2f, 1.0f);
        return null;
    }

    private void burst(AbilityContext ctx, Vector c, Vector axis) {
        Player p = ctx.owner();
        if (!p.isOnline()) return;
        Kit.impact(ctx, BladeId.VORTH, c, 3.0, ctx.baseDamage(9.0) * 0.5, 6, 0.6, 0.3);
        var fx = plugin.fx();
        var col = fx.energy(p);
        Vector a = axis.clone().add(new Vector(0, 0.7, 0));
        Vector b = axis.clone().add(new Vector(0, -0.7, 0));
        fx.slash(p.getWorld(), c, a, 4.5, col);
        fx.slash(p.getWorld(), c, b, 4.5, col);
        fx.spark(p.getWorld(), c, 25, 0.6);
        fx.sound(p.getWorld(), c, "reap_cross", "xarvoth:reap.cross", 1.3f, 1.0f);
    }
}

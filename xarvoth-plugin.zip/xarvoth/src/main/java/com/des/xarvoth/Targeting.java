package com.des.xarvoth;

import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

public final class Targeting {
    private Targeting() {}

    /** What the wielder is aiming at. {@code entity} is null when it is a block / point. */
    public record Aim(Vector point, LivingEntity entity) {}

    public static Aim aim(Player p, double range) {
        Location eye = p.getEyeLocation();
        RayTraceResult r = p.getWorld().rayTrace(eye, eye.getDirection(), range, FluidCollisionMode.NEVER, true, 0.35,
                e -> e instanceof LivingEntity le && !e.equals(p) && !le.isDead()
                        && !(e instanceof Player pl && pl.getGameMode() == GameMode.SPECTATOR));
        if (r == null) return null;
        if (r.getHitEntity() instanceof LivingEntity le) return new Aim(le.getBoundingBox().getCenter(), le);
        if (r.getHitPosition() != null) return new Aim(r.getHitPosition(), null);
        return null;
    }

    public static boolean blockedBetween(World w, Vector a, Vector b) {
        Vector d = b.clone().subtract(a);
        double len = d.length();
        if (len < 1e-4) return false;
        return w.rayTraceBlocks(new Location(w, a.getX(), a.getY(), a.getZ()), d.multiply(1.0 / len), len, FluidCollisionMode.NEVER, true) != null;
    }
}

package com.des.xarvoth.ability.impl;

import com.des.xarvoth.RavageMeter;
import com.des.xarvoth.Targeting;
import com.des.xarvoth.XarvothPlugin;
import com.des.xarvoth.ability.AbilityCategory;
import com.des.xarvoth.ability.AbilityContext;
import com.des.xarvoth.blade.BladeId;
import com.des.xarvoth.blade.BladeUnit;
import com.des.xarvoth.blade.Hitbook;
import com.des.xarvoth.blade.Motions;
import com.des.xarvoth.blade.PlayerSession;
import com.des.xarvoth.blade.Script;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;

/**
 * CONVERGENCE 7 - SOVEREIGN'S CAGE. Where Iron Prison is a static chain cage, this one is alive: both blades orbit the rim in
 * opposite directions at full speed, tethered to four ground posts by chain, cutting everything that comes near the wall.
 * Enemies inside are confined to the ring (RestraintService grants the time) and thrown back in whenever they touch the rim.
 */
public final class SovereignsCage extends BaseAbility {
    public SovereignsCage(XarvothPlugin plugin) { super(plugin, "sovereigns_cage", "SOVEREIGN'S CAGE", AbilityCategory.CONVERGENCE); }

    @Override
    protected String start(AbilityContext ctx) {
        Player p = ctx.owner();
        PlayerSession s = ctx.session();
        String busy = Kit.requireIdle(s, BladeId.VORTH, BladeId.ZYRATH);
        if (busy != null) return busy;
        World w = p.getWorld();
        double range = Math.min(ctx.cfgD("range", 16.0), plugin.cfg().d("chain.max-length", 24.0) - 8.0);
        Targeting.Aim aim = Targeting.aim(p, range);
        Vector c = aim != null && aim.entity() != null ? Kit.ground(w, aim.entity().getLocation().toVector()) : Kit.aimGround(ctx, range);
        double r = ctx.cfgD("radius", 4.5);
        int dur = Math.min(ctx.cfgI("duration-ticks", 50), plugin.cfg().i("restraint.max-ticks", 60));

        List<LivingEntity> held = new ArrayList<>();
        for (LivingEntity e : Kit.around(ctx, c, r + 1.5, ctx.cfgI("target-limit", 6), false)) {
            if (plugin.restraints().grant(e, dur, false) > 0) held.add(e);
        }
        if (held.isEmpty()) return "Nothing to cage.";

        BladeUnit v = s.unit(BladeId.VORTH);
        BladeUnit z = s.unit(BladeId.ZYRATH);
        double dmg = ctx.baseDamage(4.0);

        Script sc = new Script().exclusive(true);
        sc.run(() -> {
            for (BladeId id : BladeId.values()) {
                double a0 = id == BladeId.VORTH ? 0 : Math.PI;
                s.unit(id).queue(new Motions.Arc(() -> c.clone().add(new Vector(Math.cos(a0) * r, 1.4, Math.sin(a0) * r)), Kit.ZERO.clone(), 8, Motions.Easing.OUT));
            }
            plugin.fx().rune(p, w, c, r + 0.5, dur + 14);
            plugin.fx().sound(w, c, "cage_start", "xarvoth:cage.start", 1.4f, 1.0f);
        });
        sc.waitIdle(v, z);
        sc.run(() -> {
            for (int seg = 0; seg < dur / 10; seg++) {
                final int off = seg * 10;
                for (BladeId id : BladeId.values()) {
                    double a0 = id == BladeId.VORTH ? 0 : Math.PI;
                    double dir = id == BladeId.VORTH ? 1 : -1;
                    s.unit(id).queue(new Motions.Path(i -> {
                        double a = a0 + (off + i) * 0.34 * dir;
                        return c.clone().add(new Vector(Math.cos(a) * r, 1.4 + Math.sin((off + i) * 0.5) * 0.5, Math.sin(a) * r));
                    }, 10, 0.6).hook(Kit.cut(ctx, id, new Hitbook(), dmg, 6, 1.4)));
                }
            }
            for (BladeUnit u : new BladeUnit[]{v, z}) {
                for (int k = 0; k < 4; k++) {
                    double a = Math.PI * 2 * (k + (u == v ? 0 : 0.5)) / 4;
                    Vector post = Kit.ground(w, c.clone().add(new Vector(Math.cos(a) * (r + 1.0), 0, Math.sin(a) * (r + 1.0))));
                    sc.own(s.strand(() -> u.pos.clone(), () -> post, 1.05, dur + 40, 4));
                }
            }
        });
        sc.during(dur, i -> {
            if (i % 5 == 0) plugin.fx().ring(w, c, r, 36, plugin.fx().energy(p));
            for (LivingEntity e : held) {
                if (!Kit.alive(e)) continue;
                Kit.confine(e, c.clone().add(new Vector(0, 1.0, 0)), r - 0.3);
                double horiz = e.getLocation().toVector().subtract(c).setY(0).length();
                if (i % 10 == 9 && horiz > r - 1.0) {
                    ctx.hit(null, e, dmg * 0.7, RavageMeter.Source.CHAIN_HIT, Kit.kb(e.getLocation().toVector(), c, 0.6, 0.2));
                    plugin.fx().spark(w, Kit.center(e), 10, 0.3);
                }
            }
        });
        sc.waitIdle(v, z);
        sc.run(() -> {
            plugin.fx().shockwave(w, c, r, plugin.fx().energy(p));
            plugin.fx().sound(w, c, "cage_end", "xarvoth:cage.end", 1.4f, 1.0f);
        });
        sc.onEnd(() -> { v.clearMotions(); z.clearMotions(); });
        return Kit.begin(ctx, sc);
    }
}

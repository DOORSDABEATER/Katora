package com.des.xarvoth.ability.impl;

import com.des.xarvoth.RavageMeter;
import com.des.xarvoth.XarvothPlugin;
import com.des.xarvoth.ability.AbilityCategory;
import com.des.xarvoth.ability.AbilityContext;
import com.des.xarvoth.blade.BladeId;
import com.des.xarvoth.blade.BladeUnit;
import com.des.xarvoth.blade.Motions;
import com.des.xarvoth.blade.PlayerSession;
import com.des.xarvoth.blade.Script;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.Comparator;
import java.util.List;

/**
 * CONVERGENCE 10 - EXECUTION PROTOCOL. The wielder's chains scan everything visible and lock onto the three weakest (lowest health
 * fraction first), binding each briefly. Then one by one: ZYRATH opens the target, VORTH drops the execution. Damage scales with how
 * hurt the target is; each confirmed kill makes the next strike 25% harder and feeds the meter as a combo.
 */
public final class ExecutionProtocol extends BaseAbility {
    public ExecutionProtocol(XarvothPlugin plugin) { super(plugin, "execution_protocol", "EXECUTION PROTOCOL", AbilityCategory.CONVERGENCE); }

    @Override
    protected String start(AbilityContext ctx) {
        Player p = ctx.owner();
        PlayerSession s = ctx.session();
        String busy = Kit.requireIdle(s, BladeId.VORTH, BladeId.ZYRATH);
        if (busy != null) return busy;
        World w = p.getWorld();
        double range = Math.min(ctx.cfgD("range", 16.0), plugin.cfg().d("chain.max-length", 24.0) - 4.0);

        List<LivingEntity> cands = Kit.around(ctx, p.getLocation().toVector(), range, 12, true);
        if (cands.isEmpty()) return "No targets in sight.";
        cands.sort(Comparator.comparingDouble((LivingEntity e) -> Kit.healthFraction(e)).thenComparingDouble(LivingEntity::getHealth));
        List<LivingEntity> marks = cands.size() > ctx.cfgI("target-limit", 3) ? cands.subList(0, ctx.cfgI("target-limit", 3)) : cands;

        BladeUnit v = s.unit(BladeId.VORTH);
        BladeUnit z = s.unit(BladeId.ZYRATH);
        double open = ctx.baseDamage(5.0);
        double finish = ctx.baseDamage(20.0);
        double missBonus = ctx.cfgD("missing-health-bonus", 1.2);
        double thr = ctx.cfgD("execute-threshold", 0.25);
        double exMult = ctx.cfgD("execute-multiplier", 2.5);
        double[] chain = {1.0};

        Script sc = new Script();
        sc.run(() -> {
            for (LivingEntity m : marks) sc.own(s.strand(() -> s.handAnchor(BladeId.VORTH), () -> Kit.alive(m) ? Kit.center(m) : null, 1.0, 200, 6));
            plugin.fx().sound(w, p.getLocation().toVector(), "protocol_scan", "xarvoth:protocol.scan", 1.3f, 1.0f);
        });
        for (LivingEntity m : List.copyOf(marks)) {
            Vector[] last = {Kit.center(m)};
            sc.run(() -> {
                if (!Kit.alive(m)) return;
                plugin.restraints().restrain(p, m, 20);
                plugin.fx().ring(w, Kit.ground(w, Kit.center(m)), 2.0, 20, plugin.fx().energy(p));
                plugin.fx().rune(p, w, Kit.ground(w, Kit.center(m)), 2.2, 26);
                z.queue(new Motions.Homing(() -> Kit.alive(m) ? Kit.center(m) : null, 3.0, 1.1, 12).onArrive(() -> {
                    ctx.hit(BladeId.ZYRATH, m, open * BladeId.ZYRATH.damageMul, RavageMeter.Source.BLADE_HIT, new Vector(0, 0.05, 0));
                    plugin.fx().slash(w, Kit.center(m), new Vector(1, 0.4, 0.3), 2.6, plugin.fx().energy(p));
                }));
                v.queue(new Motions.Arc(() -> { if (Kit.alive(m)) last[0] = Kit.center(m); return last[0].clone().add(new Vector(0, 5.0, 0)); }, Kit.ZERO.clone(), 8, Motions.Easing.OUT));
                v.queue(new Motions.Arc(() -> { if (Kit.alive(m)) last[0] = Kit.center(m); return last[0].clone(); }, Kit.ZERO.clone(), 4, Motions.Easing.IN)
                        .then(() -> {
                            if (Kit.alive(m)) {
                                double mult = Kit.executeMult(m, missBonus, thr, exMult) * chain[0];
                                ctx.hit(BladeId.VORTH, m, finish * mult * BladeId.VORTH.damageMul, RavageMeter.Source.BLADE_HIT, new Vector(0, 0.3, 0));
                            }
                            if (!Kit.alive(m)) {
                                chain[0] *= 1.25;
                                ctx.gain(RavageMeter.Source.COMBO, m);
                                plugin.fx().spark(w, last[0], 40, 0.6);
                            }
                            plugin.fx().shockwave(w, Kit.ground(w, last[0]), 2.6, plugin.fx().energy(p));
                            plugin.fx().sound(w, last[0], "protocol_exec", "xarvoth:protocol.exec", 1.6f, 0.9f);
                        }));
            });
            sc.waitIdle(v, z);
            sc.waitTicks(4);
        }
        sc.onEnd(() -> { v.clearMotions(); z.clearMotions(); });
        return Kit.begin(ctx, sc);
    }
}

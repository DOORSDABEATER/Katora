package com.des.xarvoth.ability.impl;

import com.des.xarvoth.RavageMeter;
import com.des.xarvoth.XarvothPlugin;
import com.des.xarvoth.ability.AbilityCategory;
import com.des.xarvoth.ability.AbilityContext;
import com.des.xarvoth.blade.BladeId;
import com.des.xarvoth.blade.BladeUnit;
import com.des.xarvoth.blade.Motions;
import com.des.xarvoth.blade.PlayerSession;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/**
 * BLADE 4 - SKYREND. Both blades are flung high above the battlefield, hang there charged, then dive onto separate targets
 * from above (VORTH takes the 1st, 3rd... ZYRATH the 2nd, 4th...; with one target both dive on it), rising back between dives.
 */
public final class Skyrend extends BaseAbility {
    public Skyrend(XarvothPlugin plugin) { super(plugin, "skyrend", "SKYREND", AbilityCategory.BLADE); }

    @Override
    protected String start(AbilityContext ctx) {
        Player p = ctx.owner();
        PlayerSession s = ctx.session();
        String busy = Kit.requireIdle(s, BladeId.VORTH, BladeId.ZYRATH);
        if (busy != null) return busy;

        double range = Math.min(ctx.cfgD("range", 18.0), plugin.cfg().d("chain.max-length", 24.0) - 8.0);
        List<LivingEntity> targets = Kit.around(ctx, p.getLocation().toVector(), range, ctx.cfgI("target-limit", 4), false);
        if (targets.isEmpty()) return "No targets in range.";

        World w = p.getWorld();
        double dmg = ctx.baseDamage(11.0);
        double radius = ctx.cfgD("radius", 2.8);
        double height = ctx.cfgD("height", 11.0);

        for (BladeId id : BladeId.values()) {
            BladeUnit u = s.unit(id);
            double sg = id.side;
            Supplier<Vector> apex = () -> p.getLocation().toVector().add(s.right().multiply(3.5 * sg)).add(new Vector(0, height, 0));
            u.queue(new Motions.Arc(apex, s.right().multiply(2.0 * sg), 10, Motions.Easing.OUT)
                    .hook((b, t) -> plugin.fx().spark(w, b.pos, 2, 0.25)));
            u.queue(new Motions.Hold(5).hook((b, t) -> plugin.fx().ring(w, b.pos, 0.5 + t * 0.12, 10, plugin.fx().energy(p))));

            List<LivingEntity> mine = new ArrayList<>();
            for (int i = 0; i < targets.size(); i++) if (targets.size() == 1 || i % 2 == (id == BladeId.VORTH ? 0 : 1)) mine.add(targets.get(i));
            for (LivingEntity tg : mine) {
                Vector[] last = {Kit.center(tg)};
                Supplier<Vector> spot = () -> {
                    if (Kit.alive(tg)) last[0] = Kit.ground(w, Kit.center(tg)).add(new Vector(0, 0.4, 0));
                    return last[0].clone();
                };
                u.queue(new Motions.Arc(spot, Kit.ZERO.clone(), 5, Motions.Easing.IN)
                        .hook((b, t) -> plugin.fx().dust(w, b.pos, 3, 0.12, 1.6f, plugin.fx().energy(p)))
                        .then(() -> strike(ctx, id, last[0], dmg, radius)));
                u.queue(new Motions.Arc(apex, Kit.ZERO.clone(), 5, Motions.Easing.OUT));
            }
        }
        plugin.fx().sound(w, p.getLocation().toVector(), "sky_launch", "xarvoth:sky.launch", 1.3f, 1.0f);
        return null;
    }

    private void strike(AbilityContext ctx, BladeId id, Vector at, double dmg, double radius) {
        Player p = ctx.owner();
        if (!p.isOnline()) return;
        for (LivingEntity e : Kit.impact(ctx, id, at, radius, dmg * id.damageMul, 6, 0.7, 0.55)) ctx.gain(RavageMeter.Source.AERIAL, e);
        plugin.fx().shockwave(p.getWorld(), at, radius, plugin.fx().energy(p));
        plugin.fx().sound(p.getWorld(), at, "sky_impact", "xarvoth:sky.impact", 1.3f, id == BladeId.VORTH ? 0.8f : 1.2f);
    }
}

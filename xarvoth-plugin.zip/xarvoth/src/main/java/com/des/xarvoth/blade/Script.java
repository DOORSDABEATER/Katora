package com.des.xarvoth.blade;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;

/**
 * A timeline: steps run strictly one after another, each with a start action and a "done?" condition.
 * Blade motions are asynchronous (each blade runs its own queue), so scripts wait on them with waitIdle(...).
 * Strands registered with own(...) are closed on finish AND on cancel. stop() ends the script early (failure paths).
 */
public class Script extends Effect {
    private record Step(Runnable start, BooleanSupplier done) {}

    private final List<Step> steps = new ArrayList<>();
    private final List<ChainStrand> owned = new ArrayList<>();
    private int i = -1;
    private boolean stopped;
    private boolean exclusive;
    private Runnable onEnd;
    private Runnable onAbort;

    public Script exclusive(boolean e) { this.exclusive = e; return this; }
    public Script onEnd(Runnable r) { this.onEnd = r; return this; }
    public Script onAbort(Runnable r) { this.onAbort = r; return this; }

    public Script step(Runnable start, BooleanSupplier done) { steps.add(new Step(start, done)); return this; }

    public Script run(Runnable r) { return step(r, () -> true); }

    public Script waitTicks(int n) {
        int[] c = new int[1];
        return step(() -> c[0] = 0, () -> ++c[0] >= n);
    }

    public Script waitIdle(BladeUnit... units) {
        return step(() -> { }, () -> {
            for (BladeUnit u : units) if (u.isBusy()) return false;
            return true;
        });
    }

    /** Run {@code body} every tick for {@code ticks} ticks; body gets the tick index (0-based). */
    public Script during(int ticks, java.util.function.IntConsumer body) {
        int[] c = new int[1];
        return step(() -> c[0] = 0, () -> {
            body.accept(c[0]);
            return ++c[0] >= ticks;
        });
    }

    public ChainStrand own(ChainStrand s) { owned.add(s); return s; }

    public void stop() { stopped = true; }

    public boolean isStopped() { return stopped; }

    @Override public boolean exclusive() { return exclusive; }

    @Override public boolean tick(int age) {
        if (stopped) return true;
        while (true) {
            if (i >= 0 && !steps.get(i).done().getAsBoolean()) return false;
            if (stopped) return true;
            i++;
            if (i >= steps.size()) return true;
            steps.get(i).start().run();
            if (stopped) return true;
        }
    }

    private void closeOwned() { for (ChainStrand s : owned) s.close(); owned.clear(); }

    @Override public void onFinish() {
        closeOwned();
        if (onEnd != null) onEnd.run();
    }

    @Override public void onCancel() {
        closeOwned();
        if (onAbort != null) onAbort.run();
        if (onEnd != null) onEnd.run();
    }
}

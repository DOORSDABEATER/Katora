package com.des.xarvoth.ability.impl;

import com.des.xarvoth.RavageMeter;
import com.des.xarvoth.Targeting;
import com.des.xarvoth.XarvothPlugin;
import com.des.xarvoth.ability.Ability;
import com.des.xarvoth.ability.AbilityCategory;
import com.des.xarvoth.ability.AbilityContext;
import com.des.xarvoth.blade.BladeId;
import com.des.xarvoth.blade.BladeUnit;
import com.des.xarvoth.blade.Motion;
import com.des.xarvoth.blade.Motions;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.Locale;

/**
 * CHAIN AUTHORITY 1 - HELLBOUND GRASP.
 * ZYRATH is hurled along the aim line as a chain hook. If it lands (the damage event must survive, so protected targets
 * are never affected) the hook stays buried in the target while the chain drags it to the wielder, stopping at walls.
 * On arrival the target is rooted through RestraintService, which enforces the hold cap, post-hold immunity and window cap.
 * The pulled target is left standing in front of the wielder so a blade ability can follow up.
 */
public final class HellboundGrasp implements Ability {
    public static final String ID = "hellbound_grasp";
    private final XarvothPlugin plugin;

    public HellboundGrasp(XarvothPlugin plugin) { this.plugin = plugin; }

    @Override public String id() { return ID; }
    @Override public String displayName() { return "HELLBOUND GRASP"; }
    @Override public AbilityCategory category() { return AbilityCategory.CHAIN; }

    @Override
    public String activate(AbilityContext ctx) {
        Player p = ctx.owner();
        BladeUnit z = ctx.session().unit(BladeId.ZYRATH);
        if (z.isBusy()) return "ZYRATH is already out.";

        double maxLen = plugin.cfg().d("chain.max-length", 24.0);
        double range = Math.min(ctx.cfgD("range", 16.0), maxLen - 2.0);
        Targeting.Aim aim = Targeting.aim(p, range);
        if (aim == null || aim.entity() == null) return "No target in range.";

        final LivingEntity target = aim.entity();
        if (!plugin.damage().canTarget(p, target)) return "That target cannot be bound.";
        if (!plugin.restraints().canRestrain(target)) return "The chains cannot hold that.";
        long immune = plugin.restraints().immuneRemainingMs(target);
        if (immune > 0) return "Target is resisting the chains (" + String.format(Locale.ROOT, "%.1fs", immune / 1000.0) + ").";

        plugin.fx().sound(p.getWorld(), p.getLocation().toVector(), "grasp_launch", "minecraft:block.chain.place", 1.2f, 0.8f);
        z.queue(new Motions.Homing(() -> target.isValid() ? target.getBoundingBox().getCenter() : null, 2.4, 0.9, 14)
                .stopOnBlock()
                .onArrive(() -> capture(ctx, z, target)));
        return null;
    }

    private void capture(AbilityContext ctx, BladeUnit z, LivingEntity target) {
        Player p = ctx.owner();
        if (!p.isOnline() || !target.isValid() || target.isDead()) return;
        double dmg = ctx.baseDamage(4.0) * BladeId.ZYRATH.damageMul;
        if (!ctx.hit(BladeId.ZYRATH, target, dmg, RavageMeter.Source.CHAIN_HIT, null)) return;   // protected / cancelled: no pull, no root
        ctx.gain(RavageMeter.Source.CAPTURE, target);
        plugin.fx().sound(p.getWorld(), target.getLocation().toVector(), "grasp_bind", "minecraft:block.anvil.land", 1.0f, 1.4f);
        z.queue(new Pull(ctx, target));
    }

    private final class Pull extends Motion {
        private final AbilityContext ctx;
        private final LivingEntity victim;
        private final double speed;
        private final int maxTicks;
        private final int holdTicks;
        private int t;
        private boolean reached;

        Pull(AbilityContext ctx, LivingEntity victim) {
            this.ctx = ctx;
            this.victim = victim;
            this.speed = ctx.cfgD("pull-speed", 1.0);
            this.maxTicks = ctx.cfgI("pull-max-ticks", 30);
            this.holdTicks = ctx.cfgI("hold-ticks", 20);
        }

        @Override public boolean step() {
            Player p = ctx.owner();
            if (!victim.isValid() || victim.isDead() || !victim.getWorld().equals(p.getWorld())) return true;
            t++;

            Vector center = victim.getBoundingBox().getCenter();
            u.pos.copy(center);                                              // the hook stays buried in the target
            if (Targeting.blockedBetween(p.getWorld(), p.getEyeLocation().toVector(), center)) return true;   // never drag through walls

            Vector stop = p.getLocation().toVector().add(ctx.session().forward().multiply(2.0));
            Vector to = stop.subtract(victim.getLocation().toVector());
            double dist = to.length();
            if (dist <= 2.0) { reached = true; return true; }
            if (t > maxTicks) return true;

            Vector v = to.multiply(Math.min(speed, 0.25 + dist * 0.18) / dist);
            if (victim.isOnGround() && v.getY() < 0.08) v.setY(0.08);        // tiny lift so ground friction doesn't stall the pull
            victim.setVelocity(v);
            plugin.fx().dust(p.getWorld(), center, 2, 0.15, 1.2f, plugin.fx().energy(p));
            return false;
        }

        @Override public void onFinish() {
            Player p = ctx.owner();
            if (!p.isOnline() || !victim.isValid() || victim.isDead()) return;
            victim.setVelocity(new Vector(0, 0, 0));
            if (plugin.restraints().restrain(p, victim, holdTicks) > 0) {
                plugin.fx().sound(p.getWorld(), victim.getLocation().toVector(), "grasp_bind", "minecraft:block.anvil.land", 0.8f, 0.7f);
                plugin.fx().spark(p.getWorld(), victim.getBoundingBox().getCenter(), 20, 0.4);
            }
            if (reached) ctx.gain(RavageMeter.Source.PULL, victim);
        }
    }
}

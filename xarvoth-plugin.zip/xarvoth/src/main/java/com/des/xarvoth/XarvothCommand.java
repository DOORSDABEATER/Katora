package com.des.xarvoth;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class XarvothCommand implements CommandExecutor, TabCompleter {
    private static final List<String> SUB = List.of("give", "grant", "revoke", "reload", "meter", "cleanup", "status");
    private final XarvothPlugin plugin;

    public XarvothCommand(XarvothPlugin plugin) { this.plugin = plugin; }

    private void msg(CommandSender s, String text) { s.sendMessage(Text.c(text)); }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("xarvoth.admin")) { msg(sender, "&cNo permission."); return true; }
        if (args.length == 0) { msg(sender, "&7/xarvoth &f" + String.join("|", SUB)); return true; }

        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "give" -> {
                Player t = target(sender, args);
                if (t == null) return true;
                plugin.ownership().grant(t.getUniqueId());
                ItemStack item = plugin.ownership().issue(t);
                Map<Integer, ItemStack> left = t.getInventory().addItem(item);
                for (ItemStack rest : left.values()) t.getWorld().dropItemNaturally(t.getLocation(), rest);
                msg(sender, "&bXARVOTH bound to &f" + t.getName() + "&b. Any older weapon of theirs is now void.");
            }
            case "grant" -> {
                Player t = target(sender, args);
                if (t == null) return true;
                plugin.ownership().grant(t.getUniqueId());
                msg(sender, "&bAuthorized &f" + t.getName() + "&b. Use /xarvoth give to issue the weapon.");
            }
            case "revoke" -> {
                Player t = target(sender, args);
                if (t == null) return true;
                plugin.ownership().revoke(t.getUniqueId());
                plugin.blades().destroy(t);
                plugin.hud().hide(t);
                msg(sender, "&bRevoked &f" + t.getName() + "&b. All their weapons are void.");
            }
            case "reload" -> {
                plugin.reloadConfig();
                msg(sender, "&bConfig reloaded.");
            }
            case "meter" -> {
                Player t = target(sender, args);
                if (t == null) return true;
                if (args.length < 3) { msg(sender, "&7/xarvoth meter <player> <0-100>"); return true; }
                try {
                    plugin.meter().set(t, Double.parseDouble(args[2]));
                    msg(sender, "&bRavage meter of &f" + t.getName() + "&b set to " + args[2] + "%.");
                } catch (NumberFormatException ex) {
                    msg(sender, "&cNot a number.");
                }
            }
            case "cleanup" -> msg(sender, "&bRemoved " + plugin.blades().sweepStrays() + " stray displays.");
            case "status" -> msg(sender, "&bSessions: &f" + plugin.blades().sessions().size()
                    + " &bdisplays: &f" + plugin.blades().liveDisplayCount()
                    + " &babilities: &f" + plugin.registry().size()
                    + " &bauthorized: &f" + plugin.ownership().authorizedCount());
            default -> msg(sender, "&7/xarvoth &f" + String.join("|", SUB));
        }
        return true;
    }

    private Player target(CommandSender sender, String[] args) {
        if (args.length < 2) { msg(sender, "&cSpecify an online player."); return null; }
        Player t = Bukkit.getPlayerExact(args[1]);
        if (t == null) msg(sender, "&c" + args[1] + " is not online.");
        return t;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : SUB) if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
        } else if (args.length == 2 && !args[0].equalsIgnoreCase("reload") && !args[0].equalsIgnoreCase("cleanup") && !args[0].equalsIgnoreCase("status")) {
            for (Player p : Bukkit.getOnlinePlayers()) if (p.getName().toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))) out.add(p.getName());
        }
        return out;
    }
}

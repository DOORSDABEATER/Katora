package com.des.xarvoth.ability.impl;

import com.des.xarvoth.RavageMeter;
import com.des.xarvoth.XarvothPlugin;
import com.des.xarvoth.ability.AbilityCategory;
import com.des.xarvoth.ability.AbilityContext;
import com.des.xarvoth.blade.ChainStrand;
import com.des.xarvoth.blade.Effect;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * CHAIN 7 - ABYSSAL NETWORK. Up to four enemies are tied together by chains between every pair. While it lasts:
 *  - damage the wielder deals to any one of them is shared (config %) with the others,
 *  - the group cannot spread beyond a fixed radius around its centre (it drags them back together),
 *  - on a beat the links pulse, hurting and slowing every member,
 *  - anything else that walks through a chain is cut by it.
 * Only targets RestraintService grants time on join, so it cannot be chained onto the same victims forever.
 */
public final class AbyssalNetwork extends BaseAbility {
    public AbyssalNetwork(XarvothPlugin plugin) { super(plugin, "abyssal_network", "ABYSSAL NETWORK", AbilityCategory.CHAIN); }

    @Override
    protected String start(AbilityContext ctx) {
        Player p = ctx.owner();
        int dur = Math.min(ctx.cfgI("duration-ticks", 60), plugin.cfg().i("restraint.max-ticks", 60));
        double range = Math.min(ctx.cfgD("range", 16.0), plugin.cfg().d("chain.max-length", 24.0) - 2.0);
        List<LivingEntity> members = new ArrayList<>();
        for (LivingEntity e : Kit.around(ctx, p.getLocation().toVector(), range, ctx.cfgI("target-limit", 4) + 3, true)) {
            if (members.size() >= ctx.cfgI("target-limit", 4)) break;
            if (plugin.restraints().grant(e, dur, false) > 0) members.add(e);
        }
        if (members.size() < 2) return "A network needs at least two targets.";
        return Kit.begin(ctx, new Net(ctx, members, dur));
    }

    private final class Net extends Effect {
        private final AbilityContext ctx;
        private final List<LivingEntity> members;
        private final int dur;
        private final double share;
        private final double spread;
        private final List<ChainStrand> edges = new ArrayList<>();
        private final Map<UUID, Integer> edgeNext = new HashMap<>();

        Net(AbilityContext ctx, List<LivingEntity> members, int dur) {
            this.ctx = ctx;
            this.members = members;
            this.dur = dur;
            this.share = ctx.cfgD("share", 0.5);
            this.spread = ctx.cfgD("spread-radius", 7.0);
        }

        private int aliveCount() {
            int n = 0;
            for (LivingEntity e : members) if (Kit.alive(e)) n++;
            return n;
        }

        @Override public void onStart() {
            for (int i = 0; i < members.size(); i++) {
                for (int j = i + 1; j < members.size(); j++) {
                    LivingEntity a = members.get(i), b = members.get(j);
                    edges.add(session.strand(() -> Kit.alive(a) ? Kit.center(a) : null, () -> Kit.alive(b) ? Kit.center(b) : null, 1.15, dur + 10, 5));
                }
            }
            for (LivingEntity e : members) ctx.gain(RavageMeter.Source.CAPTURE, e);
            Player p = owner();
            plugin.fx().sound(p.getWorld(), Kit.center(members.get(0)), "network_link", "xarvoth:network.link", 1.4f, 1.0f);
        }

        private Vector centroid() {
            Vector c = new Vector();
            int n = 0;
            for (LivingEntity e : members) if (Kit.alive(e)) { c.add(Kit.center(e)); n++; }
            return n == 0 ? null : c.multiply(1.0 / n);
        }

        @Override public boolean tick(int age) {
            Player p = owner();
            World w = p.getWorld();
            if (aliveCount() < 2 || age > dur) return true;
            Vector c = centroid();
            if (c == null) return true;
            for (LivingEntity e : members) if (Kit.alive(e)) Kit.confine(e, c, spread);

            if (age % 20 == 0) {
                for (LivingEntity e : members) {
                    if (!Kit.alive(e)) continue;
                    ctx.hit(null, e, ctx.baseDamage(2.5), RavageMeter.Source.CHAIN_HIT, null);
                    plugin.restraints().slow(e, 30, 1);
                    plugin.fx().spark(w, Kit.center(e), 10, 0.3);
                }
                plugin.fx().sound(w, c, "network_pulse", "xarvoth:network.pulse", 1.0f, 1.0f);
            }
            if (age % 5 == 0) {
                for (ChainStrand edge : edges) {
                    for (LivingEntity e : edge.sweep(0.7)) {
                        if (members.contains(e) || !plugin.damage().canTarget(p, e)) continue;
                        UUID id = e.getUniqueId();
                        if (age < edgeNext.getOrDefault(id, 0)) continue;
                        edgeNext.put(id, age + 10);
                        ctx.hit(null, e, ctx.baseDamage(2.5) * 0.6, RavageMeter.Source.CHAIN_HIT, Kit.kb(c, e.getLocation().toVector(), 0.5, 0.2));
                    }
                }
            }
            return false;
        }

        @Override public void onHit(LivingEntity victim, double amount) {
            if (!members.contains(victim)) return;
            for (LivingEntity other : members) {
                if (other.equals(victim) || !Kit.alive(other)) continue;
                if (plugin.damage().damage(owner(), other, amount * share, null)) {
                    plugin.meter().gain(owner(), other, RavageMeter.Source.CHAIN_HIT);
                    plugin.fx().spark(owner().getWorld(), Kit.center(other), 8, 0.25);
                }
            }
        }

        @Override public void onFinish() { close(); }
        @Override public void onCancel() { close(); }

        private void close() {
            for (ChainStrand e : edges) e.close();
            edges.clear();
        }
    }
}

package com.des.xarvoth.ability.impl;

import com.des.xarvoth.RavageMeter;
import com.des.xarvoth.XarvothPlugin;
import com.des.xarvoth.ability.AbilityCategory;
import com.des.xarvoth.ability.AbilityContext;
import com.des.xarvoth.blade.BladeId;
import com.des.xarvoth.blade.PlayerSession;
import com.des.xarvoth.blade.Script;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.List;

/**
 * CHAIN 4 - DOMINION PULL. Chains lash out of both hands at every visible enemy in a wide radius and drag them all into one
 * tight knot in front of the wielder, breaking whatever formation they held. Pulled targets are left staggered (a short, capped
 * slow - not a root) so the wielder can follow up with a blade ability.
 */
public final class DominionPull extends BaseAbility {
    public DominionPull(XarvothPlugin plugin) { super(plugin, "dominion_pull", "DOMINION PULL", AbilityCategory.CHAIN); }

    @Override
    protected String start(AbilityContext ctx) {
        Player p = ctx.owner();
        PlayerSession s = ctx.session();
        World w = p.getWorld();
        double range = Math.min(ctx.cfgD("range", 11.0), plugin.cfg().d("chain.max-length", 24.0) - 4.0);
        List<LivingEntity> victims = Kit.around(ctx, p.getLocation().toVector(), range, ctx.cfgI("target-limit", 8), true);
        if (victims.isEmpty()) return "No targets in sight.";

        Vector gather = Kit.ground(w, p.getLocation().toVector().add(s.forward().multiply(ctx.cfgD("gather-distance", 3.5))));
        double dmg = ctx.baseDamage(3.0);
        int pullTicks = ctx.cfgI("pull-ticks", 14);
        double speed = ctx.cfgD("pull-speed", 1.1);

        Script sc = new Script();
        sc.run(() -> {
            int n = 0;
            for (LivingEntity e : victims) {
                if (n++ < 5) {
                    BladeId hand = n % 2 == 0 ? BladeId.VORTH : BladeId.ZYRATH;
                    sc.own(s.strand(() -> s.handAnchor(hand), () -> Kit.alive(e) ? Kit.center(e) : gather, 1.0, pullTicks + 10, 6));
                }
                ctx.hit(null, e, dmg, RavageMeter.Source.CHAIN_HIT, null);
            }
            plugin.fx().sound(w, p.getLocation().toVector(), "dominion_pull", "xarvoth:dominion.pull", 1.4f, 0.9f);
        });
        sc.during(pullTicks, i -> {
            for (LivingEntity e : victims) {
                if (!Kit.alive(e)) continue;
                Kit.pull(e, gather, speed);
                if (i % 3 == 0) plugin.fx().dust(w, Kit.center(e), 2, 0.2, 1.2f, plugin.fx().energy(p));
            }
        });
        sc.run(() -> {
            for (LivingEntity e : victims) {
                if (!Kit.alive(e)) continue;
                plugin.restraints().slow(e, 30, 1);
                ctx.gain(RavageMeter.Source.PULL, e);
            }
            plugin.fx().shockwave(w, gather, 2.5, plugin.fx().energy(p));
            plugin.fx().sound(w, gather, "dominion_snap", "xarvoth:dominion.snap", 1.2f, 1.0f);
        });
        return Kit.begin(ctx, sc);
    }
}

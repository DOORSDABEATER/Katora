package com.des.xarvoth;

import com.des.xarvoth.blade.PlayerSession;
import org.bukkit.GameMode;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Tameable;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.scoreboard.Team;
import org.bukkit.util.Vector;

/**
 * The single place XARVOTH deals damage. Server-authoritative: damage goes through LivingEntity#damage(amount, owner),
 * so protection / region / PvP plugins see a normal EntityDamageByEntityEvent and can cancel it. A hit only counts
 * (meter, knockback, follow-up effects) if that event survived.
 */
public final class DamageService implements Listener {
    private static final class Ctx {
        final LivingEntity victim;
        boolean landed;
        Ctx(LivingEntity v) { victim = v; }
    }

    private final XarvothPlugin plugin;
    private Ctx current;
    private boolean propagating;

    public DamageService(XarvothPlugin plugin) { this.plugin = plugin; }

    public boolean canTarget(Player owner, LivingEntity victim) {
        if (victim == null || victim.equals(owner) || victim.isDead() || !victim.isValid()) return false;
        if (victim.isInvulnerable()) return false;
        if (victim instanceof ArmorStand a && a.isMarker()) return false;
        if (victim instanceof Player p) {
            if (!plugin.cfg().b("pvp.enabled", true)) return false;
            if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return false;
        }
        if (victim instanceof Tameable t && t.isTamed() && t.getOwner() != null
                && t.getOwner().getUniqueId().equals(owner.getUniqueId())) return false;
        Team team = owner.getScoreboard().getEntryTeam(owner.getName());
        if (team != null && !team.allowFriendlyFire()) {
            String entry = victim instanceof Player ? victim.getName() : victim.getUniqueId().toString();
            if (team.hasEntry(entry)) return false;
        }
        return true;
    }

    /** @return true if damage actually landed (event not cancelled, final damage above zero). */
    public boolean damage(Player owner, LivingEntity victim, double base, Vector knockback) {
        if (!canTarget(owner, victim)) return false;
        Cfg cfg = plugin.cfg();
        double amount = base;
        if (plugin.meter().isEmpowered(owner)) amount *= 1.0 + cfg.d("ravage.damage-bonus", 0.40);
        if (victim instanceof Player) amount *= cfg.d("pvp.damage-multiplier", 1.0);
        amount = Math.min(amount, cfg.d("max-hit-damage", 60.0));
        if (amount <= 0) return false;

        Ctx prev = current;
        Ctx ctx = new Ctx(victim);
        current = ctx;
        try {
            victim.setNoDamageTicks(0); // multi-hit abilities must not be eaten by vanilla i-frames
            victim.damage(amount, owner);
        } finally {
            current = prev;
        }
        if (ctx.landed) {
            if (knockback != null) applyKnockback(victim, knockback);
            if (!propagating) {                       // effects may react (Abyssal Network shares damage); never recursively
                propagating = true;
                try {
                    PlayerSession s = plugin.blades().session(owner);
                    if (s != null) s.afterHit(victim, amount);
                } finally {
                    propagating = false;
                }
            }
        }
        return ctx.landed;
    }

    private void applyKnockback(LivingEntity victim, Vector kb) {
        Vector k = kb.clone();
        double max = plugin.cfg().d("max-knockback", 2.0);
        if (k.lengthSquared() > max * max) k.normalize().multiply(max);
        victim.setVelocity(victim.getVelocity().multiply(0.4).add(k));
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDamage(EntityDamageByEntityEvent e) {
        Ctx c = current;
        if (c != null && e.getEntity() == c.victim) c.landed = !e.isCancelled() && e.getFinalDamage() > 0;
    }
}

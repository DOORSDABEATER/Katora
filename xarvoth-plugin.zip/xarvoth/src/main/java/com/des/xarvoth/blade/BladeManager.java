package com.des.xarvoth.blade;

import com.des.xarvoth.XarvothPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Display;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Owns every PlayerSession. One repeating task drives all blade simulation, so cost scales with the number of
 * wielders currently holding XARVOTH - nobody else costs anything. Every display entity spawned is tracked
 * so cleanup (quit, death, world change, disable, /xarvoth cleanup) can always account for all of them.
 */
public final class BladeManager {
    public static final String TAG = "xarvoth_display";

    private final XarvothPlugin plugin;
    private final Map<UUID, PlayerSession> sessions = new HashMap<>();
    private final Set<UUID> live = new HashSet<>();
    private BukkitTask task;

    public BladeManager(XarvothPlugin plugin) { this.plugin = plugin; }

    public void start() {
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L);
    }

    public void shutdown() {
        if (task != null) task.cancel();
        for (PlayerSession s : new ArrayList<>(sessions.values())) s.destroy();
        sessions.clear();
        sweepStrays();
    }

    public PlayerSession session(Player p) { return sessions.get(p.getUniqueId()); }

    public Collection<PlayerSession> sessions() { return new ArrayList<>(sessions.values()); }

    void register(UUID id) { live.add(id); }

    /** Single place every XARVOTH display entity is created: non-persistent, tagged, tracked. */
    public ItemDisplay spawnDisplay(World w, Vector at, ItemStack item) {
        ItemDisplay d = w.spawn(new Location(w, at.getX(), at.getY(), at.getZ()), ItemDisplay.class, e -> {
            e.setItemStack(item);
            e.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
            e.setBillboard(Display.Billboard.FIXED);
            e.setPersistent(false);
            e.setGravity(false);
            e.setInvulnerable(true);
            e.setBrightness(new Display.Brightness(15, 15));
            e.setTeleportDuration(2);
            e.setInterpolationDuration(2);
            e.addScoreboardTag(TAG);
        });
        live.add(d.getUniqueId());
        return d;
    }

    public void despawnDisplay(ItemDisplay d) {
        live.remove(d.getUniqueId());
        d.remove();
    }
    void unregister(UUID id) { live.remove(id); }

    private void tick() {
        int tick = Bukkit.getCurrentTick();
        if (tick % 10 == 0) {
            for (Player p : Bukkit.getOnlinePlayers()) refresh(p);
            plugin.meter().prune();
            plugin.restraints().prune();
        }
        for (PlayerSession s : new ArrayList<>(sessions.values())) {
            Player p = s.owner();
            if (!p.isOnline() || !p.isValid() || p.isDead()) { destroy(p); continue; }
            try {
                s.tick(tick);
            } catch (RuntimeException ex) {
                plugin.getLogger().severe("Session tick failed for " + p.getName() + ", destroying it: " + ex);
                destroy(p);
            }
        }
    }

    /** Re-evaluates whether this player is holding a genuine XARVOTH and creates / hides their session accordingly. */
    public void refresh(Player p) {
        UUID id = p.getUniqueId();
        PlayerSession s = sessions.get(id);
        boolean holding = p.isOnline() && !p.isDead()
                && !plugin.cfg().worldDisabled(p.getWorld().getName())
                && plugin.ownership().holdsValid(p);
        if (holding) {
            if (s == null) {
                s = new PlayerSession(plugin, p);
                sessions.put(id, s);
            }
            s.setHolding(true);
            if (!s.isVisible()) s.show();
        } else if (s != null) {
            s.setHolding(false);
            if (s.anyOut()) {
                s.interrupt();        // blades swing home; session is removed on a later refresh once they're back
            } else {
                s.destroy();
                sessions.remove(id);
            }
        }
    }

    public void refreshSoon(Player p) {
        Bukkit.getScheduler().runTask(plugin, () -> { if (p.isOnline()) refresh(p); });
    }

    public void destroy(Player p) {
        PlayerSession s = sessions.remove(p.getUniqueId());
        if (s != null) s.destroy();
    }

    /** Removes any tagged display that no live session accounts for. */
    public int sweepStrays() {
        int n = 0;
        for (World w : Bukkit.getWorlds()) {
            for (Entity e : w.getEntitiesByClass(ItemDisplay.class)) {
                if (e.getScoreboardTags().contains(TAG) && !live.contains(e.getUniqueId())) {
                    e.remove();
                    n++;
                }
            }
        }
        return n;
    }

    public int liveDisplayCount() { return live.size(); }
}

package com.des.xarvoth;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.HashSet;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Ownership is identity-based, never name-based.
 *
 * A weapon item is valid only if ALL of these hold:
 *  - it carries the xarvoth id tag, a serial, an owner UUID and an HMAC signature made with a server-side secret
 *  - the signature verifies (forged / edited item data fails)
 *  - the serial is registered to that same owner and has not been revoked
 *  - the holder IS that owner and is currently authorized
 *
 * Renaming an item changes nothing that is checked. Copying an item gives the copy the same serial and owner,
 * so it only ever works for the real owner. Issuing a new weapon revokes the owner's older serials.
 *
 * To bind this to DeS' NULL//REQUIEM system, call {@link #setExternalAuthorizer}: when set, it replaces the
 * built-in authorized-UUID list as the "is this player allowed" decision. Item signing still applies.
 */
public final class OwnershipService {
    public interface ExternalAuthorizer { boolean isAuthorized(Player player); }

    public static final String ITEM_ID = "xarvoth";

    private final XarvothPlugin plugin;
    private final File dataFile;
    private final Set<UUID> authorized = new HashSet<>();
    private final Map<String, UUID> serials = new HashMap<>();
    private final Set<String> revoked = new HashSet<>();
    private final byte[] secret;
    private volatile ExternalAuthorizer external;
    private final NamespacedKey kId, kSerial, kOwner, kSig;

    public OwnershipService(XarvothPlugin plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "owners.yml");
        this.kId = new NamespacedKey(plugin, "id");
        this.kSerial = new NamespacedKey(plugin, "serial");
        this.kOwner = new NamespacedKey(plugin, "owner");
        this.kSig = new NamespacedKey(plugin, "sig");
        this.secret = loadOrCreateSecret(new File(plugin.getDataFolder(), "secret.key"));
        load();
    }

    public void setExternalAuthorizer(ExternalAuthorizer ex) { this.external = ex; }

    private byte[] loadOrCreateSecret(File f) {
        try {
            plugin.getDataFolder().mkdirs();
            if (f.exists()) {
                return Base64.getDecoder().decode(Files.readString(f.toPath()).trim());
            }
            byte[] key = new byte[32];
            new SecureRandom().nextBytes(key);
            Files.writeString(f.toPath(), Base64.getEncoder().encodeToString(key));
            return key;
        } catch (IOException | IllegalArgumentException e) {
            // Without a persistent key every issued weapon would break on restart, so refuse to run.
            throw new IllegalStateException("Cannot load or create secret.key", e);
        }
    }

    private void load() {
        if (!dataFile.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(dataFile);
        for (String s : y.getStringList("authorized")) {
            try { authorized.add(UUID.fromString(s)); } catch (IllegalArgumentException ignored) { }
        }
        ConfigurationSection sec = y.getConfigurationSection("serials");
        if (sec != null) {
            for (String serial : sec.getKeys(false)) {
                try { serials.put(serial, UUID.fromString(sec.getString(serial, ""))); } catch (IllegalArgumentException ignored) { }
            }
        }
        revoked.addAll(y.getStringList("revoked"));
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        List<String> a = new ArrayList<>();
        for (UUID u : authorized) a.add(u.toString());
        y.set("authorized", a);
        for (Map.Entry<String, UUID> e : serials.entrySet()) y.set("serials." + e.getKey(), e.getValue().toString());
        y.set("revoked", new ArrayList<>(revoked));
        try { y.save(dataFile); } catch (IOException e) { plugin.getLogger().severe("Could not save owners.yml: " + e.getMessage()); }
    }

    public boolean isAuthorized(Player p) {
        ExternalAuthorizer ex = external;
        if (ex != null) return ex.isAuthorized(p);
        return authorized.contains(p.getUniqueId());
    }

    public void grant(UUID id) { authorized.add(id); save(); }

    public void revoke(UUID id) {
        authorized.remove(id);
        for (Map.Entry<String, UUID> e : serials.entrySet()) if (e.getValue().equals(id)) revoked.add(e.getKey());
        save();
    }

    public int authorizedCount() { return authorized.size(); }

    /** Creates a fresh signed weapon bound to {@code target}. */
    public ItemStack issue(Player target) {
        UUID owner = target.getUniqueId();
        if (plugin.cfg().b("security.single-active-serial", true)) {
            for (Map.Entry<String, UUID> e : serials.entrySet()) if (e.getValue().equals(owner)) revoked.add(e.getKey());
        }
        String serial = UUID.randomUUID().toString();
        serials.put(serial, owner);

        Material mat = Material.matchMaterial(plugin.cfg().s("item.material", "NETHERITE_SWORD"));
        if (mat == null) mat = Material.NETHERITE_SWORD;
        ItemStack item = new ItemStack(mat);
        ItemMeta m = item.getItemMeta();
        m.displayName(Text.item(plugin.cfg().s("item.display-name", "&bXARVOTH")));
        List<net.kyori.adventure.text.Component> lore = new ArrayList<>();
        for (String line : plugin.cfg().list("item.lore")) lore.add(Text.item(line));
        m.lore(lore);
        m.setItemModel(Models.weaponKey(plugin, false));
        m.setUnbreakable(true);
        m.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE);
        PersistentDataContainer pdc = m.getPersistentDataContainer();
        pdc.set(kId, PersistentDataType.STRING, ITEM_ID);
        pdc.set(kSerial, PersistentDataType.STRING, serial);
        pdc.set(kOwner, PersistentDataType.STRING, owner.toString());
        pdc.set(kSig, PersistentDataType.STRING, sign(serial, owner.toString()));
        item.setItemMeta(m);
        save();
        return item;
    }

    /** Cheap pre-check: does the item merely claim to be XARVOTH? */
    public boolean looksLikeXarvoth(ItemStack item) {
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) return false;
        return ITEM_ID.equals(item.getItemMeta().getPersistentDataContainer().get(kId, PersistentDataType.STRING));
    }

    /** Full check. True only for the authorized owner holding a genuine, unrevoked, correctly signed item. */
    public boolean validate(ItemStack item, Player holder) {
        if (!looksLikeXarvoth(item)) return false;
        PersistentDataContainer pdc = item.getItemMeta().getPersistentDataContainer();
        String serial = pdc.get(kSerial, PersistentDataType.STRING);
        String ownerStr = pdc.get(kOwner, PersistentDataType.STRING);
        String sig = pdc.get(kSig, PersistentDataType.STRING);
        if (serial == null || ownerStr == null || sig == null) return false;
        if (!MessageDigest.isEqual(sig.getBytes(StandardCharsets.UTF_8), sign(serial, ownerStr).getBytes(StandardCharsets.UTF_8))) return false;
        UUID owner;
        try { owner = UUID.fromString(ownerStr); } catch (IllegalArgumentException e) { return false; }
        if (!owner.equals(holder.getUniqueId())) return false;
        if (revoked.contains(serial)) return false;
        if (!owner.equals(serials.get(serial))) return false;
        return isAuthorized(holder);
    }

    public boolean holdsValid(Player p) { return validate(p.getInventory().getItemInMainHand(), p); }

    private String sign(String serial, String owner) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(secret, "HmacSHA256"));
            return HexFormat.of().formatHex(mac.doFinal((serial + ":" + owner).getBytes(StandardCharsets.UTF_8)));
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException(e);
        }
    }
}

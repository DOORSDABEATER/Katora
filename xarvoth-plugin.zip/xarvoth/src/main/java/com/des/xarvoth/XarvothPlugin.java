package com.des.xarvoth;

import com.des.xarvoth.ability.AbilityRegistry;
import com.des.xarvoth.ability.AbilityService;
import com.des.xarvoth.ability.impl.*;
import com.des.xarvoth.blade.BladeManager;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public final class XarvothPlugin extends JavaPlugin {
    private Cfg cfg;
    private OwnershipService ownership;
    private CooldownManager cooldowns;
    private RavageMeter meter;
    private DamageService damage;
    private ComboTracker combos;
    private RestraintService restraints;
    private Fx fx;
    private BladeManager blades;
    private AbilityRegistry registry;
    private SelectionManager selection;
    private AbilityService abilityService;
    private HudService hud;
    private Vfx vfx;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        cfg = new Cfg(this);
        ownership = new OwnershipService(this);
        cooldowns = new CooldownManager(this);
        meter = new RavageMeter(this);
        damage = new DamageService(this);
        combos = new ComboTracker(this);
        restraints = new RestraintService(this);
        fx = new Fx(this);
        blades = new BladeManager(this);
        registry = new AbilityRegistry();
        selection = new SelectionManager(this);
        abilityService = new AbilityService(this);
        hud = new HudService(this);
        vfx = new Vfx(this);

        // Selection order inside each authority is the order registered here.
        // BLADE AUTHORITY
        registry.register(new VorthsAnnihilation(this));
        registry.register(new ZyrathsFury(this));
        registry.register(new DualReaping(this));
        registry.register(new Skyrend(this));
        registry.register(new ReturnToRuin(this));
        registry.register(new HollowExecution(this));
        registry.register(new InfiniteCarnage(this));
        // CHAIN AUTHORITY
        registry.register(new HellboundGrasp(this));
        registry.register(new WorldAnchor(this));
        registry.register(new IronPrison(this));
        registry.register(new DominionPull(this));
        registry.register(new Chainstorm(this));
        registry.register(new UnbreakableReprisal(this));
        registry.register(new AbyssalNetwork(this));
        // CONVERGENCE AUTHORITY
        registry.register(new CrossboundExecution(this));
        registry.register(new GravityReaver(this));
        registry.register(new ThousandLinkSlaughter(this));
        registry.register(new DualityBreaker(this));
        registry.register(new SkyfallDominion(this));
        registry.register(new EndlessPursuit(this));
        registry.register(new SovereignsCage(this));
        registry.register(new FractureOfTheBound(this));
        registry.register(new RavageTornado(this));
        registry.register(new ExecutionProtocol(this));
        registry.register(new WorldsLastBinding(this));
        registry.register(new GodrendAnnihilation(this));
        // ULTIMATES
        registry.register(new CrownOfTheRavager(this));
        registry.register(new KingdomOfChains(this));
        registry.register(new ThroneOfTheGodrend(this));

        getServer().getPluginManager().registerEvents(damage, this);
        getServer().getPluginManager().registerEvents(new XarvothListener(this), this);

        PluginCommand pc = getCommand("xarvoth");
        if (pc != null) {
            XarvothCommand ex = new XarvothCommand(this);
            pc.setExecutor(ex);
            pc.setTabCompleter(ex);
        }

        blades.start();
        hud.start();
        vfx.start();
        for (Player p : Bukkit.getOnlinePlayers()) loadPlayer(p);
        Bukkit.getScheduler().runTask(this, () -> blades.sweepStrays());
        getLogger().info("XARVOTH online with " + registry.size() + " abilities.");
    }

    @Override
    public void onDisable() {
        for (Player p : Bukkit.getOnlinePlayers()) savePlayer(p);
        if (vfx != null) vfx.shutdown();
        if (hud != null) hud.shutdown();
        if (blades != null) blades.shutdown();
        if (ownership != null) ownership.save();
    }

    public void loadPlayer(Player p) {
        cooldowns.load(p);
        meter.load(p);
        selection.load(p);
    }

    public void savePlayer(Player p) {
        cooldowns.save(p);
        meter.save(p);
        selection.save(p);
    }

    /** Drops every in-memory trace of a player after they leave. */
    public void forgetPlayer(Player p) {
        cooldowns.reset(p.getUniqueId());
        meter.forget(p.getUniqueId());
        combos.forget(p.getUniqueId());
        selection.forget(p.getUniqueId());
        abilityService.forget(p.getUniqueId());
        hud.forget(p.getUniqueId());
    }

    public Cfg cfg() { return cfg; }
    public OwnershipService ownership() { return ownership; }
    public CooldownManager cooldowns() { return cooldowns; }
    public RavageMeter meter() { return meter; }
    public DamageService damage() { return damage; }
    public ComboTracker combos() { return combos; }
    public RestraintService restraints() { return restraints; }
    public Fx fx() { return fx; }
    public BladeManager blades() { return blades; }
    public AbilityRegistry registry() { return registry; }
    public SelectionManager selection() { return selection; }
    public AbilityService abilityService() { return abilityService; }
    public HudService hud() { return hud; }
    public Vfx vfx() { return vfx; }
}

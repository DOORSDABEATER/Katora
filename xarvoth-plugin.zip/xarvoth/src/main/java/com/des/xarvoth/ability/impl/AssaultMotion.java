package com.des.xarvoth.ability.impl;

import com.des.xarvoth.Fx;
import com.des.xarvoth.RavageMeter;
import com.des.xarvoth.Targeting;
import com.des.xarvoth.ability.AbilityContext;
import com.des.xarvoth.blade.BladeId;
import com.des.xarvoth.blade.Motion;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.function.DoubleUnaryOperator;
import java.util.function.Supplier;

/**
 * A blade that blinks to a fresh angle around a target, strikes it, and moves to the next one, over and over.
 * Used by the big abilities and ultimates. Escalation maps "fraction of strikes done" (0..1) to a damage multiplier.
 * Dead / invalid targets are skipped; with none left it ends. Hard caps on strikes and total ticks.
 */
public final class AssaultMotion extends Motion {
    private final AbilityContext ctx;
    private final BladeId blade;
    private final Supplier<List<LivingEntity>> targets;
    private final int strikes;
    private final double perHit;
    private final int orbitTicks;
    private final double speed;
    private final DoubleUnaryOperator escalate;
    private final int maxTicks;
    private int t;
    private int hits;
    private int idx;
    private boolean blinked;

    public AssaultMotion(AbilityContext ctx, BladeId blade, Supplier<List<LivingEntity>> targets, int strikes, double perHit,
                         int orbitTicks, double speed, DoubleUnaryOperator escalate) {
        this.ctx = ctx;
        this.blade = blade;
        this.targets = targets;
        this.strikes = strikes;
        this.perHit = perHit;
        this.orbitTicks = orbitTicks;
        this.speed = speed;
        this.escalate = escalate;
        this.maxTicks = orbitTicks + strikes * 8 + 16;
    }

    @Override public boolean step() {
        t++;
        Player p = ctx.owner();
        Fx fx = ctx.plugin().fx();
        if (t <= orbitTicks) {
            double ang = t * 1.0 * blade.side;
            Vector c = p.getLocation().toVector().add(new Vector(0, 1.3, 0));
            Vector tp = c.add(new Vector(Math.cos(ang) * 1.9, Math.sin(ang * 2) * 0.3, Math.sin(ang) * 1.9));
            u.pos.add(tp.subtract(u.pos).multiply(0.6));
            fx.dust(p.getWorld(), u.pos, 1, 0.05, 1.0f, fx.energy(p));
            return false;
        }
        if (t > maxTicks) return true;

        List<LivingEntity> alive = new ArrayList<>();
        for (LivingEntity e : targets.get()) if (Kit.alive(e) && e.getWorld().equals(p.getWorld())) alive.add(e);
        if (alive.isEmpty()) return true;
        LivingEntity cur = alive.get(idx % alive.size());

        Vector center = Kit.center(cur);
        if (!blinked) {
            double a = idx * 2.399 + blade.side * 1.1;
            Vector from = center.clone().add(new Vector(Math.cos(a) * 2.5, 0.3 * Math.sin(idx), Math.sin(a) * 2.5));
            if (!Targeting.blockedBetween(p.getWorld(), center, from)) {
                u.pos.copy(from);
                u.prev.copy(from);
            }
            blinked = true;
        }

        Vector d = center.clone().subtract(u.pos);
        double dist = d.length();
        if (dist <= 1.2) {
            double mult = escalate == null ? 1.0 : escalate.applyAsDouble(hits / (double) strikes);
            Vector kb = dist > 1e-4 ? d.clone().normalize().multiply(0.25) : new Vector(0, 0, 0);
            kb.setY(0.1);
            ctx.hit(blade, cur, perHit * mult * blade.damageMul, RavageMeter.Source.BLADE_HIT, kb);
            fx.slash(p.getWorld(), center, d, 1.8 + mult, fx.energy(p));
            fx.sound(p.getWorld(), center, "blade_hit", "xarvoth:blade.hit", 0.9f, 1.2f + Math.min(0.6f, hits * 0.03f));
            hits++;
            idx++;
            blinked = false;
            return hits >= strikes;
        }
        u.pos.add(d.multiply(Math.min(speed, dist - 0.4) / dist));
        return false;
    }
}

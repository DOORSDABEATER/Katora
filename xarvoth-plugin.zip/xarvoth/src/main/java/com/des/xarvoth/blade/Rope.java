package com.des.xarvoth.blade;

import org.bukkit.util.Vector;

/**
 * Verlet rope. Both ends are pinned (wielder's hand, blade pommel); interior nodes integrate with gravity and damping,
 * then distance constraints are relaxed a few times. Fully deterministic, no entities involved - the renderer just reads the nodes.
 * A little slack makes a near blade's chain sag; a far blade pulls it taut.
 */
final class Rope {
    final int n;
    final Vector[] p;
    private final Vector[] o;
    private boolean init;

    Rope(int n) {
        this.n = n;
        p = new Vector[n];
        o = new Vector[n];
        for (int i = 0; i < n; i++) { p[i] = new Vector(); o[i] = new Vector(); }
    }

    void reset() { init = false; }

    private void init(Vector a, Vector b) {
        for (int i = 0; i < n; i++) {
            double k = i / (double) (n - 1);
            p[i].setX(a.getX() + (b.getX() - a.getX()) * k);
            p[i].setY(a.getY() + (b.getY() - a.getY()) * k);
            p[i].setZ(a.getZ() + (b.getZ() - a.getZ()) * k);
            o[i].copy(p[i]);
        }
        init = true;
    }

    void step(Vector a, Vector b, double gravity, double damping, int iterations, double slack) {
        if (!init || p[0].distanceSquared(a) > 36.0) init(a, b);
        double dist = a.distance(b);
        double seg = Math.max(dist * slack, 0.6) / (n - 1);

        for (int i = 1; i < n - 1; i++) {
            double vx = (p[i].getX() - o[i].getX()) * damping;
            double vy = (p[i].getY() - o[i].getY()) * damping;
            double vz = (p[i].getZ() - o[i].getZ()) * damping;
            o[i].copy(p[i]);
            p[i].setX(p[i].getX() + vx);
            p[i].setY(p[i].getY() + vy - gravity);
            p[i].setZ(p[i].getZ() + vz);
        }
        p[0].copy(a);
        p[n - 1].copy(b);

        for (int it = 0; it < iterations; it++) {
            for (int i = 0; i < n - 1; i++) {
                Vector A = p[i], B = p[i + 1];
                double dx = B.getX() - A.getX(), dy = B.getY() - A.getY(), dz = B.getZ() - A.getZ();
                double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
                if (len < 1e-9) continue;
                double diff = (len - seg) / len;
                boolean pinA = i == 0, pinB = i + 1 == n - 1;
                double wA = pinA ? 0 : (pinB ? 1 : 0.5);
                double wB = pinB ? 0 : (pinA ? 1 : 0.5);
                A.setX(A.getX() + dx * diff * wA);
                A.setY(A.getY() + dy * diff * wA);
                A.setZ(A.getZ() + dz * diff * wA);
                B.setX(B.getX() - dx * diff * wB);
                B.setY(B.getY() - dy * diff * wB);
                B.setZ(B.getZ() - dz * diff * wB);
            }
            p[0].copy(a);
            p[n - 1].copy(b);
        }
    }
}

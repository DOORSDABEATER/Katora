package com.des.xarvoth.ability.impl;

import com.des.xarvoth.RavageMeter;
import com.des.xarvoth.XarvothPlugin;
import com.des.xarvoth.ability.AbilityCategory;
import com.des.xarvoth.ability.AbilityContext;
import com.des.xarvoth.blade.Barrier;
import com.des.xarvoth.blade.BladeId;
import com.des.xarvoth.blade.BladeUnit;
import com.des.xarvoth.blade.Hitbook;
import com.des.xarvoth.blade.Motions;
import com.des.xarvoth.blade.PlayerSession;
import com.des.xarvoth.blade.Script;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * CONVERGENCE ULTIMATE - THRONE OF THE GODREND. Blades and chains as one sovereign.
 *  1. ASCENSION: the blades are hurled to opposite ends of the sky above the battlefield and a colossal chain is drawn between
 *     them - an arch over the field, sagging under its own weight.
 *  2. JUDGEMENT SEAT: every enemy in range (limit 10, only those RestraintService grants time on) is claimed by chains from the
 *     blades and drawn up into the air beneath the arch, held for a capped time.
 *  3. THE CARVING: the blades drop from the arch and carve the suspended enemies in turn, escalating, while the arch lashes
 *     them on a beat.
 *  4. VERDICT: the blades withdraw to opposite sides and tear through the centre along crossing lines - an X across the whole
 *     field - and the captives are cast down into a final detonation.
 * Unlike the other two ultimates it needs both blades AND three kinds of chain work to be running together.
 */
public final class ThroneOfTheGodrend extends BaseAbility {
    public ThroneOfTheGodrend(XarvothPlugin plugin) { super(plugin, "throne_of_the_godrend", "THRONE OF THE GODREND", AbilityCategory.ULTIMATE); }

    @Override
    protected String start(AbilityContext ctx) {
        Player p = ctx.owner();
        PlayerSession s = ctx.session();
        String busy = Kit.requireIdle(s, BladeId.VORTH, BladeId.ZYRATH);
        if (busy != null) return busy;
        World w = p.getWorld();
        double range = Math.min(ctx.cfgD("range", 16.0), plugin.cfg().d("chain.max-length", 24.0) - 6.0);
        if (Kit.around(ctx, p.getLocation().toVector(), range, 1, false).isEmpty()) return "No enemies in range.";

        BladeUnit v = s.unit(BladeId.VORTH);
        BladeUnit z = s.unit(BladeId.ZYRATH);
        Vector c = Kit.ground(w, p.getLocation().toVector().add(s.forward().multiply(3.0)));
        Vector right = s.right();
        int hold = Math.min(ctx.cfgI("hold-ticks", 60), plugin.cfg().i("restraint.max-ticks", 60));
        double liftTo = ctx.cfgD("lift-height", 5.0);
        double verdictDmg = ctx.baseDamage(18.0);
        Map<LivingEntity, Integer> left = new LinkedHashMap<>();
        Barrier boom = new Barrier(2, () -> verdict(ctx, c, left));

        Script sc = new Script().exclusive(true);
        // 1. ASCENSION
        sc.run(() -> {
            v.queue(new Motions.Arc(() -> c.clone().add(right.clone().multiply(11.0)).add(new Vector(0, 14.0, 0)), right.clone().multiply(6.0), 16, Motions.Easing.OUT));
            z.queue(new Motions.Arc(() -> c.clone().add(right.clone().multiply(-11.0)).add(new Vector(0, 14.0, 0)), right.clone().multiply(-6.0), 16, Motions.Easing.OUT));
            sc.own(s.strand(() -> v.pos.clone(), () -> z.pos.clone(), 1.18, 300, 12));
            plugin.fx().sound(w, p.getLocation().toVector(), "throne_ascend", "xarvoth:throne.ascend", 2.0f, 1.0f);
        });
        sc.waitIdle(v, z);
        // 2. JUDGEMENT SEAT
        sc.run(() -> {
            int n = 0;
            for (LivingEntity e : Kit.around(ctx, c, range, ctx.cfgI("target-limit", 10), false)) {
                int g = plugin.restraints().grant(e, hold, false);
                if (g <= 0) continue;
                left.put(e, g);
                ctx.hit(null, e, ctx.baseDamage(4.0), RavageMeter.Source.CHAIN_HIT, new Vector(0, 0.2, 0));
                ctx.gain(RavageMeter.Source.CAPTURE, e);
                BladeUnit from = n % 2 == 0 ? v : z;
                if (n++ < 8) sc.own(s.strand(() -> from.pos.clone(), () -> Kit.alive(e) ? Kit.center(e) : null, 1.04, hold + 80, 5));
            }
            plugin.fx().shockwave(w, c, 6.0, plugin.fx().energy(p));
            plugin.fx().rune(p, w, c, 10.0, 130);
            plugin.fx().sound(w, c, "throne_seat", "xarvoth:throne.seat", 2.0f, 0.9f);
        });
        int[] age = {0};
        // 2b. lift and 3. CARVING run together: the carving blades are queued once the captives are up
        sc.during(12, i -> hold(left, w, c, liftTo, i));
        sc.run(() -> {
            java.util.function.Supplier<List<LivingEntity>> targets = () -> {
                List<LivingEntity> l = new ArrayList<>();
                for (LivingEntity e : left.keySet()) if (Kit.alive(e)) l.add(e);
                return l;
            };
            for (BladeId id : BladeId.values()) {
                s.unit(id).queue(new AssaultMotion(ctx, id, targets, ctx.cfgI("strikes-per-blade", 8), ctx.baseDamage(4.0), 0, 3.4, f -> 1.0 + f * 0.7));
            }
            plugin.fx().sound(w, c, "throne_carve", "xarvoth:throne.carve", 2.0f, 1.0f);
        });
        sc.step(() -> age[0] = 0, () -> {
            int i = age[0]++;
            hold(left, w, c, liftTo, i + 12);
            if (i % 10 == 9) {
                for (LivingEntity e : left.keySet()) {
                    if (!Kit.alive(e)) continue;
                    ctx.hit(null, e, ctx.baseDamage(3.0), RavageMeter.Source.CHAIN_HIT, new Vector(0, 0.0, 0));
                    plugin.fx().spark(w, Kit.center(e), 10, 0.3);
                }
                plugin.fx().sound(w, c, "chain_hit", "xarvoth:chain.hit", 1.2f, 0.7f);
            }
            return Kit.idle(s, BladeId.VORTH, BladeId.ZYRATH).getAsBoolean();
        });
        // 4. VERDICT
        sc.run(() -> {
            v.queue(new Motions.Arc(() -> c.clone().add(right.clone().multiply(9.0)).add(new Vector(0, 1.6, 0)), new Vector(0, 3.0, 0), 8, Motions.Easing.OUT));
            z.queue(new Motions.Arc(() -> c.clone().add(right.clone().multiply(-9.0)).add(new Vector(0, 1.6, 0)), new Vector(0, 3.0, 0), 8, Motions.Easing.OUT));
        });
        sc.waitIdle(v, z);
        sc.run(() -> {
            for (BladeId id : BladeId.values()) {
                double sg = id.side;
                s.unit(id).queue(new Motions.Arc(() -> c.clone().add(right.clone().multiply(-9.0 * sg)).add(new Vector(0, 1.6, 0)), Kit.ZERO.clone(), 7, Motions.Easing.IN)
                        .hook(Kit.cut(ctx, id, new Hitbook(), verdictDmg, 14, 3.2))
                        .then(boom::arrive));
            }
            plugin.fx().sound(w, c, "throne_verdict", "xarvoth:throne.verdict", 2.0f, 1.0f);
        });
        sc.waitIdle(v, z);
        sc.onEnd(() -> { v.clearMotions(); z.clearMotions(); });
        return Kit.begin(ctx, sc);
    }

    /** Keep captives suspended under the arch while their granted ticks last. */
    private void hold(Map<LivingEntity, Integer> left, World w, Vector c, double liftTo, int i) {
        for (Map.Entry<LivingEntity, Integer> en : left.entrySet()) {
            LivingEntity e = en.getKey();
            if (!Kit.alive(e) || en.getValue() <= 0) continue;
            en.setValue(en.getValue() - 1);
            Vector g = Kit.ground(w, e.getLocation().toVector());
            double vy = Math.max(-0.5, Math.min(0.8, (g.getY() + liftTo - e.getLocation().getY()) * 0.35));
            Vector lateral = c.clone().subtract(e.getLocation().toVector()).setY(0).multiply(0.05);
            e.setVelocity(new Vector(lateral.getX(), vy, lateral.getZ()));
            e.setFallDistance(0);
        }
    }

    private void verdict(AbilityContext ctx, Vector c, Map<LivingEntity, Integer> captives) {
        Player p = ctx.owner();
        if (!p.isOnline()) return;
        World w = p.getWorld();
        for (LivingEntity e : captives.keySet()) if (Kit.alive(e)) e.setVelocity(new Vector(0, -1.6, 0));
        double radius = ctx.cfgD("verdict-radius", 9.0);
        Kit.impact(ctx, BladeId.VORTH, c, radius, ctx.baseDamage(30.0), 14, 1.2, 0.9);
        plugin.fx().shockwave(w, c, radius, plugin.fx().energy(p));
        plugin.fx().ring(w, c, radius * 0.6, 40, plugin.fx().energy(p));
        for (int i = 0; i < 8; i++) {
            double a = i * Math.PI / 4;
            w.strikeLightningEffect(new Location(w, c.getX() + Math.cos(a) * radius * 0.6, c.getY(), c.getZ() + Math.sin(a) * radius * 0.6));
        }
        plugin.fx().beam(p, w, c, 22.0, 4.2, 20);
        plugin.fx().sound(w, c, "throne_end", "xarvoth:throne.end", 2.2f, 0.8f);
    }
}

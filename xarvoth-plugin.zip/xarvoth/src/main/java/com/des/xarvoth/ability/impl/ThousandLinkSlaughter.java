package com.des.xarvoth.ability.impl;

import com.des.xarvoth.RavageMeter;
import com.des.xarvoth.XarvothPlugin;
import com.des.xarvoth.ability.AbilityCategory;
import com.des.xarvoth.ability.AbilityContext;
import com.des.xarvoth.blade.BladeId;
import com.des.xarvoth.blade.BladeUnit;
import com.des.xarvoth.blade.ChainStrand;
import com.des.xarvoth.blade.Hitbook;
import com.des.xarvoth.blade.Motions;
import com.des.xarvoth.blade.PlayerSession;
import com.des.xarvoth.blade.Script;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * CONVERGENCE 3 - THOUSAND-LINK SLAUGHTER. The blades fly independent, opposing orbits over the aimed ground, one low and heavy,
 * one high and fast. Three free chains are laid across the field - blade to blade, and each blade to the centre - so the
 * pattern is a moving web of chain. The blades cut where they fly, and the chain webs cut where they cross: damage comes from the
 * chain bodies as well as the steel.
 */
public final class ThousandLinkSlaughter extends BaseAbility {
    public ThousandLinkSlaughter(XarvothPlugin plugin) { super(plugin, "thousand_link_slaughter", "THOUSAND-LINK SLAUGHTER", AbilityCategory.CONVERGENCE); }

    @Override
    protected String start(AbilityContext ctx) {
        Player p = ctx.owner();
        PlayerSession s = ctx.session();
        String busy = Kit.requireIdle(s, BladeId.VORTH, BladeId.ZYRATH);
        if (busy != null) return busy;
        World w = p.getWorld();
        double range = Math.min(ctx.cfgD("range", 16.0), plugin.cfg().d("chain.max-length", 24.0) - 8.0);
        Vector c = Kit.aimGround(ctx, range);
        if (Kit.around(ctx, c, 11.0, 1, false).isEmpty()) return "No targets near that point.";

        BladeUnit v = s.unit(BladeId.VORTH);
        BladeUnit z = s.unit(BladeId.ZYRATH);
        int total = 60;
        double dmg = ctx.baseDamage(5.0);
        double chainDmg = ctx.baseDamage(2.2);
        Map<UUID, Integer> next = new HashMap<>();
        Map<UUID, Integer> count = new HashMap<>();
        List<ChainStrand> web = new ArrayList<>();

        Script sc = new Script().exclusive(true);
        sc.run(() -> {
            for (int seg = 0; seg < 3; seg++) {
                final int off = seg * 20;
                v.queue(new Motions.Path(i -> orbit(c, BladeId.VORTH, off + i, total), 20, 0.45).hook(Kit.cut(ctx, BladeId.VORTH, new Hitbook(), dmg, 8, 1.2)));
                z.queue(new Motions.Path(i -> orbit(c, BladeId.ZYRATH, off + i, total), 20, 0.5).hook(Kit.cut(ctx, BladeId.ZYRATH, new Hitbook(), dmg, 8, 1.2)));
            }
            web.add(sc.own(s.strand(() -> v.pos.clone(), () -> z.pos.clone(), 1.1, total + 30, 7)));
            web.add(sc.own(s.strand(() -> v.pos.clone(), () -> c.clone().add(new Vector(0, 0.3, 0)), 1.05, total + 30, 6)));
            web.add(sc.own(s.strand(() -> z.pos.clone(), () -> c.clone().add(new Vector(0, 0.3, 0)), 1.05, total + 30, 6)));
            plugin.fx().sound(w, p.getLocation().toVector(), "thousand_start", "xarvoth:thousand.start", 1.4f, 1.0f);
        });
        sc.during(total + 4, i -> {
            if (i % 2 != 0) return;
            for (ChainStrand st : web) {
                for (LivingEntity e : st.sweep(0.9)) {
                    if (!plugin.damage().canTarget(p, e)) continue;
                    UUID id = e.getUniqueId();
                    if (count.getOrDefault(id, 0) >= 6 || i < next.getOrDefault(id, 0)) continue;
                    next.put(id, i + 8);
                    if (ctx.hit(null, e, chainDmg, RavageMeter.Source.CHAIN_HIT, Kit.kb(c, e.getLocation().toVector(), 0.4, 0.25))) {
                        count.merge(id, 1, Integer::sum);
                        plugin.fx().spark(w, Kit.center(e), 8, 0.25);
                        plugin.fx().sound(w, Kit.center(e), "chain_hit", "xarvoth:chain.hit", 0.7f, 1.2f);
                    }
                }
            }
        });
        sc.waitIdle(v, z);
        sc.run(() -> {
            plugin.fx().shockwave(w, c, 5.0, plugin.fx().energy(p));
            plugin.fx().sound(w, c, "thousand_end", "xarvoth:thousand.end", 1.4f, 0.9f);
        });
        sc.onEnd(() -> { v.clearMotions(); z.clearMotions(); });
        return Kit.begin(ctx, sc);
    }

    /** Opposing orbits: VORTH low, wide and clockwise; ZYRATH high, tighter and counter-clockwise. */
    private Vector orbit(Vector c, BladeId id, int i, int total) {
        double f = i / (double) total;
        boolean v = id == BladeId.VORTH;
        double ang = f * Math.PI * 2 * 1.5 * (v ? 1 : -1) + (v ? 0 : Math.PI);
        double r = (v ? 8.0 : 6.0) + Math.sin(f * Math.PI * 4) * 1.5;
        double h = (v ? 1.4 : 3.0) + Math.sin(i * 0.3) * 0.6;
        return c.clone().add(new Vector(Math.cos(ang) * r, h, Math.sin(ang) * r));
    }
}

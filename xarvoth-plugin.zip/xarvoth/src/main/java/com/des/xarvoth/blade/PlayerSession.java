package com.des.xarvoth.blade;

import com.des.xarvoth.Models;
import com.des.xarvoth.XarvothPlugin;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.Iterator;
import java.util.List;
import java.util.function.Supplier;

/**
 * Everything XARVOTH has in the world for one wielder: two blades, their chains, free chain strands and running effects.
 * One object owns all of it, so one call (interrupt / destroy) can always clean the whole lot up.
 */
public final class PlayerSession {
    private final XarvothPlugin plugin;
    private final Player owner;
    private final EnumMap<BladeId, BladeUnit> units = new EnumMap<>(BladeId.class);
    private final List<Effect> effects = new ArrayList<>();
    private final List<ChainStrand> strands = new ArrayList<>();
    private boolean visible;
    private boolean holding;
    private boolean empowered;

    PlayerSession(XarvothPlugin plugin, Player owner) {
        this.plugin = plugin;
        this.owner = owner;
        for (BladeId id : BladeId.values()) units.put(id, new BladeUnit(plugin, this, id));
    }

    public XarvothPlugin plugin() { return plugin; }
    public Player owner() { return owner; }
    public BladeUnit unit(BladeId id) { return units.get(id); }
    public boolean isHolding() { return holding; }
    void setHolding(boolean h) { holding = h; }
    public boolean isVisible() { return visible; }
    public boolean empowered() { return empowered; }

    void show() {
        if (visible) return;
        visible = true;
        empowered = plugin.meter().isEmpowered(owner);
        syncHeldModel();
        for (BladeUnit u : units.values()) u.spawn();
    }

    void hide() {
        visible = false;
        interrupt();
        for (BladeUnit u : units.values()) u.despawn();
    }

    void destroy() { hide(); }

    // ---------------------------------------------------------------- effects

    /** @return false if the wielder already has the maximum number of effects running. */
    public boolean addEffect(Effect e) {
        if (effects.size() >= plugin.cfg().i("performance.max-effects-per-player", 6)) return false;
        e.bind(this);
        effects.add(e);
        try {
            e.onStart();
        } catch (RuntimeException ex) {
            plugin.getLogger().warning("Effect start failed: " + ex);
            effects.remove(e);
            safeCancel(e);
            return false;
        }
        return true;
    }

    public boolean hasExclusive() {
        for (Effect e : effects) if (e.exclusive()) return true;
        return false;
    }

    public <T extends Effect> T effect(Class<T> type) {
        for (Effect e : effects) if (type.isInstance(e)) return type.cast(e);
        return null;
    }

    private void safeCancel(Effect e) {
        try { e.onCancel(); } catch (RuntimeException ex) { plugin.getLogger().warning("Effect cancel failed: " + ex); }
    }

    /** Called by DamageService after the wielder lands damage; lets effects react (Abyssal Network shares it). */
    public void afterHit(LivingEntity victim, double amount) {
        for (Effect e : new ArrayList<>(effects)) e.onHit(victim, amount);
    }

    /** Damage is about to hit the wielder: effects (Unbreakable Reprisal) may consume it. */
    public boolean interceptIncoming(EntityDamageByEntityEvent ev) {
        for (Effect e : new ArrayList<>(effects)) if (e.onIncoming(ev)) return true;
        return false;
    }

    // ---------------------------------------------------------------- strands

    public int liveLinks() {
        int n = 0;
        for (BladeUnit u : units.values()) n += u.linkCount();
        for (ChainStrand s : strands) n += s.linkCount();
        return n;
    }

    /**
     * Creates a free chain. It is drawn only while the wielder is inside the display budget; otherwise it is a "ghost"
     * strand that still exists for hit detection. Always auto-closes after maxTicks.
     */
    public ChainStrand strand(Supplier<Vector> from, Supplier<Vector> to, double slack, int maxTicks) {
        return strand(from, to, slack, maxTicks, plugin.cfg().i("chain.strand-nodes", 7));
    }

    public ChainStrand strand(Supplier<Vector> from, Supplier<Vector> to, double slack, int maxTicks, int nodes) {
        int budget = plugin.cfg().i("performance.max-displays-per-player", 110);
        int maxStrands = plugin.cfg().i("performance.max-strands-per-player", 24);
        boolean draw = strands.size() < maxStrands && liveLinks() + (nodes - 1) <= budget;
        ChainStrand s = new ChainStrand(plugin, this, from, to, slack, maxTicks, nodes, draw);
        strands.add(s);
        return s;
    }

    // ---------------------------------------------------------------- tick

    void tick(int tick) {
        if (!visible) return;
        boolean emp = plugin.meter().isEmpowered(owner);
        if (emp != empowered) {
            empowered = emp;
            syncHeldModel();
            for (BladeUnit u : units.values()) u.refreshModel();
            for (ChainStrand s : strands) s.refreshModel();
        }

        Iterator<Effect> it = effects.iterator();
        while (it.hasNext()) {
            Effect e = it.next();
            e.age++;
            boolean done;
            try {
                done = e.tick(e.age);
            } catch (RuntimeException ex) {
                plugin.getLogger().warning("Effect failed, cancelling it: " + ex);
                it.remove();
                safeCancel(e);
                continue;
            }
            if (done) {
                it.remove();
                try { e.onFinish(); } catch (RuntimeException ex) { plugin.getLogger().warning("Effect finish failed: " + ex); }
            }
        }

        for (BladeUnit u : units.values()) u.tick(tick);

        Iterator<ChainStrand> si = strands.iterator();
        while (si.hasNext()) {
            ChainStrand s = si.next();
            s.tick();
            if (s.isClosed()) si.remove();
        }
    }

    public boolean anyOut() {
        for (BladeUnit u : units.values()) if (u.isOut()) return true;
        return !effects.isEmpty() || !strands.isEmpty();
    }

    /** Cancels every motion, effect and strand. Blades swing back to the hips on their own. */
    public void interrupt() {
        List<Effect> copy = new ArrayList<>(effects);
        effects.clear();
        for (Effect e : copy) safeCancel(e);
        for (BladeUnit u : units.values()) u.clearMotions();
        for (ChainStrand s : new ArrayList<>(strands)) s.close();
        strands.clear();
    }

    /** Instantly puts the blades back on the hips (long teleports). */
    public void snapAll() {
        interrupt();
        for (BladeUnit u : units.values()) u.snapToHolster();
    }

    private void syncHeldModel() {
        ItemStack it = owner.getInventory().getItemInMainHand();
        if (!plugin.ownership().validate(it, owner)) return;
        ItemMeta m = it.getItemMeta();
        m.setItemModel(Models.weaponKey(plugin, empowered));
        it.setItemMeta(m);
        owner.getInventory().setItemInMainHand(it);
    }

    // ---------------------------------------------------------------- geometry (yaw-based so it never goes NaN looking up/down)

    public Vector forward() {
        double y = Math.toRadians(owner.getLocation().getYaw());
        return new Vector(-Math.sin(y), 0, Math.cos(y));
    }

    public Vector right() {
        double y = Math.toRadians(owner.getLocation().getYaw());
        return new Vector(-Math.cos(y), 0, -Math.sin(y));
    }

    /** Where a resting blade hovers: at its hip, with a slow idle bob. */
    public Vector holster(BladeId id, int tick) {
        double bob = Math.sin(tick * 0.12 + (id.side > 0 ? 0.0 : 2.1)) * 0.05;
        return owner.getLocation().toVector()
                .add(new Vector(0, 1.3 + bob, 0))
                .add(right().multiply(0.6 * id.side))
                .subtract(forward().multiply(0.25));
    }

    /** Where this blade's chain is held: the wielder's hand on that side. */
    public Vector handAnchor(BladeId id) {
        return owner.getLocation().toVector()
                .add(new Vector(0, owner.isSneaking() ? 1.0 : 1.15, 0))
                .add(right().multiply(0.42 * id.side))
                .add(forward().multiply(0.3));
    }
}

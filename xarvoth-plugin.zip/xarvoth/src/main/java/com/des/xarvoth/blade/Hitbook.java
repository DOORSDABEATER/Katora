package com.des.xarvoth.blade;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** Records who a blade pass has already struck so one pass can never damage the same target twice. */
public final class Hitbook {
    private final Set<UUID> seen = new HashSet<>();

    /** @return true the first time this id is seen. */
    public boolean first(UUID id) { return seen.add(id); }

    public boolean has(UUID id) { return seen.contains(id); }

    public int size() { return seen.size(); }
}

package com.des.xarvoth.ability;

public enum AbilityCategory {
    BLADE("BLADE"),
    CHAIN("CHAIN"),
    CONVERGENCE("CONVERGENCE"),
    ULTIMATE("ULTIMATE");

    private final String label;

    AbilityCategory(String label) { this.label = label; }

    public String label() { return label; }
}

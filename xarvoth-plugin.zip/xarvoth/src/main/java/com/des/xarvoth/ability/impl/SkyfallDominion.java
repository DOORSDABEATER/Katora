package com.des.xarvoth.ability.impl;

import com.des.xarvoth.RavageMeter;
import com.des.xarvoth.XarvothPlugin;
import com.des.xarvoth.ability.AbilityCategory;
import com.des.xarvoth.ability.AbilityContext;
import com.des.xarvoth.blade.Barrier;
import com.des.xarvoth.blade.BladeId;
import com.des.xarvoth.blade.BladeUnit;
import com.des.xarvoth.blade.Motions;
import com.des.xarvoth.blade.PlayerSession;
import com.des.xarvoth.blade.Script;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.List;

/**
 * CONVERGENCE 5 - SKYFALL DOMINION. The blades are flung up and apart over the target ground and hang there. Eight chains fall
 * from them to a ring on the ground, a dome of chain that pulses damage, slows and drags in everything under it. Then the chains
 * go slack as both blades plunge to the centre together; the impact is huge, and the retracting chains haul every survivor in.
 */
public final class SkyfallDominion extends BaseAbility {
    public SkyfallDominion(XarvothPlugin plugin) { super(plugin, "skyfall_dominion", "SKYFALL DOMINION", AbilityCategory.CONVERGENCE); }

    @Override
    protected String start(AbilityContext ctx) {
        Player p = ctx.owner();
        PlayerSession s = ctx.session();
        String busy = Kit.requireIdle(s, BladeId.VORTH, BladeId.ZYRATH);
        if (busy != null) return busy;
        World w = p.getWorld();
        double range = Math.min(ctx.cfgD("range", 16.0), plugin.cfg().d("chain.max-length", 24.0) - 10.0);
        Vector c = Kit.aimGround(ctx, range);
        double zone = ctx.cfgD("zone-radius", 6.0);
        if (Kit.around(ctx, c, zone + 2.0, 1, false).isEmpty()) return "No targets near that point.";

        Vector right = s.right();
        BladeUnit v = s.unit(BladeId.VORTH);
        BladeUnit z = s.unit(BladeId.ZYRATH);
        double height = ctx.cfgD("height", 12.0);
        double chainDmg = ctx.baseDamage(2.8);
        Barrier slam = new Barrier(2, () -> impact(ctx, c, zone));

        Script sc = new Script().exclusive(true);
        sc.run(() -> {
            v.queue(new Motions.Arc(() -> c.clone().add(right.clone().multiply(5.0)).add(new Vector(0, height, 0)), right.clone().multiply(3.0), 12, Motions.Easing.OUT));
            z.queue(new Motions.Arc(() -> c.clone().add(right.clone().multiply(-5.0)).add(new Vector(0, height, 0)), right.clone().multiply(-3.0), 11, Motions.Easing.OUT));
            plugin.fx().sound(w, p.getLocation().toVector(), "skyfall_launch", "xarvoth:skyfall.launch", 1.4f, 1.0f);
        });
        sc.waitIdle(v, z);
        sc.run(() -> {
            for (BladeUnit u : new BladeUnit[]{v, z}) {
                for (int k = 0; k < 4; k++) {
                    double a = Math.PI * 2 * (k + (u == v ? 0 : 0.5)) / 4;
                    Vector post = Kit.ground(w, c.clone().add(new Vector(Math.cos(a) * (zone - 0.5), 0, Math.sin(a) * (zone - 0.5))));
                    sc.own(s.strand(() -> u.pos.clone(), () -> post, 1.05, 110, 4));
                }
            }
            plugin.fx().rune(p, w, c, zone, 46);
            plugin.fx().sound(w, c, "skyfall_dome", "xarvoth:skyfall.dome", 1.4f, 0.9f);
        });
        sc.during(40, i -> {
            if (i % 5 == 0) plugin.fx().ring(w, c, zone - 0.3, 36, plugin.fx().energy(p));
            for (LivingEntity e : Kit.around(ctx, c, zone, 8, false)) {
                Kit.pull(e, c, 0.3);
                if (i % 10 == 9) {
                    ctx.hit(null, e, chainDmg, RavageMeter.Source.CHAIN_HIT, null);
                    plugin.restraints().slow(e, 24, 1);
                    plugin.fx().spark(w, Kit.center(e), 10, 0.3);
                }
            }
        });
        sc.run(() -> {
            v.queue(new Motions.Arc(() -> c.clone().add(new Vector(0, 0.5, 0)), Kit.ZERO.clone(), 6, Motions.Easing.IN).then(slam::arrive));
            z.queue(new Motions.Arc(() -> c.clone().add(new Vector(0, 0.5, 0)), Kit.ZERO.clone(), 6, Motions.Easing.IN).then(slam::arrive));
        });
        sc.waitIdle(v, z);
        sc.during(6, i -> {
            for (LivingEntity e : Kit.around(ctx, c, zone + 3.0, 10, false)) Kit.pull(e, c, 1.0);
        });
        sc.onEnd(() -> { v.clearMotions(); z.clearMotions(); });
        return Kit.begin(ctx, sc);
    }

    private void impact(AbilityContext ctx, Vector c, double zone) {
        Player p = ctx.owner();
        if (!p.isOnline()) return;
        List<LivingEntity> hit = Kit.impact(ctx, BladeId.VORTH, c, zone + 0.5, ctx.baseDamage(22.0), 10, 0.5, 0.5);
        for (LivingEntity e : hit) ctx.gain(RavageMeter.Source.PULL, e);
        plugin.fx().shockwave(p.getWorld(), c, zone, plugin.fx().energy(p));
        plugin.fx().beam(p, p.getWorld(), c, 14.0, 1.8, 10);
        plugin.fx().sound(p.getWorld(), c, "skyfall_impact", "xarvoth:skyfall.impact", 1.8f, 0.8f);
    }
}

package com.des.xarvoth.ability.impl;

import com.des.xarvoth.RavageMeter;
import com.des.xarvoth.XarvothPlugin;
import com.des.xarvoth.ability.Ability;
import com.des.xarvoth.ability.AbilityCategory;
import com.des.xarvoth.ability.AbilityContext;
import com.des.xarvoth.blade.BladeId;
import com.des.xarvoth.blade.BladeUnit;
import com.des.xarvoth.blade.Hitbook;
import com.des.xarvoth.blade.Motions;
import com.des.xarvoth.blade.PlayerSession;
import org.bukkit.Color;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

/**
 * BLADE AUTHORITY 5 - RETURN TO RUIN.
 * Both blades are flung out on opposite wide arcs, cutting through everything on the way (they stop dead on solid blocks),
 * then swing back on crossing arcs that cut a second time. Each pass has its own hit list, so a target can be struck on the
 * way out and again on the way home, but never twice in one pass. The chains stay attached the entire time.
 */
public final class ReturnToRuin implements Ability {
    public static final String ID = "return_to_ruin";
    private final XarvothPlugin plugin;

    public ReturnToRuin(XarvothPlugin plugin) { this.plugin = plugin; }

    @Override public String id() { return ID; }
    @Override public String displayName() { return "RETURN TO RUIN"; }
    @Override public AbilityCategory category() { return AbilityCategory.BLADE; }

    @Override
    public String activate(AbilityContext ctx) {
        Player p = ctx.owner();
        PlayerSession s = ctx.session();
        BladeUnit v = s.unit(BladeId.VORTH);
        BladeUnit z = s.unit(BladeId.ZYRATH);
        if (v.isBusy() || z.isBusy()) return "Both blades must be at hand.";

        double maxLen = plugin.cfg().d("chain.max-length", 24.0);
        double range = Math.min(ctx.cfgD("range", 20.0), maxLen - 4.0);
        int limit = ctx.cfgI("target-limit", 6);
        double dmg = ctx.baseDamage(6.0);
        Vector eye = p.getEyeLocation().toVector();
        Vector dir = p.getEyeLocation().getDirection();
        Vector right = s.right();

        for (BladeId id : BladeId.values()) {
            BladeUnit u = s.unit(id);
            double side = id.side;                              // VORTH sweeps out right, ZYRATH out left
            Vector end = eye.clone().add(dir.clone().multiply(range)).add(right.clone().multiply(side * 3.5));
            Vector bulgeOut = right.clone().multiply(side * 6.0);
            Vector bulgeBack = right.clone().multiply(-side * 6.0);
            int outTicks = id == BladeId.VORTH ? 16 : 12;       // the heavy blade is slower
            int backTicks = id == BladeId.VORTH ? 15 : 11;

            u.queue(new Motions.Arc(() -> end, bulgeOut, outTicks, Motions.Easing.OUT)
                    .stopOnBlock()
                    .hook(hook(ctx, id, new Hitbook(), dmg, limit)));
            u.queue(new Motions.Arc(() -> s.holster(id, org.bukkit.Bukkit.getCurrentTick()), bulgeBack, backTicks, Motions.Easing.IN_OUT)
                    .hook(hook(ctx, id, new Hitbook(), dmg, limit))
                    .then(() -> plugin.fx().sound(p.getWorld(), u.pos, "ruin_return", "minecraft:item.trident.return", 0.8f, id == BladeId.VORTH ? 0.7f : 1.3f)));
        }
        plugin.fx().sound(p.getWorld(), eye, "ruin_launch", "minecraft:item.trident.throw", 1.2f, 0.7f);
        return null;
    }

    private Motions.Hook hook(AbilityContext ctx, BladeId id, Hitbook book, double dmg, int limit) {
        return (u, t) -> {
            Player p = ctx.owner();
            Color col = plugin.fx().energy(p);
            plugin.fx().dust(p.getWorld(), u.pos, 2, 0.1, id == BladeId.VORTH ? 1.7f : 1.1f, col);
            for (LivingEntity victim : u.sweep(id.hitRadius)) {
                if (!plugin.damage().canTarget(p, victim)) continue;
                if (book.size() >= limit && !book.has(victim.getUniqueId())) continue;
                if (!book.first(victim.getUniqueId())) continue;
                Vector kb = u.pos.clone().subtract(u.prev);
                kb = kb.lengthSquared() > 1e-4 ? kb.normalize().multiply(0.7) : new Vector(0, 0, 0);
                kb.setY(0.3);
                if (ctx.hit(id, victim, dmg * id.damageMul, RavageMeter.Source.BLADE_HIT, kb)) {
                    plugin.fx().slash(p.getWorld(), victim.getBoundingBox().getCenter(), u.pos.clone().subtract(u.prev), 2.0, col);
                    plugin.fx().sound(p.getWorld(), u.pos, "zyrath_hit", "minecraft:entity.player.attack.crit", 0.8f, id == BladeId.VORTH ? 0.7f : 1.3f);
                }
            }
        };
    }
}

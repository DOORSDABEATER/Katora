package com.des.xarvoth.blade;

/** The two sentient blades. Their numbers are what make them feel different in the world. */
public enum BladeId {
    //     key       side  scale  dmgMul  hitRadius  spin
    VORTH("vorth",   +1,   2.30f, 1.25,   1.35,      0.30f),   // heavy, brutal, slow, wide
    ZYRATH("zyrath", -1,   1.90f, 0.90,   1.05,      0.85f);   // fast, sharp, predatory

    public final String key;
    public final int side;          // +1 = wielder's right, -1 = left
    public final float scale;
    public final double damageMul;
    public final double hitRadius;
    public final float spin;

    BladeId(String key, int side, float scale, double damageMul, double hitRadius, float spin) {
        this.key = key;
        this.side = side;
        this.scale = scale;
        this.damageMul = damageMul;
        this.hitRadius = hitRadius;
        this.spin = spin;
    }
}

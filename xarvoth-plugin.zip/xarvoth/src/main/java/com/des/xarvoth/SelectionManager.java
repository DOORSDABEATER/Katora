package com.des.xarvoth;

import com.des.xarvoth.ability.Ability;
import com.des.xarvoth.ability.AbilityCategory;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Selection model: F cycles the authority (Blade / Chain / Convergence / Ultimate), sneak + scroll cycles the ability inside it.
 * Authorities with nothing installed are skipped, so the player is never offered an ability that does not exist.
 * The selection is remembered per player across relogs.
 */
public final class SelectionManager {
    private final XarvothPlugin plugin;
    private final Map<UUID, String> selected = new HashMap<>();
    private final NamespacedKey key;

    public SelectionManager(XarvothPlugin plugin) {
        this.plugin = plugin;
        this.key = new NamespacedKey(plugin, "selected");
    }

    private Ability first() {
        List<AbilityCategory> cats = plugin.registry().activeCategories();
        return cats.isEmpty() ? null : plugin.registry().byCategory(cats.get(0)).get(0);
    }

    public Ability selected(Player p) {
        Ability a = plugin.registry().get(selected.get(p.getUniqueId()));
        if (a == null) {
            a = first();
            if (a != null) selected.put(p.getUniqueId(), a.id());
        }
        return a;
    }

    public Ability cycleCategory(Player p) {
        Ability cur = selected(p);
        List<AbilityCategory> cats = plugin.registry().activeCategories();
        if (cats.isEmpty()) return null;
        int idx = cur == null ? -1 : cats.indexOf(cur.category());
        AbilityCategory next = cats.get(Math.floorMod(idx + 1, cats.size()));
        Ability a = plugin.registry().byCategory(next).get(0);
        selected.put(p.getUniqueId(), a.id());
        return a;
    }

    public Ability cycleAbility(Player p, int delta) {
        Ability cur = selected(p);
        if (cur == null) return null;
        List<Ability> list = plugin.registry().byCategory(cur.category());
        int i = Math.floorMod(list.indexOf(cur) + delta, list.size());
        Ability a = list.get(i);
        selected.put(p.getUniqueId(), a.id());
        return a;
    }

    public void load(Player p) {
        String id = p.getPersistentDataContainer().get(key, PersistentDataType.STRING);
        if (id != null && plugin.registry().get(id) != null) selected.put(p.getUniqueId(), id);
    }

    public void save(Player p) {
        String id = selected.get(p.getUniqueId());
        if (id != null) p.getPersistentDataContainer().set(key, PersistentDataType.STRING, id);
    }

    public void forget(UUID id) { selected.remove(id); }
}

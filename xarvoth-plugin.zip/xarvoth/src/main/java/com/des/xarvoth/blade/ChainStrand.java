package com.des.xarvoth.blade;

import com.des.xarvoth.Models;
import com.des.xarvoth.XarvothPlugin;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * A free chain between two moving points (hand, blade, entity, ground anchor). Same Verlet rope as the blade chains,
 * rendered as pooled link displays. It has a hard lifetime (maxTicks) so it can never leak, and a damage sweep along its
 * whole body, which is what lets chain abilities hurt things with the chain itself. If the wielder's display budget is
 * used up the strand still exists and still sweeps, it just isn't drawn.
 */
public final class ChainStrand {
    private final XarvothPlugin plugin;
    private final PlayerSession session;
    private final Supplier<Vector> from;
    private final Supplier<Vector> to;
    private final Rope rope;
    private final List<ItemDisplay> links = new ArrayList<>();
    private final double slack;
    private final boolean render;
    private int ttl;
    private boolean closed;

    ChainStrand(XarvothPlugin plugin, PlayerSession session, Supplier<Vector> from, Supplier<Vector> to,
                double slack, int maxTicks, int nodes, boolean render) {
        this.plugin = plugin;
        this.session = session;
        this.from = from;
        this.to = to;
        this.slack = slack;
        this.ttl = maxTicks;
        this.rope = new Rope(Math.max(3, Math.min(16, nodes)));
        this.render = render;
    }

    public boolean isClosed() { return closed; }
    public int linkCount() { return links.size(); }

    void tick() {
        if (closed) return;
        if (--ttl < 0 || !session.owner().isValid()) { close(); return; }
        Vector a = from.get();
        Vector b = to.get();
        if (a == null || b == null) { close(); return; }
        rope.step(a, b, plugin.cfg().d("chain.gravity", 0.035), plugin.cfg().d("chain.damping", 0.96),
                plugin.cfg().i("chain.iterations", 4), slack);
        if (render) renderLinks();
    }

    private void renderLinks() {
        World w = session.owner().getWorld();
        int count = rope.n - 1;
        float scale = (float) plugin.cfg().d("chain.link-scale", 0.45);
        while (links.size() < count) {
            links.add(plugin.blades().spawnDisplay(w, rope.p[links.size()], Models.chain(plugin, session.empowered())));
        }
        for (int i = 0; i < count; i++) {
            Vector a = rope.p[i], b = rope.p[i + 1];
            double dx = b.getX() - a.getX(), dy = b.getY() - a.getY(), dz = b.getZ() - a.getZ();
            double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (len < 1e-4) continue;
            Quaternionf q = new Quaternionf().rotationTo(0f, 1f, 0f, (float) (dx / len), (float) (dy / len), (float) (dz / len));
            if (i % 2 == 1) q.rotateY((float) (Math.PI / 2));
            ItemDisplay link = links.get(i);
            link.teleport(new Location(w, (a.getX() + b.getX()) / 2, (a.getY() + b.getY()) / 2, (a.getZ() + b.getZ()) / 2));
            link.setInterpolationDelay(0);
            link.setTransformation(new Transformation(new Vector3f(0, 0, 0), q, new Vector3f(scale, (float) (len * 1.1), scale), new Quaternionf()));
        }
    }

    void refreshModel() {
        for (ItemDisplay l : links) l.setItemStack(Models.chain(plugin, session.empowered()));
    }

    public void close() {
        if (closed) return;
        closed = true;
        for (ItemDisplay l : links) plugin.blades().despawnDisplay(l);
        links.clear();
    }

    /** Living entities (except the wielder) touching any segment of the chain body. */
    public List<LivingEntity> sweep(double r) {
        List<LivingEntity> out = new ArrayList<>();
        if (closed) return out;
        World w = session.owner().getWorld();
        double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, minZ = Double.MAX_VALUE;
        double maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE, maxZ = -Double.MAX_VALUE;
        for (Vector v : rope.p) {
            minX = Math.min(minX, v.getX()); maxX = Math.max(maxX, v.getX());
            minY = Math.min(minY, v.getY()); maxY = Math.max(maxY, v.getY());
            minZ = Math.min(minZ, v.getZ()); maxZ = Math.max(maxZ, v.getZ());
        }
        BoundingBox area = new BoundingBox(minX, minY, minZ, maxX, maxY, maxZ).expand(r + 0.6);
        UUID ownerId = session.owner().getUniqueId();
        for (Entity e : w.getNearbyEntities(area, en -> en instanceof LivingEntity && !en.getUniqueId().equals(ownerId))) {
            BoundingBox eb = e.getBoundingBox().expand(r);
            for (int i = 0; i < rope.n - 1; i++) {
                Vector a = rope.p[i], b = rope.p[i + 1];
                Vector d = b.clone().subtract(a);
                double len = d.length();
                if (eb.contains(a) || eb.contains(b) || (len > 1e-6 && eb.rayTrace(a, d.multiply(1.0 / len), len) != null)) {
                    out.add((LivingEntity) e);
                    break;
                }
            }
        }
        return out;
    }
}

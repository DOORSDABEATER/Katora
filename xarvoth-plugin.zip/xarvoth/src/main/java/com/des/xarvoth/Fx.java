package com.des.xarvoth;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

/**
 * Particle and sound helpers. Every sound goes through config (sounds.*) so the resource pack's custom sound events
 * can be dropped in later without touching code. Colors follow the XARVOTH palette: electric blue, blue-white when empowered.
 */
public final class Fx {
    public static final Color BLUE = Color.fromRGB(40, 140, 255);
    public static final Color WHITE_BLUE = Color.fromRGB(205, 235, 255);
    public static final Color SILVER = Color.fromRGB(200, 205, 215);

    private final XarvothPlugin plugin;

    public Fx(XarvothPlugin plugin) { this.plugin = plugin; }

    public Color energy(Player p) { return plugin.meter().isEmpowered(p) ? WHITE_BLUE : BLUE; }

    public void dust(World w, Vector at, int count, double spread, float size, Color c) {
        w.spawnParticle(Particle.DUST, at.getX(), at.getY(), at.getZ(), count, spread, spread, spread, 0, new Particle.DustOptions(c, size));
    }

    public void spark(World w, Vector at, int count, double spread) {
        w.spawnParticle(Particle.ELECTRIC_SPARK, at.getX(), at.getY(), at.getZ(), count, spread, spread, spread, 0.15);
    }

    public void ring(World w, Vector center, double radius, int points, Color c) {
        for (int i = 0; i < points; i++) {
            double a = (Math.PI * 2 * i) / points;
            w.spawnParticle(Particle.DUST, center.getX() + Math.cos(a) * radius, center.getY() + 0.15, center.getZ() + Math.sin(a) * radius,
                    1, 0, 0, 0, 0, new Particle.DustOptions(c, 1.4f));
        }
    }

    /** A curved slash drawn through {@code center} along {@code dir}. */
    public void slash(World w, Vector center, Vector dir, double length, Color c) {
        Vector d = dir.lengthSquared() < 1e-6 ? new Vector(0, 0, 1) : dir.clone().normalize();
        Vector side = d.clone().crossProduct(new Vector(0, 1, 0));
        if (side.lengthSquared() < 1e-4) side = new Vector(1, 0, 0);
        side.normalize();
        int pts = 10;
        for (int i = 0; i < pts; i++) {
            double k = i / (double) (pts - 1) - 0.5;
            Vector p = center.clone().add(d.clone().multiply(k * length)).add(side.clone().multiply((0.25 - k * k) * length * 0.8));
            w.spawnParticle(Particle.DUST, p.getX(), p.getY(), p.getZ(), 1, 0.02, 0.02, 0.02, 0, new Particle.DustOptions(c, 1.2f));
            if (i % 3 == 0) w.spawnParticle(Particle.CRIT, p.getX(), p.getY(), p.getZ(), 1, 0.05, 0.05, 0.05, 0.1);
        }
        plugin.vfx().slash(w, center, d, length * 0.7, c.equals(WHITE_BLUE));
    }

    public void shockwave(World w, Vector c, double radius, Color col) {
        ring(w, c, radius * 0.35, 18, col);
        ring(w, c, radius * 0.7, 30, col);
        ring(w, c, radius, 44, Fx.SILVER);
        w.spawnParticle(Particle.EXPLOSION, c.getX(), c.getY() + 0.3, c.getZ(), 2, 0.4, 0.2, 0.4, 0);
        spark(w, c.clone().add(new Vector(0, 0.5, 0)), 40, radius * 0.35);
        dust(w, c.clone().add(new Vector(0, 0.4, 0)), 30, radius * 0.4, 1.8f, col);
        boolean emp = col.equals(WHITE_BLUE);
        plugin.vfx().shockwave(w, c, radius, emp);
        plugin.vfx().burst(w, c.clone().add(new Vector(0, 0.8, 0)), Math.max(1.5, radius * 0.7), emp);
        if (radius >= 2.0) plugin.vfx().crack(w, c, radius * 0.9, emp);
    }

    /** Rune-circle telegraph on the ground (model VFX). */
    public void rune(Player p, World w, Vector ground, double radius, int ticks) {
        plugin.vfx().rune(w, ground, radius, ticks, plugin.meter().isEmpowered(p));
    }

    /** Column of light (model VFX). */
    public void beam(Player p, World w, Vector base, double height, double radius, int ticks) {
        plugin.vfx().beam(w, base, height, radius, ticks, plugin.meter().isEmpowered(p));
    }

    public void sound(World w, Vector at, String key, String def, float vol, float pitch) {
        String s = plugin.cfg().s("sounds." + key, def);
        w.playSound(new Location(w, at.getX(), at.getY(), at.getZ()), s, SoundCategory.PLAYERS, vol, pitch);
    }

    /** Sound only the player hears (UI feedback). */
    public void tell(Player p, String key, String def, float vol, float pitch) {
        p.playSound(p.getLocation(), plugin.cfg().s("sounds." + key, def), SoundCategory.PLAYERS, vol, pitch);
    }

    public void ravageBurst(Player p) {
        World w = p.getWorld();
        Vector at = p.getLocation().toVector().add(new Vector(0, 1.0, 0));
        ring(w, at, 1.2, 24, WHITE_BLUE);
        ring(w, at, 2.4, 40, BLUE);
        spark(w, at, 60, 0.9);
        plugin.vfx().shockwave(w, p.getLocation().toVector(), 3.5, true);
        plugin.vfx().burst(w, at, 3.0, true);
        plugin.vfx().rune(w, p.getLocation().toVector(), 2.4, 30, true);
        sound(w, at, "ravage_activate", "minecraft:block.beacon.activate", 1.4f, 1.3f);
    }
}

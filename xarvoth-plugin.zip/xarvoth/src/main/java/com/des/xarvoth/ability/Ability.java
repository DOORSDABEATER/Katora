package com.des.xarvoth.ability;

public interface Ability {
    /** Stable lowercase id; also the key under "abilities" in config.yml. */
    String id();

    String displayName();

    AbilityCategory category();

    /**
     * Validate and start. Must not consume anything on failure.
     *
     * @return null if the ability started, otherwise a short reason shown to the player (no cooldown is spent).
     */
    String activate(AbilityContext ctx);
}

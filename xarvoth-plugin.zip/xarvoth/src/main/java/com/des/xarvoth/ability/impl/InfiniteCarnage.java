package com.des.xarvoth.ability.impl;

import com.des.xarvoth.RavageMeter;
import com.des.xarvoth.XarvothPlugin;
import com.des.xarvoth.ability.AbilityCategory;
import com.des.xarvoth.ability.AbilityContext;
import com.des.xarvoth.blade.Barrier;
import com.des.xarvoth.blade.BladeId;
import com.des.xarvoth.blade.Motion;
import com.des.xarvoth.blade.PlayerSession;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * BLADE 7 - INFINITE CARNAGE. Both blades whirl around the nearest cluster of enemies on opposing spirals and cut everything
 * they pass through. It escalates: the spiral tightens and speeds up, the per-target hit interval shrinks from 9 to 3 ticks,
 * damage climbs up to +60%, and the effects get denser. Per-target total hits are capped; it ends early if the enemies are gone.
 */
public final class InfiniteCarnage extends BaseAbility {
    public InfiniteCarnage(XarvothPlugin plugin) { super(plugin, "infinite_carnage", "INFINITE CARNAGE", AbilityCategory.BLADE); }

    private static final class Shared {
        Vector center;
        int missing;
        final Map<UUID, Integer> hits = new HashMap<>();
        final Map<String, Integer> next = new HashMap<>();
    }

    @Override
    protected String start(AbilityContext ctx) {
        Player p = ctx.owner();
        PlayerSession s = ctx.session();
        String busy = Kit.requireIdle(s, BladeId.VORTH, BladeId.ZYRATH);
        if (busy != null) return busy;

        double range = ctx.cfgD("range", 14.0);
        List<LivingEntity> first = Kit.around(ctx, p.getLocation().toVector(), range, 6, false);
        if (first.isEmpty()) return "No targets in range.";

        Shared sh = new Shared();
        sh.center = centroid(first);
        int total = ctx.cfgI("duration-ticks", 70);
        Barrier fin = new Barrier(2, () -> finish(ctx, sh));
        for (BladeId id : BladeId.values()) s.unit(id).queue(new Carnage(ctx, id, sh, total, range, fin));
        plugin.fx().sound(p.getWorld(), p.getLocation().toVector(), "carnage_start", "xarvoth:carnage.start", 1.4f, 1.0f);
        return null;
    }

    private static Vector centroid(List<LivingEntity> l) {
        Vector c = new Vector();
        for (LivingEntity e : l) c.add(Kit.center(e));
        return c.multiply(1.0 / l.size());
    }

    private void finish(AbilityContext ctx, Shared sh) {
        Player p = ctx.owner();
        if (!p.isOnline() || sh.center == null) return;
        Kit.impact(ctx, BladeId.VORTH, sh.center, 4.5, ctx.baseDamage(10.0), 8, 0.9, 0.6);
        plugin.fx().shockwave(p.getWorld(), Kit.ground(p.getWorld(), sh.center), 4.5, plugin.fx().energy(p));
        plugin.fx().sound(p.getWorld(), sh.center, "carnage_end", "xarvoth:carnage.end", 1.5f, 0.9f);
    }

    private final class Carnage extends Motion {
        private final AbilityContext ctx;
        private final BladeId blade;
        private final Shared sh;
        private final int total;
        private final double range;
        private final Barrier fin;
        private final int maxHits;
        private int t;

        Carnage(AbilityContext ctx, BladeId blade, Shared sh, int total, double range, Barrier fin) {
            this.ctx = ctx;
            this.blade = blade;
            this.sh = sh;
            this.total = total;
            this.range = range;
            this.fin = fin;
            this.maxHits = ctx.cfgI("max-hits-per-target", 14);
        }

        @Override public boolean step() {
            t++;
            Player p = ctx.owner();
            double f = Math.min(1.0, t / (double) total);
            if (t % 4 == 1) {
                List<LivingEntity> l = Kit.around(ctx, p.getLocation().toVector(), range, 6, false);
                if (l.isEmpty()) sh.missing += 4; else { sh.missing = 0; sh.center = centroid(l); }
            }
            if (sh.missing >= 12 || sh.center == null) return true;

            boolean v = blade == BladeId.VORTH;
            double ang = t * (0.5 + f * 0.55) * blade.side + (v ? 0 : Math.PI);
            double r = (v ? 4.2 : 3.0) - f * 1.2;
            double h = 1.0 + Math.sin(t * 0.45 + (v ? 0 : 2)) * 1.4 + f * 0.6;
            Vector goal = sh.center.clone().add(new Vector(Math.cos(ang) * r, h, Math.sin(ang) * r));
            u.pos.add(goal.subtract(u.pos).multiply(0.55));

            int interval = (int) Math.max(3, Math.round(9 - 6 * f));
            for (LivingEntity e : u.sweep(blade.hitRadius * 1.5)) {
                if (!plugin.damage().canTarget(p, e)) continue;
                UUID id = e.getUniqueId();
                if (sh.hits.getOrDefault(id, 0) >= maxHits) continue;
                String key = blade.key + id;
                if (t < sh.next.getOrDefault(key, 0)) continue;
                sh.next.put(key, t + interval);
                double dmg = ctx.baseDamage(2.6) * blade.damageMul * (1.0 + f * 0.6);
                if (ctx.hit(blade, e, dmg, RavageMeter.Source.BLADE_HIT, Kit.kb(sh.center, e.getLocation().toVector(), 0.2, 0.15))) {
                    sh.hits.merge(id, 1, Integer::sum);
                    plugin.fx().slash(p.getWorld(), Kit.center(e), u.pos.clone().subtract(u.prev), 1.8 + f * 1.5, plugin.fx().energy(p));
                    plugin.fx().sound(p.getWorld(), u.pos, "blade_hit", "xarvoth:blade.hit", 0.8f, 1.0f + (float) f * 0.8f);
                }
            }
            plugin.fx().dust(p.getWorld(), u.pos, 1 + (int) (f * 4), 0.12, 1.2f + (float) f, plugin.fx().energy(p));
            if (f > 0.7) plugin.fx().spark(p.getWorld(), u.pos, 2, 0.2);
            return t >= total;
        }

        @Override public void onFinish() { fin.arrive(); }
    }
}

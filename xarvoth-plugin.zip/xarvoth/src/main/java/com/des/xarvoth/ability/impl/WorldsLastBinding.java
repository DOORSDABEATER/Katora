package com.des.xarvoth.ability.impl;

import com.des.xarvoth.RavageMeter;
import com.des.xarvoth.XarvothPlugin;
import com.des.xarvoth.ability.AbilityCategory;
import com.des.xarvoth.ability.AbilityContext;
import com.des.xarvoth.blade.Barrier;
import com.des.xarvoth.blade.BladeId;
import com.des.xarvoth.blade.BladeUnit;
import com.des.xarvoth.blade.Motions;
import com.des.xarvoth.blade.PlayerSession;
import com.des.xarvoth.blade.Script;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;

/**
 * CONVERGENCE 11 - WORLD'S LAST BINDING. The blades hammer six stakes into the ground around a huge circle, one after another from
 * opposite sides. Chains join the stakes into a polygon and run to the centre: a web pinned to the world itself. Inside it, enemies
 * are crushed by tension - heavily slowed, dragged gently inward, pulsed by the links (the time is granted and capped by
 * RestraintService). Then the stakes are ripped out: the web snaps inward, everything is hauled to the centre, and both blades
 * come down on it.
 */
public final class WorldsLastBinding extends BaseAbility {
    private static final int STAKES = 6;

    public WorldsLastBinding(XarvothPlugin plugin) { super(plugin, "worlds_last_binding", "WORLD'S LAST BINDING", AbilityCategory.CONVERGENCE); }

    @Override
    protected String start(AbilityContext ctx) {
        Player p = ctx.owner();
        PlayerSession s = ctx.session();
        String busy = Kit.requireIdle(s, BladeId.VORTH, BladeId.ZYRATH);
        if (busy != null) return busy;
        World w = p.getWorld();
        double range = Math.min(ctx.cfgD("range", 14.0), plugin.cfg().d("chain.max-length", 24.0) - 10.0);
        Vector c = Kit.aimGround(ctx, range);
        double r = ctx.cfgD("radius", 9.0);
        if (Kit.around(ctx, c, r, 1, false).isEmpty()) return "No targets inside the binding.";

        int hold = Math.min(ctx.cfgI("hold-ticks", 40), plugin.cfg().i("restraint.max-ticks", 60));
        BladeUnit v = s.unit(BladeId.VORTH);
        BladeUnit z = s.unit(BladeId.ZYRATH);
        Vector[] post = new Vector[STAKES];
        for (int i = 0; i < STAKES; i++) {
            double a = Math.PI * 2 * i / STAKES;
            post[i] = Kit.ground(w, c.clone().add(new Vector(Math.cos(a) * r, 0, Math.sin(a) * r)));
        }
        List<LivingEntity> held = new ArrayList<>();
        Barrier blast = new Barrier(2, () -> blast(ctx, c, r));

        Script sc = new Script().exclusive(true);
        sc.run(() -> {
            for (int i = 0; i < STAKES; i++) {
                final int k = i;
                BladeUnit u = i % 2 == 0 ? v : z;
                u.queue(new Motions.Arc(() -> post[k].clone().add(new Vector(0, 7.0, 0)), Kit.ZERO.clone(), 4, Motions.Easing.OUT));
                u.queue(new Motions.Arc(() -> post[k].clone().add(new Vector(0, 0.3, 0)), Kit.ZERO.clone(), 3, Motions.Easing.IN).then(() -> {
                    plugin.fx().shockwave(w, post[k], 1.6, plugin.fx().energy(p));
                    plugin.fx().sound(w, post[k], "binding_stake", "xarvoth:binding.stake", 1.3f, 0.8f + k * 0.08f);
                }));
            }
            plugin.fx().sound(w, p.getLocation().toVector(), "binding_start", "xarvoth:binding.start", 1.3f, 1.0f);
        });
        sc.waitIdle(v, z);
        sc.run(() -> {
            for (int i = 0; i < STAKES; i++) {
                final int k = i;
                sc.own(s.strand(() -> post[k], () -> post[(k + 1) % STAKES], 1.02, hold + 60, 5));
                sc.own(s.strand(() -> post[k], () -> c.clone().add(new Vector(0, 0.4, 0)), 1.05, hold + 60, 5));
            }
            for (LivingEntity e : Kit.around(ctx, c, r, ctx.cfgI("target-limit", 10), false)) {
                if (plugin.restraints().grant(e, hold, false) > 0) held.add(e);
            }
            for (LivingEntity e : held) ctx.gain(RavageMeter.Source.CAPTURE, e);
            plugin.fx().rune(p, w, c, r, hold + 14);
            plugin.fx().sound(w, c, "binding_web", "xarvoth:binding.web", 1.5f, 0.8f);
        });
        sc.during(hold, i -> {
            if (i % 6 == 0) plugin.fx().ring(w, c, r * (1.0 - i / (double) hold * 0.5), 40, plugin.fx().energy(p));
            for (LivingEntity e : held) {
                if (!Kit.alive(e)) continue;
                if (i % 10 == 0) plugin.restraints().slow(e, 12, 3);
                Kit.pull(e, c, 0.15);
                Kit.confine(e, c, r - 0.5);
                if (i % 10 == 9) {
                    ctx.hit(null, e, ctx.baseDamage(2.5), RavageMeter.Source.CHAIN_HIT, null);
                    plugin.fx().spark(w, Kit.center(e), 10, 0.3);
                }
            }
        });
        sc.run(() -> {
            v.queue(new Motions.Arc(() -> c.clone().add(new Vector(0, 0.5, 0)), Kit.ZERO.clone(), 6, Motions.Easing.IN).then(blast::arrive));
            z.queue(new Motions.Arc(() -> c.clone().add(new Vector(0, 0.5, 0)), Kit.ZERO.clone(), 6, Motions.Easing.IN).then(blast::arrive));
            plugin.fx().sound(w, c, "binding_snap", "xarvoth:binding.snap", 1.5f, 1.0f);
        });
        sc.during(8, i -> {
            for (LivingEntity e : held) if (Kit.alive(e)) Kit.pull(e, c, 1.3);
        });
        sc.waitIdle(v, z);
        sc.onEnd(() -> { v.clearMotions(); z.clearMotions(); });
        return Kit.begin(ctx, sc);
    }

    private void blast(AbilityContext ctx, Vector c, double r) {
        Player p = ctx.owner();
        if (!p.isOnline()) return;
        for (LivingEntity e : Kit.impact(ctx, BladeId.VORTH, c, 6.0, ctx.baseDamage(24.0), 12, 0.6, 0.7)) ctx.gain(RavageMeter.Source.PULL, e);
        plugin.fx().shockwave(p.getWorld(), c, 6.0, plugin.fx().energy(p));
        plugin.fx().beam(p, p.getWorld(), c, 14.0, 2.0, 10);
        plugin.fx().sound(p.getWorld(), c, "binding_end", "xarvoth:binding.end", 1.8f, 0.7f);
    }
}

package com.des.xarvoth;

import org.bukkit.configuration.file.FileConfiguration;

import java.util.List;

/** Thin live wrapper over config.yml so reloads take effect immediately. */
public final class Cfg {
    private final XarvothPlugin plugin;

    public Cfg(XarvothPlugin plugin) { this.plugin = plugin; }

    private FileConfiguration c() { return plugin.getConfig(); }

    public double d(String path, double def) { return c().getDouble(path, def); }
    public int i(String path, int def) { return c().getInt(path, def); }
    public boolean b(String path, boolean def) { return c().getBoolean(path, def); }
    public String s(String path, String def) { return c().getString(path, def); }
    public List<String> list(String path) { return c().getStringList(path); }

    public double ad(String ability, String key, double def) { return d("abilities." + ability + "." + key, def); }
    public int ai(String ability, String key, int def) { return i("abilities." + ability + "." + key, def); }
    public long cooldownMs(String ability) { return ai(ability, "cooldown-ticks", 100) * 50L; }
    public boolean worldDisabled(String world) { return list("worlds-disabled").contains(world); }
}

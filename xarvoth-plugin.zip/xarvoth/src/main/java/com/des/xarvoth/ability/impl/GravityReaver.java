package com.des.xarvoth.ability.impl;

import com.des.xarvoth.RavageMeter;
import com.des.xarvoth.Targeting;
import com.des.xarvoth.XarvothPlugin;
import com.des.xarvoth.ability.AbilityCategory;
import com.des.xarvoth.ability.AbilityContext;
import com.des.xarvoth.blade.BladeId;
import com.des.xarvoth.blade.BladeUnit;
import com.des.xarvoth.blade.Motions;
import com.des.xarvoth.blade.PlayerSession;
import com.des.xarvoth.blade.Script;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.Locale;

/**
 * CONVERGENCE 2 - GRAVITY REAVER. ZYRATH's chain hooks one target and hoists it into the air, held there for a capped time while
 * ZYRATH circles and slashes it and VORTH rises overhead. Then VORTH drops the full weight of the strike on it, the target is
 * driven into the ground, and the ground impact hits everything around it. Needs RestraintService to grant the suspension.
 */
public final class GravityReaver extends BaseAbility {
    public GravityReaver(XarvothPlugin plugin) { super(plugin, "gravity_reaver", "GRAVITY REAVER", AbilityCategory.CONVERGENCE); }

    @Override
    protected String start(AbilityContext ctx) {
        Player p = ctx.owner();
        PlayerSession s = ctx.session();
        String busy = Kit.requireIdle(s, BladeId.VORTH, BladeId.ZYRATH);
        if (busy != null) return busy;
        double range = Math.min(ctx.cfgD("range", 16.0), plugin.cfg().d("chain.max-length", 24.0) - 2.0);
        Targeting.Aim a = Targeting.aim(p, range);
        if (a == null || a.entity() == null) return "No target in range.";
        LivingEntity t = a.entity();
        if (!plugin.damage().canTarget(p, t)) return "That target cannot be bound.";
        if (!plugin.restraints().canRestrain(t)) return "The chains cannot hold that.";
        long imm = plugin.restraints().immuneRemainingMs(t);
        if (imm > 0) return "Target is resisting the chains (" + String.format(Locale.ROOT, "%.1fs", imm / 1000.0) + ").";

        World w = p.getWorld();
        BladeUnit v = s.unit(BladeId.VORTH);
        BladeUnit z = s.unit(BladeId.ZYRATH);
        boolean[] arrived = {false};
        int[] granted = {0};
        double[] hoistY = {0};
        Vector[] last = {Kit.center(t)};
        double slash = ctx.baseDamage(5.0);

        Script sc = new Script();
        sc.run(() -> z.queue(new Motions.Homing(() -> Kit.alive(t) ? Kit.center(t) : null, 3.0, 0.9, 14).stopOnBlock().onArrive(() -> arrived[0] = true)));
        sc.waitIdle(z);
        sc.run(() -> {
            if (!arrived[0] || !ctx.hit(BladeId.ZYRATH, t, slash * BladeId.ZYRATH.damageMul, RavageMeter.Source.CHAIN_HIT, null)) { sc.stop(); return; }
            granted[0] = plugin.restraints().grant(t, ctx.cfgI("hoist-ticks", 30), false);
            if (granted[0] <= 0) { sc.stop(); return; }
            hoistY[0] = Kit.ground(w, t.getLocation().toVector()).getY() + ctx.cfgD("hoist-height", 4.0);
            ctx.gain(RavageMeter.Source.CAPTURE, t);
            sc.own(s.strand(() -> s.handAnchor(BladeId.ZYRATH), () -> Kit.alive(t) ? Kit.center(t) : last[0], 1.0, granted[0] + 40, 7));
            z.queue(new Motions.Path(i -> Kit.center(t).add(new Vector(Math.cos(i * 0.6) * 1.7, 0.1, Math.sin(i * 0.6) * 1.7)), granted[0] + 2, 0.5));
            v.queue(new Motions.Arc(() -> (Kit.alive(t) ? Kit.center(t) : last[0]).clone().add(new Vector(0, 6.0, 0)), Kit.ZERO.clone(), 10, Motions.Easing.OUT));
            plugin.fx().sound(w, Kit.center(t), "reaver_hoist", "xarvoth:reaver.hoist", 1.4f, 0.9f);
        });
        int[] n = {0};
        sc.step(() -> n[0] = 0, () -> {
            int i = n[0]++;
            if (Kit.alive(t)) {
                last[0] = Kit.center(t);
                Kit.hold(t, hoistY[0]);
                if (i == 6 || i == 13 || i == 20) {
                    ctx.hit(BladeId.ZYRATH, t, slash * BladeId.ZYRATH.damageMul, RavageMeter.Source.BLADE_HIT, new Vector(0, 0.0, 0));
                    plugin.fx().slash(w, last[0], new Vector(Math.cos(i), 0.3, Math.sin(i)), 2.6, plugin.fx().energy(p));
                    plugin.fx().sound(w, last[0], "blade_hit", "xarvoth:blade.hit", 0.9f, 1.0f + i * 0.02f);
                }
                if (i % 3 == 0) plugin.fx().ring(w, Kit.ground(w, last[0]), 1.5, 14, plugin.fx().energy(p));
            }
            return !Kit.alive(t) || n[0] >= Math.min(24, granted[0]);
        });
        sc.waitIdle(v);
        sc.run(() -> {
            z.clearMotions();
            v.queue(new Motions.Arc(() -> Kit.alive(t) ? Kit.center(t) : last[0].clone(), Kit.ZERO.clone(), 4, Motions.Easing.IN).then(() -> {
                if (Kit.alive(t)) {
                    ctx.hit(BladeId.VORTH, t, ctx.baseDamage(18.0) * BladeId.VORTH.damageMul, RavageMeter.Source.BLADE_HIT, new Vector(0, -1.8, 0));
                    t.setVelocity(new Vector(0, -1.8, 0));
                }
                plugin.fx().sound(w, last[0], "reaver_smash", "xarvoth:reaver.smash", 1.6f, 0.8f);
            }));
        });
        sc.waitIdle(v);
        sc.step(() -> { }, new java.util.function.BooleanSupplier() {
            int n;
            @Override public boolean getAsBoolean() { return ++n > 12 || !Kit.alive(t) || t.isOnGround(); }
        });
        sc.run(() -> {
            Vector g = Kit.alive(t) ? Kit.ground(w, t.getLocation().toVector()) : Kit.ground(w, last[0]);
            double base = ctx.baseDamage(18.0) * 0.6 * BladeId.VORTH.damageMul;
            for (LivingEntity e : Kit.around(ctx, g, 4.0, 8, false)) {
                if (e.equals(t)) continue;
                ctx.hit(BladeId.VORTH, e, base, RavageMeter.Source.BLADE_HIT, Kit.kb(g, e.getLocation().toVector(), 0.9, 0.55));
            }
            plugin.fx().shockwave(w, g, 4.0, plugin.fx().energy(p));
            plugin.fx().sound(w, g, "reaver_impact", "xarvoth:reaver.impact", 1.6f, 0.7f);
        });
        sc.onEnd(() -> { z.clearMotions(); v.clearMotions(); });
        return Kit.begin(ctx, sc);
    }
}

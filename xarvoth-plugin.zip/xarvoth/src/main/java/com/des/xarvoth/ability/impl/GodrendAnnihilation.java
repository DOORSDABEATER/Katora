package com.des.xarvoth.ability.impl;

import com.des.xarvoth.RavageMeter;
import com.des.xarvoth.XarvothPlugin;
import com.des.xarvoth.ability.AbilityCategory;
import com.des.xarvoth.ability.AbilityContext;
import com.des.xarvoth.blade.Barrier;
import com.des.xarvoth.blade.BladeId;
import com.des.xarvoth.blade.BladeUnit;
import com.des.xarvoth.blade.ChainStrand;
import com.des.xarvoth.blade.Hitbook;
import com.des.xarvoth.blade.Motions;
import com.des.xarvoth.blade.PlayerSession;
import com.des.xarvoth.blade.Script;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;

/**
 * CONVERGENCE 12 - GODREND ANNIHILATION. The blades climb and meet in one point high above the target ground, a chain stretched
 * between them like a lance; the ground is marked and the air charges. Then they plunge together as one: a column strike, huge
 * area damage. Where it lands eight chains tear out across the ground like spokes, each cutting whatever it crosses once
 * and throwing it outward.
 */
public final class GodrendAnnihilation extends BaseAbility {
    private static final int SPOKES = 8;

    public GodrendAnnihilation(XarvothPlugin plugin) { super(plugin, "godrend_annihilation", "GODREND ANNIHILATION", AbilityCategory.CONVERGENCE); }

    @Override
    protected String start(AbilityContext ctx) {
        Player p = ctx.owner();
        PlayerSession s = ctx.session();
        String busy = Kit.requireIdle(s, BladeId.VORTH, BladeId.ZYRATH);
        if (busy != null) return busy;
        World w = p.getWorld();
        double range = Math.min(ctx.cfgD("range", 16.0), plugin.cfg().d("chain.max-length", 24.0) - 10.0);
        Vector c = Kit.aimGround(ctx, range);
        double radius = ctx.cfgD("radius", 5.5);
        double reach = ctx.cfgD("spoke-length", 11.0);
        if (Kit.around(ctx, c, radius + 3.0, 1, false).isEmpty()) return "No targets near that point.";

        Vector right = s.right();
        BladeUnit v = s.unit(BladeId.VORTH);
        BladeUnit z = s.unit(BladeId.ZYRATH);
        Vector top = c.clone().add(new Vector(0, ctx.cfgD("height", 10.0), 0));
        int[] tk = {0};
        List<ChainStrand> spokes = new ArrayList<>();
        Hitbook spokeBook = new Hitbook();
        Barrier plunge = new Barrier(2, () -> crash(ctx, c, radius));

        Script sc = new Script().exclusive(true);
        sc.run(() -> {
            v.queue(new Motions.Arc(() -> top.clone().add(right.clone().multiply(0.9)), right.clone().multiply(5.0), 14, Motions.Easing.OUT));
            z.queue(new Motions.Arc(() -> top.clone().add(right.clone().multiply(-0.9)), right.clone().multiply(-5.0), 14, Motions.Easing.OUT));
            sc.own(s.strand(() -> v.pos.clone(), () -> z.pos.clone(), 1.0, 120, 5));
            plugin.fx().rune(p, w, c, radius + 1.0, 64);
            plugin.fx().sound(w, p.getLocation().toVector(), "godrend_rise", "xarvoth:godrend.rise", 1.5f, 1.0f);
        });
        sc.waitIdle(v, z);
        sc.run(() -> { v.queue(new Motions.Hold(14)); z.queue(new Motions.Hold(14)); });
        sc.during(14, i -> {
            double f = i / 14.0;
            plugin.fx().ring(w, c, radius * (1.0 - f * 0.4), 44, plugin.fx().energy(p));
            for (double y = 0; y < top.getY() - c.getY(); y += 1.2) plugin.fx().dust(w, c.clone().add(new Vector(0, y, 0)), 1, 0.15 + f * 0.2, 1.3f, plugin.fx().energy(p));
            plugin.fx().spark(w, top, 3 + (int) (f * 6), 0.7);
            if (i == 0) plugin.fx().sound(w, c, "godrend_charge", "xarvoth:godrend.charge", 1.6f, 1.0f);
        });
        sc.waitIdle(v, z);
        sc.run(() -> {
            v.queue(new Motions.Arc(() -> c.clone().add(new Vector(0, 0.5, 0)), Kit.ZERO.clone(), 5, Motions.Easing.IN).then(plunge::arrive));
            z.queue(new Motions.Arc(() -> c.clone().add(new Vector(0, 0.5, 0)), Kit.ZERO.clone(), 5, Motions.Easing.IN).then(plunge::arrive));
        });
        sc.waitIdle(v, z);
        sc.run(() -> {
            tk[0] = 0;
            for (int k = 0; k < SPOKES; k++) {
                final int kk = k;
                double a = Math.PI * 2 * k / SPOKES;
                Vector dir = new Vector(Math.cos(a), 0, Math.sin(a));
                spokes.add(sc.own(s.strand(() -> c.clone().add(new Vector(0, 0.3, 0)),
                        () -> Kit.ground(w, c.clone().add(dir.clone().multiply(reach * Math.min(1.0, tk[0] / 7.0)))).add(new Vector(0, 0.3, 0)),
                        1.02, 30, 6)));
            }
            plugin.fx().sound(w, c, "godrend_spokes", "xarvoth:godrend.spokes", 1.5f, 1.0f);
        });
        sc.during(16, i -> {
            tk[0] = i;
            if (i % 2 != 0) return;
            for (ChainStrand st : spokes) {
                for (LivingEntity e : st.sweep(0.9)) {
                    if (!plugin.damage().canTarget(p, e) || !spokeBook.first(e.getUniqueId())) continue;
                    if (ctx.hit(null, e, ctx.baseDamage(8.0), RavageMeter.Source.CHAIN_HIT, Kit.kb(c, e.getLocation().toVector(), 1.2, 0.5))) {
                        plugin.fx().spark(w, Kit.center(e), 14, 0.35);
                        plugin.fx().sound(w, Kit.center(e), "chain_hit", "xarvoth:chain.hit", 0.9f, 0.9f);
                    }
                }
            }
        });
        sc.onEnd(() -> { v.clearMotions(); z.clearMotions(); });
        return Kit.begin(ctx, sc);
    }

    private void crash(AbilityContext ctx, Vector c, double radius) {
        Player p = ctx.owner();
        if (!p.isOnline()) return;
        World w = p.getWorld();
        Kit.impact(ctx, BladeId.VORTH, c, radius, ctx.baseDamage(32.0), 12, 1.0, 0.9);
        plugin.fx().shockwave(w, c, radius, plugin.fx().energy(p));
        for (double y = 0; y < 14; y += 0.8) plugin.fx().dust(w, c.clone().add(new Vector(0, y, 0)), 3, 0.5, 1.9f, plugin.fx().energy(p));
        for (int i = 0; i < 3; i++) {
            double a = i * 2.1;
            w.strikeLightningEffect(new Location(w, c.getX() + Math.cos(a) * 2.5, c.getY(), c.getZ() + Math.sin(a) * 2.5));
        }
        plugin.fx().beam(p, w, c, 18.0, 3.0, 16);
        plugin.fx().sound(w, c, "godrend_impact", "xarvoth:godrend.impact", 2.0f, 0.7f);
    }
}

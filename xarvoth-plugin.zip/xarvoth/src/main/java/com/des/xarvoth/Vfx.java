package com.des.xarvoth;

import com.des.xarvoth.blade.BladeId;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Model-based visual effects. Every effect is a short-lived ItemDisplay using one of XARVOTH's own VFX models; its transform
 * is animated every tick (scale, rotation, position) and its item_model is swapped through four fade stages as it ages.
 * All displays go through BladeManager (tagged, non-persistent, tracked), life is hard-capped, and the number alive at once is
 * capped by vfx.max-active, so effects can never accumulate. Particles stay as a thin accent layer on top (see Fx).
 */
public final class Vfx {
    private interface Xf { Transformation at(double k, int age); }
    private interface Fr { int at(double k); }

    private static final class Live {
        final ItemDisplay d; final String type; final boolean emp; final int life; final Xf xf; final Fr fr;
        int age; int frame;
        Live(ItemDisplay d, String type, boolean emp, int life, Xf xf, Fr fr, int frame) {
            this.d = d; this.type = type; this.emp = emp; this.life = life; this.xf = xf; this.fr = fr; this.frame = frame;
        }
    }

    private final XarvothPlugin plugin;
    private final List<Live> live = new ArrayList<>();
    private final Map<String, ItemStack> cache = new HashMap<>();
    private final Random rnd = new Random(1337);
    private BukkitTask task;

    public Vfx(XarvothPlugin plugin) { this.plugin = plugin; }

    public void start() { task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L); }

    public void shutdown() {
        if (task != null) task.cancel();
        for (Live l : live) plugin.blades().despawnDisplay(l.d);
        live.clear();
    }

    public int activeCount() { return live.size(); }

    private ItemStack item(String name, boolean emp) {
        return cache.computeIfAbsent(name + (emp ? "#e" : ""), k -> Models.vfx(plugin, name, emp));
    }

    private static Transformation tf(float sx, float sy, float sz, Quaternionf q) {
        return new Transformation(new Vector3f(0, 0, 0), q, new Vector3f(sx, sy, sz), new Quaternionf());
    }

    private static double easeOut(double k) { k = Math.max(0, Math.min(1, k)); return 1 - (1 - k) * (1 - k); }

    private static final Fr FADE = k -> Math.min(3, (int) (k * k * 4));

    private void add(World w, Vector pos, String type, boolean emp, int life, Xf xf, Fr fr) {
        if (!plugin.cfg().b("vfx.enabled", true)) return;
        if (live.size() >= plugin.cfg().i("vfx.max-active", 160)) return;
        int f0 = fr.at(0);
        ItemDisplay d = plugin.blades().spawnDisplay(w, pos, item(type + f0, emp));
        d.setTeleportDuration(0);
        d.setInterpolationDuration(1);
        d.setTransformation(xf.at(0, 0));
        live.add(new Live(d, type, emp, life, xf, fr, f0));
    }

    private void tick() {
        Iterator<Live> it = live.iterator();
        while (it.hasNext()) {
            Live l = it.next();
            l.age++;
            if (l.age >= l.life || !l.d.isValid()) {
                plugin.blades().despawnDisplay(l.d);
                it.remove();
                continue;
            }
            double k = l.age / (double) l.life;
            int f = l.fr.at(k);
            if (f != l.frame) { l.d.setItemStack(item(l.type + f, l.emp)); l.frame = f; }
            l.d.setInterpolationDelay(0);
            l.d.setTransformation(l.xf.at(k, l.age));
        }
    }

    // ------------------------------------------------------------------ effects

    /** A crescent of energy cut through the air. Bulges along {@code dir}; random roll gives each cut its own angle. */
    public void slash(World w, Vector center, Vector dir, double size, boolean emp) {
        double yaw = (dir.lengthSquared() < 1e-6) ? 0 : Math.atan2(dir.getX(), dir.getZ());
        float roll = (float) Math.toRadians(rnd.nextInt(140) - 70);
        float s0 = (float) size;
        add(w, center, "vfx_slash_", emp, 5,
                (k, age) -> { float s = s0 * (0.7f + 0.5f * (float) easeOut(k * 1.6)); return tf(s, s, s, new Quaternionf().rotateY((float) yaw).rotateZ(roll)); }, FADE);
    }

    /** An expanding ground ring. */
    public void shockwave(World w, Vector center, double radius, boolean emp) {
        float full = (float) (radius * 2.0);
        add(w, center.clone().add(new Vector(0, 0.12, 0)), "vfx_shock_", emp, 9,
                (k, age) -> { float s = full * (0.25f + 0.75f * (float) easeOut(k)); return tf(s, 1f, s, new Quaternionf().rotateY(age * 0.06f)); },
                k -> Math.min(3, (int) (k * k * 4.5)));
    }

    /** A column of light from the ground up. */
    public void beam(World w, Vector base, double height, double radius, int life, boolean emp) {
        float h = (float) height, r = (float) (radius * 2.0);
        add(w, base.clone().add(new Vector(0, height / 2.0, 0)), "vfx_beam_", emp, life,
                (k, age) -> {
                    float shrink = k > 0.7 ? (float) (1.0 - (k - 0.7) / 0.3) : 1f;
                    float rr = r * (1f + 0.12f * (float) Math.sin(age * 1.7)) * shrink;
                    return tf(rr, h, rr, new Quaternionf().rotateY(age * 0.15f));
                }, k -> Math.min(3, (int) (k * k * 3.2)));
    }

    /** A flash of crossing light lines. */
    public void burst(World w, Vector at, double size, boolean emp) {
        float s0 = (float) size;
        Quaternionf q = new Quaternionf().rotationXYZ(rnd.nextFloat() * 6.28f, rnd.nextFloat() * 6.28f, rnd.nextFloat() * 6.28f);
        add(w, at, "vfx_burst_", emp, 6,
                (k, age) -> { float s = s0 * (0.4f + 0.9f * (float) easeOut(k)); return tf(s, s, s, new Quaternionf(q)); }, FADE);
    }

    /** A rotating rune circle on the ground: grows in, holds, collapses. Used as an attack telegraph. */
    public void rune(World w, Vector ground, double radius, int life, boolean emp) {
        float full = (float) (radius * 2.0);
        add(w, ground.clone().add(new Vector(0, 0.1, 0)), "vfx_rune_", emp, Math.max(12, life),
                (k, age) -> {
                    double in = easeOut(Math.min(1.0, age / 6.0));
                    double out = k > 0.85 ? 1.0 - (k - 0.85) / 0.15 : 1.0;
                    float s = full * (float) (in * out);
                    return tf(s, 1f, s, new Quaternionf().rotateY(age * 0.07f));
                },
                k -> k < 0.7 ? 0 : Math.min(3, 1 + (int) ((k - 0.7) / 0.3 * 2.99)));
    }

    /** Cracks in the ground around an impact. */
    public void crack(World w, Vector center, double radius, boolean emp) {
        float full = (float) (radius * 2.0);
        float yaw = rnd.nextFloat() * 6.28f;
        add(w, center.clone().add(new Vector(0, 0.06, 0)), "vfx_crack_", emp, 26,
                (k, age) -> { float s = full * (float) easeOut(Math.min(1.0, k * 5)); return tf(s, 1f, s, new Quaternionf().rotateY(yaw)); }, FADE);
    }

    /** A fading copy of a blade left behind where it just was. */
    public void ghost(World w, Vector pos, Quaternionf rotation, BladeId id, boolean emp) {
        float s0 = id.scale;
        add(w, pos, "vfx_ghost_" + id.key + "_", emp, 6,
                (k, age) -> { float s = s0 * (1f - 0.35f * (float) k); return tf(s, s, s, new Quaternionf(rotation)); },
                k -> Math.min(2, (int) (k * 3)));
    }
}

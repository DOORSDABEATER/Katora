package com.des.xarvoth.ability.impl;

import com.des.xarvoth.RavageMeter;
import com.des.xarvoth.XarvothPlugin;
import com.des.xarvoth.ability.AbilityCategory;
import com.des.xarvoth.ability.AbilityContext;
import com.des.xarvoth.blade.BladeId;
import com.des.xarvoth.blade.BladeUnit;
import com.des.xarvoth.blade.Motions;
import com.des.xarvoth.blade.PlayerSession;
import com.des.xarvoth.blade.Script;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * CHAIN ULTIMATE - KINGDOM OF CHAINS. The blades are only anchors; the chains are the weapon.
 *  1. DOMINION: twelve chains race out from the wielder to a ring on the ground, claiming a huge circle. The blades plant at the
 *     east and west of the rim and stay there.
 *  2. CAPTURE: every enemy inside (limit 12, only those RestraintService grants time on) is lashed, damaged and linked to the wielder.
 *  3. SUSPENSION: captives are lifted off the ground and herded towards the centre; chains lash them one by one on a beat.
 *     Suspension for each captive ends when its granted ticks run out - nobody hangs forever.
 *  4. COLLAPSE: everything is hauled into a single point and crushed, with lightning.
 */
public final class KingdomOfChains extends BaseAbility {
    private static final int POSTS = 12;

    public KingdomOfChains(XarvothPlugin plugin) { super(plugin, "kingdom_of_chains", "KINGDOM OF CHAINS", AbilityCategory.ULTIMATE); }

    @Override
    protected String start(AbilityContext ctx) {
        Player p = ctx.owner();
        PlayerSession s = ctx.session();
        String busy = Kit.requireIdle(s, BladeId.VORTH, BladeId.ZYRATH);
        if (busy != null) return busy;
        World w = p.getWorld();
        double radius = Math.min(ctx.cfgD("radius", 14.0), plugin.cfg().d("chain.max-length", 24.0) - 4.0);
        if (Kit.around(ctx, p.getLocation().toVector(), radius, 1, false).isEmpty()) return "No enemies in range.";

        BladeUnit v = s.unit(BladeId.VORTH);
        BladeUnit z = s.unit(BladeId.ZYRATH);
        Vector origin = p.getLocation().toVector();
        Vector gather = Kit.ground(w, origin.clone().add(s.forward().multiply(6.0)));
        int hold = Math.min(ctx.cfgI("hold-ticks", 60), plugin.cfg().i("restraint.max-ticks", 60));
        double lashDmg = ctx.baseDamage(5.0);
        int[] tk = {0};
        boolean[] anchored = {false};
        Map<LivingEntity, Integer> left = new LinkedHashMap<>();

        Script sc = new Script().exclusive(true);
        sc.run(() -> {
            Vector east = Kit.ground(w, origin.clone().add(new Vector(radius, 0, 0)));
            Vector west = Kit.ground(w, origin.clone().add(new Vector(-radius, 0, 0)));
            v.queue(new Motions.Homing(() -> east.clone().add(new Vector(0, 0.4, 0)), 2.6, 0.8, 20));
            z.queue(new Motions.Homing(() -> west.clone().add(new Vector(0, 0.4, 0)), 2.6, 0.8, 20));
            for (int k = 0; k < POSTS; k++) {
                double a = Math.PI * 2 * k / POSTS;
                Vector dir = new Vector(Math.cos(a), 0, Math.sin(a));
                sc.own(s.strand(() -> s.handAnchor(BladeId.VORTH),
                        () -> Kit.ground(w, origin.clone().add(dir.clone().multiply(radius * Math.min(1.0, tk[0] / 18.0)))).add(new Vector(0, 0.3, 0)),
                        1.03, 220, 5));
            }
            plugin.fx().sound(w, origin, "kingdom_start", "xarvoth:kingdom.start", 1.8f, 1.0f);
        });
        sc.during(20, i -> {
            tk[0] = i;
            plugin.fx().ring(w, origin, radius * Math.min(1.0, i / 18.0), 52, plugin.fx().energy(p));
        });
        sc.waitIdle(v, z);
        sc.run(() -> {
            v.queue(new Motions.Follow(() -> Kit.ground(w, origin.clone().add(new Vector(radius, 0, 0))).add(new Vector(0, 0.4, 0)), n -> anchored[0]));
            z.queue(new Motions.Follow(() -> Kit.ground(w, origin.clone().add(new Vector(-radius, 0, 0))).add(new Vector(0, 0.4, 0)), n -> anchored[0]));
            List<LivingEntity> victims = Kit.around(ctx, origin, radius, ctx.cfgI("target-limit", 12), false);
            int n = 0;
            for (LivingEntity e : victims) {
                int g = plugin.restraints().grant(e, hold, false);
                if (g <= 0) continue;
                left.put(e, g);
                ctx.hit(null, e, ctx.baseDamage(3.0), RavageMeter.Source.CHAIN_HIT, new Vector(0, 0.2, 0));
                ctx.gain(RavageMeter.Source.CAPTURE, e);
                if (n++ < 8) sc.own(s.strand(() -> s.handAnchor(BladeId.ZYRATH), () -> Kit.alive(e) ? Kit.center(e) : null, 1.02, hold + 60, 5));
            }
            plugin.fx().shockwave(w, origin, radius * 0.6, plugin.fx().energy(p));
            plugin.fx().rune(p, w, origin, radius, hold + 20);
            plugin.fx().sound(w, origin, "kingdom_capture", "xarvoth:kingdom.capture", 1.8f, 0.9f);
        });
        int[] age = {0};
        sc.step(() -> age[0] = 0, () -> {
            int i = age[0]++;
            List<LivingEntity> order = new ArrayList<>(left.keySet());
            for (Map.Entry<LivingEntity, Integer> en : left.entrySet()) {
                LivingEntity e = en.getKey();
                if (!Kit.alive(e) || en.getValue() <= 0) continue;
                en.setValue(en.getValue() - 1);
                Vector g = Kit.ground(w, e.getLocation().toVector());
                double vy = Math.max(-0.5, Math.min(0.7, (g.getY() + 2.6 - e.getLocation().getY()) * 0.35));
                Vector lateral = gather.clone().subtract(e.getLocation().toVector()).setY(0).multiply(0.04);
                e.setVelocity(new Vector(lateral.getX(), vy, lateral.getZ()));
                e.setFallDistance(0);
            }
            if (i % 8 == 7 && !order.isEmpty()) {
                LivingEntity e = order.get((i / 8) % order.size());
                if (Kit.alive(e) && ctx.hit(null, e, lashDmg, RavageMeter.Source.CHAIN_HIT, new Vector(0, 0.0, 0))) {
                    plugin.fx().spark(w, Kit.center(e), 18, 0.4);
                    plugin.fx().sound(w, Kit.center(e), "chain_hit", "xarvoth:chain.hit", 1.1f, 0.8f);
                }
            }
            if (i % 6 == 0) plugin.fx().ring(w, origin, radius, 52, plugin.fx().energy(p));
            return i >= hold - 12;
        });
        sc.run(() -> plugin.fx().sound(w, gather, "kingdom_collapse", "xarvoth:kingdom.collapse", 1.8f, 1.0f));
        sc.during(10, i -> {
            for (LivingEntity e : left.keySet()) if (Kit.alive(e)) Kit.pull(e, gather.clone().add(new Vector(0, 0.5, 0)), 1.4);
        });
        sc.run(() -> {
            anchored[0] = true;
            Kit.impact(ctx, null, gather, 5.5, ctx.baseDamage(22.0), 14, 0.6, 0.8);
            plugin.fx().shockwave(w, gather, 5.5, plugin.fx().energy(p));
            for (int i = 0; i < 4; i++) {
                double a = i * Math.PI / 2;
                w.strikeLightningEffect(new Location(w, gather.getX() + Math.cos(a) * 3.0, gather.getY(), gather.getZ() + Math.sin(a) * 3.0));
            }
            plugin.fx().beam(p, w, gather, 16.0, 2.6, 14);
            plugin.fx().sound(w, gather, "kingdom_crush", "xarvoth:kingdom.crush", 2.0f, 0.8f);
        });
        sc.onEnd(() -> { anchored[0] = true; v.clearMotions(); z.clearMotions(); });
        return Kit.begin(ctx, sc);
    }
}

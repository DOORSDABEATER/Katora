package com.des.xarvoth;

import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * Every root, hold, leash and confinement in XARVOTH is accounted for here, which is what makes stun-locks and permanent
 * restraint impossible:
 *  - hard cap per restraint (restraint.max-ticks)
 *  - after a restraint ends the target is immune for restraint.immunity-ticks
 *  - a rolling cap on total restraint per window (restraint.window-cap-ticks)
 *  - boss types can be excluded
 * Physical effects are timed potion effects only, so nothing can outlive its duration. Leashes / confinement are driven by
 * effects that the session always cancels on interrupt, and they are limited by the ticks this service grants.
 */
public final class RestraintService {
    private final XarvothPlugin plugin;
    private final Map<UUID, Long> immuneUntil = new HashMap<>();
    private final Map<UUID, long[]> window = new HashMap<>(); // {usedTicks, windowStartMs}

    public RestraintService(XarvothPlugin plugin) { this.plugin = plugin; }

    public boolean canRestrain(LivingEntity v) {
        for (String s : plugin.cfg().list("restraint.immune-types")) {
            try { if (v.getType() == EntityType.valueOf(s.toUpperCase())) return false; } catch (IllegalArgumentException ignored) { }
        }
        return true;
    }

    public long immuneRemainingMs(LivingEntity v) {
        Long t = immuneUntil.get(v.getUniqueId());
        return t == null ? 0 : Math.max(0, t - System.currentTimeMillis());
    }

    /** Hard root (cannot walk or jump). @return ticks applied, 0 if refused. */
    public int restrain(Player owner, LivingEntity v, int requestedTicks) {
        return grant(v, requestedTicks, true);
    }

    /**
     * Reserves up to {@code requestedTicks} of control over {@code v}. With root=true it also roots the target;
     * with root=false (leash / confinement / suspension) the caller enforces the movement itself for exactly the granted ticks.
     * @return ticks granted, 0 if the target is immune, unrestrainable or over its window cap.
     */
    public int grant(LivingEntity v, int requestedTicks, boolean root) {
        if (!canRestrain(v) || immuneRemainingMs(v) > 0 || !v.isValid() || v.isDead()) return 0;
        Cfg cfg = plugin.cfg();
        int ticks = Math.min(requestedTicks, cfg.i("restraint.max-ticks", 60));

        long now = System.currentTimeMillis();
        long[] w = window.computeIfAbsent(v.getUniqueId(), k -> new long[]{0, now});
        if (now - w[1] > cfg.i("restraint.window-seconds", 20) * 1000L) { w[0] = 0; w[1] = now; }
        int room = cfg.i("restraint.window-cap-ticks", 100) - (int) w[0];
        ticks = Math.min(ticks, room);
        if (ticks <= 0) return 0;
        w[0] += ticks;

        immuneUntil.put(v.getUniqueId(), now + (ticks + cfg.i("restraint.immunity-ticks", 100)) * 50L);
        if (root) {
            v.setVelocity(v.getVelocity().multiply(0.0));
            v.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, ticks, 6, false, false, false));
            v.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, ticks, 128, false, false, false));
        }
        return ticks;
    }

    /** Soft slow (not a root, not counted against the window). Duration is capped. */
    public void slow(LivingEntity v, int ticks, int amplifier) {
        int t = Math.min(ticks, plugin.cfg().i("restraint.max-ticks", 60));
        if (t > 0 && v.isValid() && !v.isDead()) v.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, t, amplifier, false, false, false));
    }

    public void prune() {
        long now = System.currentTimeMillis();
        Iterator<Long> it = immuneUntil.values().iterator();
        while (it.hasNext()) if (it.next() < now) it.remove();
        window.values().removeIf(w -> now - w[1] > 120_000L);
    }
}

package com.des.xarvoth.blade;

import com.des.xarvoth.Models;
import com.des.xarvoth.XarvothPlugin;
import org.bukkit.Bukkit;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * One blade in the world. It has a real simulated position ({@link #pos}), a motion queue, a hard chain tether,
 * block collision, sweep hit detection and a Verlet rope chain rendered as link displays.
 * It is NOT a particle trick: the ItemDisplay is moved to {@link #pos} every tick, and everything that hurts something
 * reads {@link #pos}/{@link #prev}.
 */
public final class BladeUnit {
    private final XarvothPlugin plugin;
    private final PlayerSession session;
    public final BladeId id;
    public final Vector pos = new Vector();
    public final Vector prev = new Vector();

    private final Vector heading = new Vector(0, -1, 0);
    private final Rope rope;
    private final List<ItemDisplay> links = new ArrayList<>();
    private final ArrayDeque<Motion> queue = new ArrayDeque<>();
    private Motion current;
    private ItemDisplay display;
    private ItemDisplay aura;
    private float spin;
    private boolean spawned;

    BladeUnit(XarvothPlugin plugin, PlayerSession session, BladeId id) {
        this.plugin = plugin;
        this.session = session;
        this.id = id;
        int n = Math.max(4, Math.min(16, plugin.cfg().i("chain.nodes", 10)));
        this.rope = new Rope(n);
    }

    public PlayerSession session() { return session; }
    public Player owner() { return session.owner(); }
    public World world() { return session.owner().getWorld(); }

    /** Running or queued motion. Abilities use this to refuse starting on a blade that is already out. */
    public boolean isBusy() { return current != null || !queue.isEmpty(); }

    /** Busy, or still on its way back to the hip. */
    public boolean isOut() {
        return isBusy() || (spawned && pos.distanceSquared(session.holster(id, Bukkit.getCurrentTick())) > 4.0);
    }

    public void queue(Motion m) { queue.add(m); }

    public void clearMotions() {
        if (current != null) {
            Motion m = current;
            current = null;
            try { m.onCancel(); } catch (RuntimeException ex) { plugin.getLogger().warning("Motion cancel failed: " + ex); }
        }
        queue.clear();
    }

    // ---------------------------------------------------------------- lifecycle

    void spawn() {
        if (spawned) return;
        Vector h = session.holster(id, Bukkit.getCurrentTick());
        pos.copy(h);
        prev.copy(h);
        display = spawnDisplay(h, bladeItem());
        spawned = true;
        rope.reset();
    }

    void despawn() {
        clearMotions();
        if (display != null) {
            plugin.blades().unregister(display.getUniqueId());
            display.remove();
            display = null;
        }
        despawnLinks();
        despawnAura();
        spawned = false;
    }

    void snapToHolster() {
        clearMotions();
        Vector h = session.holster(id, Bukkit.getCurrentTick());
        pos.copy(h);
        prev.copy(h);
        rope.reset();
    }

    void refreshModel() {
        if (display != null) display.setItemStack(bladeItem());
        ItemStack chain = chainItem();
        for (ItemDisplay l : links) l.setItemStack(chain);
    }

    private ItemStack bladeItem() { return Models.blade(plugin, id, session.empowered()); }

    private ItemStack chainItem() { return Models.chain(plugin, session.empowered()); }

    int linkCount() { return links.size(); }

    private ItemDisplay spawnDisplay(Vector at, ItemStack item) {
        World w = world();
        ItemDisplay d = w.spawn(new Location(w, at.getX(), at.getY(), at.getZ()), ItemDisplay.class, e -> {
            e.setItemStack(item);
            e.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
            e.setBillboard(Display.Billboard.FIXED);
            e.setPersistent(false);       // never saved: a crash cannot leave chains in the world
            e.setGravity(false);
            e.setInvulnerable(true);
            e.setBrightness(new Display.Brightness(15, 15));
            e.setTeleportDuration(2);
            e.setInterpolationDuration(2);
            e.addScoreboardTag(BladeManager.TAG);
        });
        plugin.blades().register(d.getUniqueId());
        return d;
    }

    private void despawnAura() {
        if (aura != null) {
            plugin.blades().unregister(aura.getUniqueId());
            aura.remove();
            aura = null;
        }
    }

    private void despawnLinks() {
        for (ItemDisplay l : links) {
            plugin.blades().unregister(l.getUniqueId());
            l.remove();
        }
        links.clear();
    }

    // ---------------------------------------------------------------- per tick

    void tick(int tick) {
        if (!spawned) return;
        prev.copy(pos);

        if (current == null && !queue.isEmpty()) {
            current = queue.poll();
            current.bind(this);
            current.onStart();
        }

        boolean idle = current == null;
        if (!idle) {
            boolean done;
            try {
                done = current.step();
            } catch (RuntimeException ex) {
                plugin.getLogger().warning("Blade motion failed, aborting it: " + ex);
                done = true;
            }
            if (done) {
                Motion m = current;
                current = null;
                try { m.onFinish(); } catch (RuntimeException ex) { plugin.getLogger().warning("Motion finish failed: " + ex); }
            }
        } else {
            Vector h = session.holster(id, tick);
            if (pos.distanceSquared(h) > 4.0) {
                queue.add(Motions.recall(this));          // came to rest far away: swing it back on a proper arc
            } else {
                pos.add(h.subtract(pos).multiply(0.4));   // idle follow with a soft spring
            }
        }

        tether();
        updateHeading(idle);
        render(tick);
    }

    /** The chain is a physical limit: a blade can never get further from the wielder than chain.max-length. */
    private void tether() {
        double max = plugin.cfg().d("chain.max-length", 24.0);
        Vector a = session.handAnchor(id);
        if (pos.distanceSquared(a) > max * max) {
            Vector off = pos.clone().subtract(a).normalize().multiply(max);
            pos.copy(a.add(off));
        }
    }

    private void updateHeading(boolean idle) {
        Vector mv = pos.clone().subtract(prev);
        if (!idle && mv.lengthSquared() > 1e-4) {
            mv.normalize();
            heading.multiply(0.5).add(mv.multiply(0.5));
        } else {
            Vector rest = session.forward().multiply(0.3).setY(-1);
            heading.multiply(0.7).add(rest.normalize().multiply(0.3));
        }
        if (heading.lengthSquared() < 1e-6) heading.setX(0).setY(-1).setZ(0);
        heading.normalize();
        if (!idle) spin += id.spin;
    }

    private void render(int tick) {
        World w = world();
        Quaternionf q = new Quaternionf().rotationTo(0f, 1f, 0f, (float) heading.getX(), (float) heading.getY(), (float) heading.getZ());
        if (!idle()) q.rotateY(spin);
        display.teleport(new Location(w, pos.getX(), pos.getY(), pos.getZ()));
        display.setInterpolationDelay(0);
        display.setTransformation(new Transformation(new Vector3f(0, 0, 0), q, new Vector3f(id.scale, id.scale, id.scale), new Quaternionf()));

        if (!idle() && (session.empowered() || pos.distanceSquared(prev) > 1.0)) {
            plugin.fx().dust(w, pos, 1, 0.08, id == BladeId.VORTH ? 1.5f : 1.0f, plugin.fx().energy(owner()));
        }
        // custom VFX: fading afterimages while moving fast, an energy aura while RAVAGE is active
        if (!idle() && tick % 2 == 0 && pos.distanceSquared(prev) > 0.35 && plugin.cfg().b("vfx.afterimages", true)) {
            plugin.vfx().ghost(w, pos, q, id, session.empowered());
        }
        if (session.empowered() && plugin.cfg().b("vfx.aura", true)) {
            if (aura == null) aura = spawnDisplay(pos, Models.vfx(plugin, "vfx_aura_0", true));
            aura.teleport(new Location(w, pos.getX(), pos.getY(), pos.getZ()));
            aura.setInterpolationDelay(0);
            aura.setTransformation(new Transformation(new Vector3f(0, 0, 0), new Quaternionf(q).rotateY(tick * 0.25f),
                    new Vector3f(id.scale * 1.15f, id.scale * 1.15f, id.scale * 1.15f), new Quaternionf()));
            if (tick % 3 == 0) aura.setItemStack(Models.vfx(plugin, "vfx_aura_" + ((tick / 3) % 2), true));
        } else if (aura != null) {
            despawnAura();
        }
        renderRope(w, tick);
    }

    private boolean idle() { return current == null && queue.isEmpty(); }

    private void renderRope(World w, int tick) {
        boolean far = pos.distanceSquared(session.holster(id, tick)) > 2.25;
        if (!(isBusy() || far || plugin.cfg().b("chain.idle-visible", false))) {
            if (!links.isEmpty()) despawnLinks();
            rope.reset();
            return;
        }

        Cfg_ c = new Cfg_();
        Vector anchor = session.handAnchor(id);
        Vector end = pos.clone().subtract(heading.clone().multiply(0.45 * id.scale)); // chain meets the pommel
        double dist = anchor.distance(end);
        double slack = 1.0 + 0.4 * Math.max(0.0, 1.0 - dist / 6.0);
        rope.step(anchor, end, c.gravity, c.damping, c.iterations, slack);

        int count = rope.n - 1;
        while (links.size() < count) links.add(spawnDisplay(anchor, chainItem()));

        for (int i = 0; i < count; i++) {
            Vector a = rope.p[i], b = rope.p[i + 1];
            double dx = b.getX() - a.getX(), dy = b.getY() - a.getY(), dz = b.getZ() - a.getZ();
            double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (len < 1e-4) continue;
            Quaternionf q = new Quaternionf().rotationTo(0f, 1f, 0f, (float) (dx / len), (float) (dy / len), (float) (dz / len));
            if (i % 2 == 1) q.rotateY((float) (Math.PI / 2)); // alternate links sit at right angles like a real chain
            ItemDisplay link = links.get(i);
            link.teleport(new Location(w, (a.getX() + b.getX()) / 2, (a.getY() + b.getY()) / 2, (a.getZ() + b.getZ()) / 2));
            link.setInterpolationDelay(0);
            link.setTransformation(new Transformation(new Vector3f(0, 0, 0), q,
                    new Vector3f(c.linkScale, (float) (len * 1.1), c.linkScale), new Quaternionf()));
        }
    }

    /** Snapshot of chain tuning so we read config once per rope step. */
    private final class Cfg_ {
        final double gravity = plugin.cfg().d("chain.gravity", 0.035);
        final double damping = plugin.cfg().d("chain.damping", 0.96);
        final int iterations = plugin.cfg().i("chain.iterations", 4);
        final float linkScale = (float) plugin.cfg().d("chain.link-scale", 0.45);
    }

    // ---------------------------------------------------------------- collision + hits

    /** Where moving from the current position to {@code to} first hits a block, or null if the way is clear. */
    public Vector blockHit(Vector to) {
        World w = world();
        Vector d = to.clone().subtract(pos);
        double len = d.length();
        if (len < 1e-4) return null;
        RayTraceResult r = w.rayTraceBlocks(new Location(w, pos.getX(), pos.getY(), pos.getZ()), d.multiply(1.0 / len), len,
                FluidCollisionMode.NEVER, true);
        return r == null ? null : r.getHitPosition();
    }

    /** All living entities (except the wielder) the blade passed through this tick, using a swept volume of radius r. */
    public List<LivingEntity> sweep(double r) {
        World w = world();
        BoundingBox area = BoundingBox.of(prev, pos).expand(r + 0.6);
        Vector dir = pos.clone().subtract(prev);
        double len = dir.length();
        if (len > 1e-6) dir.multiply(1.0 / len);
        UUID ownerId = owner().getUniqueId();
        List<LivingEntity> out = new ArrayList<>();
        for (Entity e : w.getNearbyEntities(area, en -> en instanceof LivingEntity && !en.getUniqueId().equals(ownerId))) {
            BoundingBox eb = e.getBoundingBox().expand(r);
            if (eb.contains(prev) || eb.contains(pos) || (len > 1e-6 && eb.rayTrace(prev, dir, len) != null)) {
                out.add((LivingEntity) e);
            }
        }
        return out;
    }

    public void impactSpark() {
        plugin.fx().spark(world(), pos, 14, 0.25);
        plugin.fx().sound(world(), pos, "blade_impact", "minecraft:block.chain.break", 0.9f, 0.8f);
    }
}

package com.des.xarvoth.ability.impl;

import com.des.xarvoth.Fx;
import com.des.xarvoth.RavageMeter;
import com.des.xarvoth.XarvothPlugin;
import com.des.xarvoth.ability.Ability;
import com.des.xarvoth.ability.AbilityCategory;
import com.des.xarvoth.ability.AbilityContext;
import com.des.xarvoth.blade.BladeId;
import com.des.xarvoth.blade.BladeUnit;
import com.des.xarvoth.blade.Motion;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * BLADE AUTHORITY 2 - ZYRATH'S FURY.
 * ZYRATH circles the wielder, then blinks around up to N targets and strikes them from a new angle every hit.
 * If a target dies or leaves, it moves on to the next one. Hard caps on targets, hits and total duration.
 */
public final class ZyrathsFury implements Ability {
    public static final String ID = "zyraths_fury";
    private final XarvothPlugin plugin;

    public ZyrathsFury(XarvothPlugin plugin) { this.plugin = plugin; }

    @Override public String id() { return ID; }
    @Override public String displayName() { return "ZYRATH'S FURY"; }
    @Override public AbilityCategory category() { return AbilityCategory.BLADE; }

    @Override
    public String activate(AbilityContext ctx) {
        Player p = ctx.owner();
        BladeUnit z = ctx.session().unit(BladeId.ZYRATH);
        if (z.isBusy()) return "ZYRATH is already out.";

        double range = ctx.cfgD("range", 10.0);
        int limit = Math.max(1, ctx.cfgI("target-limit", 3));
        List<LivingEntity> targets = new ArrayList<>();
        for (Entity e : p.getNearbyEntities(range, range, range)) {
            if (e instanceof LivingEntity le
                    && plugin.damage().canTarget(p, le)
                    && le.getLocation().distanceSquared(p.getLocation()) <= range * range
                    && p.hasLineOfSight(le)) {
                targets.add(le);
            }
        }
        if (targets.isEmpty()) return "No targets in range.";
        targets.sort(Comparator.comparingDouble(e -> e.getLocation().distanceSquared(p.getLocation())));
        if (targets.size() > limit) targets = new ArrayList<>(targets.subList(0, limit));

        int hits = Math.max(1, ctx.cfgI("hits", 8));
        double perHit = ctx.baseDamage(3.0) * BladeId.ZYRATH.damageMul;
        z.queue(new Fury(ctx, targets, hits, perHit));
        plugin.fx().sound(p.getWorld(), p.getLocation().toVector(), "zyrath_rush", "minecraft:entity.player.attack.sweep", 1.2f, 1.5f);
        return null;
    }

    private final class Fury extends Motion {
        private static final int ORBIT_TICKS = 8;
        private final AbilityContext ctx;
        private final List<LivingEntity> targets;
        private final int hitsMax;
        private final double perHit;
        private int t;
        private int hits;
        private int idx;
        private boolean blinked;

        Fury(AbilityContext ctx, List<LivingEntity> targets, int hitsMax, double perHit) {
            this.ctx = ctx;
            this.targets = targets;
            this.hitsMax = hitsMax;
            this.perHit = perHit;
        }

        @Override public boolean step() {
            t++;
            Player p = ctx.owner();
            Fx fx = plugin.fx();

            if (t <= ORBIT_TICKS) {                        // circling the wielder: the wind-up
                double ang = t * 1.0;
                Vector c = p.getLocation().toVector().add(new Vector(0, 1.2, 0));
                Vector tp = c.add(new Vector(Math.cos(ang) * 1.7, Math.sin(ang * 2) * 0.25, Math.sin(ang) * 1.7));
                u.pos.add(tp.subtract(u.pos).multiply(0.6));
                fx.dust(p.getWorld(), u.pos, 1, 0.05, 1.0f, fx.energy(p));
                return false;
            }
            if (t > ORBIT_TICKS + hitsMax * 7 + 12) return true;   // hard timeout

            LivingEntity cur = nextTarget(p);
            if (cur == null) return true;

            Vector center = cur.getBoundingBox().getCenter();
            if (!blinked) {                                   // each strike comes from a fresh angle
                double a = idx * 2.399;
                Vector from = center.clone().add(new Vector(Math.cos(a) * 2.4, 0.3 * Math.sin(idx), Math.sin(a) * 2.4));
                if (!com.des.xarvoth.Targeting.blockedBetween(p.getWorld(), center, from)) {
                    u.pos.copy(from);
                    u.prev.copy(from);
                }
                blinked = true;
            }

            Vector d = center.clone().subtract(u.pos);
            double dist = d.length();
            if (dist <= 1.1) {
                Vector kb = dist > 1e-4 ? d.clone().normalize().multiply(0.25) : new Vector(0, 0, 0);
                kb.setY(0.1);
                ctx.hit(BladeId.ZYRATH, cur, perHit, RavageMeter.Source.BLADE_HIT, kb);
                fx.slash(p.getWorld(), center, d, 1.8, fx.energy(p));
                fx.sound(p.getWorld(), center, "zyrath_hit", "minecraft:entity.player.attack.crit", 0.9f, 1.4f + (hits % 4) * 0.1f);
                hits++;
                idx++;
                blinked = false;
                return hits >= hitsMax;
            }
            u.pos.add(d.multiply(Math.min(2.2, dist - 0.4) / dist));
            return false;
        }

        private LivingEntity nextTarget(Player p) {
            for (int k = 0; k < targets.size(); k++) {
                int i = (idx + k) % targets.size();
                LivingEntity e = targets.get(i);
                if (e.isValid() && !e.isDead() && e.getWorld().equals(p.getWorld())) {
                    if (i != idx % targets.size()) blinked = false;
                    idx = i;
                    return e;
                }
            }
            return null;
        }
    }
}

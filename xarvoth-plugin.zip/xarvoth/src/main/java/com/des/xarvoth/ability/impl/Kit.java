package com.des.xarvoth.ability.impl;

import com.des.xarvoth.RavageMeter;
import com.des.xarvoth.Targeting;
import com.des.xarvoth.ability.AbilityContext;
import com.des.xarvoth.blade.BladeId;
import com.des.xarvoth.blade.BladeUnit;
import com.des.xarvoth.blade.Hitbook;
import com.des.xarvoth.blade.Motions;
import com.des.xarvoth.blade.PlayerSession;
import org.bukkit.Color;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.BooleanSupplier;

/** Shared building blocks for abilities. Everything that touches an enemy still goes through AbilityContext#hit. */
public final class Kit {
    private Kit() {}

    public static final Vector ZERO = new Vector(0, 0, 0);

    public static boolean alive(LivingEntity e) { return e != null && e.isValid() && !e.isDead(); }

    public static Vector center(LivingEntity e) { return e.getBoundingBox().getCenter(); }

    /** Valid targets near a point, nearest first, hard-limited. */
    public static List<LivingEntity> around(AbilityContext ctx, Vector c, double radius, int limit, boolean los) {
        Player p = ctx.owner();
        World w = p.getWorld();
        List<LivingEntity> out = new ArrayList<>();
        for (LivingEntity e : w.getNearbyLivingEntities(new Location(w, c.getX(), c.getY(), c.getZ()), radius)) {
            if (!ctx.plugin().damage().canTarget(p, e)) continue;
            if (los && !p.hasLineOfSight(e)) continue;
            out.add(e);
        }
        out.sort(Comparator.comparingDouble(e -> e.getLocation().toVector().distanceSquared(c)));
        return out.size() > limit ? new ArrayList<>(out.subList(0, limit)) : out;
    }

    /** The entity the wielder is aiming at, else the nearest visible valid target within 60% of the range. */
    public static LivingEntity targetEntity(AbilityContext ctx, double range) {
        Targeting.Aim a = Targeting.aim(ctx.owner(), range);
        if (a != null && a.entity() != null && ctx.plugin().damage().canTarget(ctx.owner(), a.entity())) return a.entity();
        List<LivingEntity> l = around(ctx, ctx.owner().getLocation().toVector(), range * 0.6, 1, true);
        return l.isEmpty() ? null : l.get(0);
    }

    /** Where the wielder points: hit position, else a point in front of them, snapped down to the ground. */
    public static Vector aimGround(AbilityContext ctx, double range) {
        Player p = ctx.owner();
        Targeting.Aim a = Targeting.aim(p, range);
        Vector pt = a != null ? a.point().clone() : p.getLocation().toVector().add(ctx.session().forward().multiply(Math.min(range, 9)));
        return ground(p.getWorld(), pt);
    }

    public static Vector ground(World w, Vector at) {
        RayTraceResult r = w.rayTraceBlocks(new Location(w, at.getX(), at.getY() + 1.0, at.getZ()), new Vector(0, -1, 0), 25,
                FluidCollisionMode.NEVER, true);
        return r != null ? r.getHitPosition() : at.clone();
    }

    public static Vector kb(Vector from, Vector to, double horizontal, double up) {
        Vector d = to.clone().subtract(from).setY(0);
        d = d.lengthSquared() > 1e-4 ? d.normalize().multiply(horizontal) : new Vector(0, 0, 0);
        d.setY(up);
        return d;
    }

    /** Area damage with falloff. Returns who was actually hit. */
    public static List<LivingEntity> impact(AbilityContext ctx, BladeId blade, Vector c, double radius, double base,
                                            int limit, double horizontal, double up) {
        List<LivingEntity> hit = new ArrayList<>();
        for (LivingEntity e : around(ctx, c, radius, limit, false)) {
            double d = e.getLocation().toVector().distance(c);
            if (d > radius * 1.25) continue;
            double falloff = 1.0 - 0.4 * Math.min(1.0, d / radius);
            if (ctx.hit(blade, e, base * falloff, RavageMeter.Source.BLADE_HIT, kb(c, e.getLocation().toVector(), horizontal, up))) hit.add(e);
        }
        return hit;
    }

    /** Drag an entity toward a point (never faster than speed, slows near the point). */
    public static void pull(LivingEntity v, Vector point, double speed) {
        Vector to = point.clone().subtract(v.getLocation().toVector());
        double dist = to.length();
        if (dist < 0.5) return;
        Vector vel = to.multiply(Math.min(speed, 0.25 + dist * 0.18) / dist);
        if (v.isOnGround() && vel.getY() < 0.08) vel.setY(0.08);
        v.setVelocity(vel);
    }

    /** Keep an entity inside a sphere. @return true if it had to be pushed back. */
    public static boolean confine(LivingEntity v, Vector center, double radius) {
        Vector off = v.getLocation().toVector().subtract(center);
        double d = off.length();
        if (d <= radius) return false;
        Vector back = off.multiply(-1.0 / d).multiply(Math.min(0.9, 0.25 + (d - radius) * 0.5));
        back.setY(Math.max(back.getY(), 0.0));
        v.setVelocity(back);
        return true;
    }

    /** Hold an entity at roughly height y (suspension). */
    public static void hold(LivingEntity v, double y) {
        double vy = Math.max(-0.5, Math.min(0.8, (y - v.getLocation().getY()) * 0.35));
        v.setVelocity(new Vector(0, vy, 0));
        v.setFallDistance(0);
    }

    public static String requireIdle(PlayerSession s, BladeId... ids) {
        for (BladeId id : ids) if (s.unit(id).isBusy()) return id.key.toUpperCase() + " is already out.";
        return null;
    }

    public static BooleanSupplier idle(PlayerSession s, BladeId... ids) {
        return () -> {
            for (BladeId id : ids) if (s.unit(id).isBusy()) return false;
            return true;
        };
    }

    public static String begin(AbilityContext ctx, com.des.xarvoth.blade.Effect e) {
        return ctx.session().addEffect(e) ? null : "Too many techniques are active.";
    }

    /** Hit detection for a blade moving through the world: each victim once per Hitbook, capped by limit. */
    public static Motions.Hook cut(AbilityContext ctx, BladeId id, Hitbook book, double dmg, int limit, double radiusMul) {
        return (u, t) -> {
            Player p = ctx.owner();
            Color col = ctx.plugin().fx().energy(p);
            ctx.plugin().fx().dust(p.getWorld(), u.pos, 2, 0.1, id == BladeId.VORTH ? 1.7f : 1.1f, col);
            for (LivingEntity victim : u.sweep(id.hitRadius * radiusMul)) {
                if (!ctx.plugin().damage().canTarget(p, victim)) continue;
                if (book.size() >= limit && !book.has(victim.getUniqueId())) continue;
                if (!book.first(victim.getUniqueId())) continue;
                Vector dir = u.pos.clone().subtract(u.prev);
                Vector kb = dir.lengthSquared() > 1e-4 ? dir.clone().normalize().multiply(0.7) : new Vector(0, 0, 0);
                kb.setY(0.3);
                if (ctx.hit(id, victim, dmg * id.damageMul, RavageMeter.Source.BLADE_HIT, kb)) {
                    ctx.plugin().fx().slash(p.getWorld(), victim.getBoundingBox().getCenter(), dir, 2.0, col);
                    ctx.plugin().fx().sound(p.getWorld(), u.pos, "blade_hit", "xarvoth:blade.hit", 0.8f, id == BladeId.VORTH ? 0.7f : 1.3f);
                }
            }
        };
    }

    public static BladeUnit vorth(PlayerSession s) { return s.unit(BladeId.VORTH); }
    public static BladeUnit zyrath(PlayerSession s) { return s.unit(BladeId.ZYRATH); }

    /** Damage multiplier for execution-style strikes: more for missing health, a big bonus under the threshold (never for players). */
    public static double executeMult(LivingEntity t, double missingBonus, double threshold, double executeMult) {
        org.bukkit.attribute.AttributeInstance max = t.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH);
        double maxHp = max != null ? max.getValue() : Math.max(1.0, t.getHealth());
        double frac = Math.max(0.0, Math.min(1.0, t.getHealth() / maxHp));
        double mult = 1.0 + (1.0 - frac) * missingBonus;
        if (!(t instanceof Player) && frac <= threshold) mult *= executeMult;
        return mult;
    }

    public static double healthFraction(LivingEntity t) {
        org.bukkit.attribute.AttributeInstance max = t.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH);
        double maxHp = max != null ? max.getValue() : Math.max(1.0, t.getHealth());
        return Math.max(0.0, Math.min(1.0, t.getHealth() / maxHp));
    }
}

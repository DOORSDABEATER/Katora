package com.des.xarvoth.ability.impl;

import com.des.xarvoth.XarvothPlugin;
import com.des.xarvoth.ability.AbilityCategory;
import com.des.xarvoth.ability.AbilityContext;
import com.des.xarvoth.blade.Barrier;
import com.des.xarvoth.blade.BladeId;
import com.des.xarvoth.blade.BladeUnit;
import com.des.xarvoth.blade.Motions;
import com.des.xarvoth.blade.PlayerSession;
import com.des.xarvoth.blade.Script;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.List;

/**
 * BLADE ULTIMATE - CROWN OF THE RAVAGER. Pure steel; the chains only follow.
 *  1. CROWN: both blades spiral up and circle above the wielder's head on a ring of light that tightens as it charges.
 *  2. RAVAGE: they tear out into the battlefield and cut down every enemy in range in turn, blinking to a fresh angle for every
 *     strike. Strike speed and damage escalate through the whole assault.
 *  3. EXECUTION: both rise over the thickest cluster and crash down together in a catastrophic finishing blow with lightning.
 */
public final class CrownOfTheRavager extends BaseAbility {
    public CrownOfTheRavager(XarvothPlugin plugin) { super(plugin, "crown_of_the_ravager", "CROWN OF THE RAVAGER", AbilityCategory.ULTIMATE); }

    @Override
    protected String start(AbilityContext ctx) {
        Player p = ctx.owner();
        PlayerSession s = ctx.session();
        String busy = Kit.requireIdle(s, BladeId.VORTH, BladeId.ZYRATH);
        if (busy != null) return busy;
        World w = p.getWorld();
        double range = Math.min(ctx.cfgD("range", 14.0), plugin.cfg().d("chain.max-length", 24.0) - 6.0);
        if (Kit.around(ctx, p.getLocation().toVector(), range, 1, false).isEmpty()) return "No enemies in range.";

        BladeUnit v = s.unit(BladeId.VORTH);
        BladeUnit z = s.unit(BladeId.ZYRATH);
        int strikes = ctx.cfgI("strikes-per-blade", 12);
        double perHit = ctx.baseDamage(3.5);
        Vector[] focus = {p.getLocation().toVector()};
        Barrier crash = new Barrier(2, () -> finisher(ctx, focus[0]));

        Script sc = new Script().exclusive(true);
        sc.run(() -> {
            for (BladeId id : BladeId.values()) {
                s.unit(id).queue(new Motions.Path(i -> {
                    double f = i / 26.0;
                    double ang = i * (0.45 + f * 0.5) * id.side + (id == BladeId.VORTH ? 0 : Math.PI);
                    return p.getLocation().toVector().add(new Vector(Math.cos(ang) * 2.3, 3.4 + f * 0.4, Math.sin(ang) * 2.3));
                }, 26, 0.5));
            }
            plugin.fx().sound(w, p.getLocation().toVector(), "crown_rise", "xarvoth:crown.rise", 1.8f, 1.0f);
        });
        sc.during(26, i -> {
            double f = i / 26.0;
            Vector top = p.getLocation().toVector().add(new Vector(0, 3.4, 0));
            plugin.fx().ring(w, top, 2.3 - f * 0.5, 28, plugin.fx().energy(p));
            if (i % 6 == 0) plugin.fx().spark(w, top, 10, 1.0);
        });
        sc.waitIdle(v, z);
        sc.run(() -> {
            java.util.function.Supplier<List<LivingEntity>> targets = () -> Kit.around(ctx, p.getLocation().toVector(), range, 8, false);
            for (BladeId id : BladeId.values()) {
                s.unit(id).queue(new AssaultMotion(ctx, id, targets, strikes, perHit, 0, 3.4, f -> 1.0 + f * 0.8));
            }
            plugin.fx().sound(w, p.getLocation().toVector(), "crown_assault", "xarvoth:crown.assault", 1.8f, 1.0f);
        });
        sc.waitIdle(v, z);
        sc.run(() -> {
            List<LivingEntity> l = Kit.around(ctx, p.getLocation().toVector(), range, 8, false);
            Vector c = new Vector();
            for (LivingEntity e : l) c.add(Kit.center(e));
            focus[0] = l.isEmpty() ? Kit.ground(w, p.getLocation().toVector().add(s.forward().multiply(5.0))) : Kit.ground(w, c.multiply(1.0 / l.size()));
            Vector right = s.right();
            Vector f0 = focus[0];
            v.queue(new Motions.Arc(() -> f0.clone().add(right.clone().multiply(1.8)).add(new Vector(0, 10.0, 0)), right.clone().multiply(4.0), 10, Motions.Easing.OUT));
            z.queue(new Motions.Arc(() -> f0.clone().add(right.clone().multiply(-1.8)).add(new Vector(0, 10.0, 0)), right.clone().multiply(-4.0), 10, Motions.Easing.OUT));
        });
        sc.waitIdle(v, z);
        sc.run(() -> { v.queue(new Motions.Hold(6)); z.queue(new Motions.Hold(6)); });
        sc.during(6, i -> {
            plugin.fx().ring(w, focus[0], 8.0 - i, 48, plugin.fx().energy(p));
            if (i == 0) plugin.fx().rune(p, w, focus[0], 8.5, 18);
            if (i == 0) plugin.fx().sound(w, focus[0], "crown_charge", "xarvoth:crown.charge", 1.8f, 1.0f);
        });
        sc.waitIdle(v, z);
        sc.run(() -> {
            Vector f0 = focus[0];
            v.queue(new Motions.Arc(() -> f0.clone().add(new Vector(0, 0.5, 0)), Kit.ZERO.clone(), 5, Motions.Easing.IN).then(crash::arrive));
            z.queue(new Motions.Arc(() -> f0.clone().add(new Vector(0, 0.5, 0)), Kit.ZERO.clone(), 5, Motions.Easing.IN).then(crash::arrive));
        });
        sc.waitIdle(v, z);
        sc.onEnd(() -> { v.clearMotions(); z.clearMotions(); });
        return Kit.begin(ctx, sc);
    }

    private void finisher(AbilityContext ctx, Vector c) {
        Player p = ctx.owner();
        if (!p.isOnline()) return;
        World w = p.getWorld();
        double radius = ctx.cfgD("finisher-radius", 8.0);
        Kit.impact(ctx, BladeId.VORTH, c, radius, ctx.baseDamage(34.0), 14, 1.3, 1.0);
        plugin.fx().shockwave(w, c, radius, plugin.fx().energy(p));
        plugin.fx().ring(w, c, radius * 0.5, 36, plugin.fx().energy(p));
        for (double y = 0; y < 16; y += 0.8) plugin.fx().dust(w, c.clone().add(new Vector(0, y, 0)), 4, 0.6, 2.0f, plugin.fx().energy(p));
        for (int i = 0; i < 6; i++) {
            double a = i * Math.PI / 3;
            w.strikeLightningEffect(new Location(w, c.getX() + Math.cos(a) * radius * 0.5, c.getY(), c.getZ() + Math.sin(a) * radius * 0.5));
        }
        plugin.fx().beam(p, w, c, 20.0, 3.8, 18);
        plugin.fx().sound(w, c, "crown_finisher", "xarvoth:crown.finisher", 2.0f, 0.8f);
    }
}

package com.des.xarvoth.ability.impl;

import com.des.xarvoth.RavageMeter;
import com.des.xarvoth.XarvothPlugin;
import com.des.xarvoth.ability.AbilityCategory;
import com.des.xarvoth.ability.AbilityContext;
import com.des.xarvoth.blade.BladeId;
import com.des.xarvoth.blade.BladeUnit;
import com.des.xarvoth.blade.Hitbook;
import com.des.xarvoth.blade.Motions;
import com.des.xarvoth.blade.PlayerSession;
import com.des.xarvoth.blade.Script;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.function.Supplier;

/**
 * CONVERGENCE 1 - CROSSBOUND EXECUTION. The blades fly to opposite sides of one target and their chains pull taut across it,
 * binding it (a capped root). After a beat of tension both blades tear through it in opposite directions along crossing lines,
 * and a binding-bonus execution strike lands where the paths cross.
 */
public final class CrossboundExecution extends BaseAbility {
    public CrossboundExecution(XarvothPlugin plugin) { super(plugin, "crossbound_execution", "CROSSBOUND EXECUTION", AbilityCategory.CONVERGENCE); }

    @Override
    protected String start(AbilityContext ctx) {
        Player p = ctx.owner();
        PlayerSession s = ctx.session();
        String busy = Kit.requireIdle(s, BladeId.VORTH, BladeId.ZYRATH);
        if (busy != null) return busy;
        LivingEntity t = Kit.targetEntity(ctx, ctx.cfgD("range", 16.0));
        if (t == null) return "No target in range.";

        World w = p.getWorld();
        BladeUnit v = s.unit(BladeId.VORTH);
        BladeUnit z = s.unit(BladeId.ZYRATH);
        Vector c0 = Kit.center(t);
        Vector toT = c0.clone().subtract(p.getLocation().toVector()).setY(0);
        Vector axis = toT.lengthSquared() > 1e-4 ? new Vector(toT.getZ(), 0, -toT.getX()).normalize() : s.right();
        Supplier<Vector> tc = () -> Kit.alive(t) ? Kit.center(t) : c0.clone();
        double dmg = ctx.baseDamage(12.0);
        boolean[] bound = {false};

        Script sc = new Script();
        sc.run(() -> {
            for (BladeId id : BladeId.values()) {
                BladeUnit u = s.unit(id);
                double sg = id.side;
                u.queue(new Motions.Homing(() -> tc.get().add(axis.clone().multiply(3.4 * sg)).add(new Vector(0, 0.6, 0)), 3.0, 0.8, 16));
                sc.own(s.strand(() -> u.pos.clone(), tc, 1.0, 90, 6));
            }
            plugin.fx().sound(w, p.getLocation().toVector(), "cross_launch", "xarvoth:cross.launch", 1.3f, 1.0f);
        });
        sc.waitIdle(v, z);
        sc.run(() -> {
            bound[0] = plugin.restraints().restrain(p, t, ctx.cfgI("bind-ticks", 24)) > 0;
            plugin.fx().sound(w, tc.get(), "cross_bind", "xarvoth:cross.bind", 1.4f, 1.0f);
            plugin.fx().shockwave(w, tc.get(), 1.6, plugin.fx().energy(p));
        });
        sc.waitTicks(8);
        sc.run(() -> {
            for (BladeId id : BladeId.values()) {
                double sg = id.side;
                s.unit(id).queue(new Motions.Arc(() -> tc.get().add(axis.clone().multiply(-3.4 * sg)).add(new Vector(0, 0.2, 0)),
                        new Vector(0, 0.4, 0), 5, Motions.Easing.IN).stopOnBlock()
                        .hook(Kit.cut(ctx, id, new Hitbook(), dmg, 5, 1.3)));
            }
        });
        sc.waitIdle(v, z);
        sc.run(() -> {
            Vector c = tc.get();
            if (Kit.alive(t)) {
                double mult = bound[0] ? ctx.cfgD("bound-multiplier", 1.3) : 1.0;
                ctx.hit(BladeId.VORTH, t, ctx.baseDamage(14.0) * mult, RavageMeter.Source.BLADE_HIT, new Vector(0, 0.3, 0));
            }
            Vector a = axis.clone().add(new Vector(0, 0.8, 0));
            Vector b = axis.clone().add(new Vector(0, -0.8, 0));
            plugin.fx().slash(w, c, a, 5.0, plugin.fx().energy(p));
            plugin.fx().slash(w, c, b, 5.0, plugin.fx().energy(p));
            plugin.fx().spark(w, c, 40, 0.7);
            plugin.fx().sound(w, c, "cross_final", "xarvoth:cross.final", 1.6f, 1.0f);
        });
        return Kit.begin(ctx, sc);
    }
}

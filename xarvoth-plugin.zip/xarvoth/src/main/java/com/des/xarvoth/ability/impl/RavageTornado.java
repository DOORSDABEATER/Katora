package com.des.xarvoth.ability.impl;

import com.des.xarvoth.RavageMeter;
import com.des.xarvoth.Targeting;
import com.des.xarvoth.XarvothPlugin;
import com.des.xarvoth.ability.AbilityCategory;
import com.des.xarvoth.ability.AbilityContext;
import com.des.xarvoth.blade.BladeId;
import com.des.xarvoth.blade.BladeUnit;
import com.des.xarvoth.blade.Motions;
import com.des.xarvoth.blade.PlayerSession;
import com.des.xarvoth.blade.Script;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * CONVERGENCE 9 - RAVAGE TORNADO. A vortex of steel and chain leaves the wielder and advances along the ground, stopping at walls.
 * Both blades spin through it on different radii; two chains fall from them to the eye of the storm. Everything in range is
 * sucked inward and around the eye (a capped, velocity-based pull - nothing is rooted), and the blades cut what they reach on a
 * fixed beat. When it dies it detonates outward.
 */
public final class RavageTornado extends BaseAbility {
    public RavageTornado(XarvothPlugin plugin) { super(plugin, "ravage_tornado", "RAVAGE TORNADO", AbilityCategory.CONVERGENCE); }

    @Override
    protected String start(AbilityContext ctx) {
        Player p = ctx.owner();
        PlayerSession s = ctx.session();
        String busy = Kit.requireIdle(s, BladeId.VORTH, BladeId.ZYRATH);
        if (busy != null) return busy;
        World w = p.getWorld();

        Vector dir = s.forward();
        Vector[] eye = {Kit.ground(w, p.getLocation().toVector().add(dir.clone().multiply(3.0)))};
        int total = ctx.cfgI("duration-ticks", 60);
        double pullR = ctx.cfgD("suction-radius", 7.0);
        double speed = ctx.cfgD("advance-speed", 0.17);
        double dmg = ctx.baseDamage(3.0);
        BladeUnit v = s.unit(BladeId.VORTH);
        BladeUnit z = s.unit(BladeId.ZYRATH);
        Map<String, Integer> next = new HashMap<>();
        Map<UUID, Integer> count = new HashMap<>();

        Script sc = new Script().exclusive(true);
        sc.run(() -> {
            for (BladeId id : BladeId.values()) {
                boolean vo = id == BladeId.VORTH;
                s.unit(id).queue(new Motions.Path(i -> {
                    double ang = i * 0.7 * id.side + (vo ? 0 : Math.PI);
                    double r = vo ? 4.0 : 2.6;
                    return eye[0].clone().add(new Vector(Math.cos(ang) * r, 1.0 + Math.sin(i * 0.4) * 1.2, Math.sin(ang) * r));
                }, total, 0.55).hook((u, t) -> {
                    plugin.fx().dust(w, u.pos, 2, 0.1, vo ? 1.7f : 1.1f, plugin.fx().energy(p));
                    for (LivingEntity e : u.sweep(id.hitRadius * 1.5)) {
                        if (!plugin.damage().canTarget(p, e)) continue;
                        UUID eid = e.getUniqueId();
                        String key = id.key + eid;
                        if (t < next.getOrDefault(key, 0) || count.getOrDefault(eid, 0) >= 8) continue;
                        next.put(key, t + 6);
                        if (ctx.hit(id, e, dmg * id.damageMul, RavageMeter.Source.BLADE_HIT, Kit.kb(eye[0], e.getLocation().toVector(), 0.3, 0.25))) {
                            count.merge(eid, 1, Integer::sum);
                            plugin.fx().slash(w, Kit.center(e), u.pos.clone().subtract(u.prev), 2.0, plugin.fx().energy(p));
                        }
                    }
                }));
                sc.own(s.strand(() -> s.unit(id).pos.clone(), () -> eye[0].clone().add(new Vector(0, 0.3, 0)), 1.1, total + 30, 6));
            }
            plugin.fx().sound(w, eye[0], "tornado_start", "xarvoth:tornado.start", 1.5f, 0.9f);
        });
        sc.during(total, i -> {
            Vector nxt = eye[0].clone().add(dir.clone().multiply(speed));
            if (!Targeting.blockedBetween(w, eye[0].clone().add(new Vector(0, 1, 0)), nxt.clone().add(dir.clone().multiply(1.5)).add(new Vector(0, 1, 0)))) {
                eye[0] = Kit.ground(w, nxt);
            }
            for (LivingEntity e : Kit.around(ctx, eye[0], pullR, 10, false)) {
                Vector in = eye[0].clone().subtract(e.getLocation().toVector());
                double len = in.length();
                if (len < 0.8) continue;
                Vector tang = new Vector(-in.getZ(), 0, in.getX()).normalize().multiply(0.22);
                Vector vel = in.multiply(Math.min(0.5, 0.2 + len * 0.1) / len).add(tang);
                vel.setY(Math.max(vel.getY(), 0.07));
                e.setVelocity(vel);
            }
            if (i % 2 == 0) {
                double r = 1.0 + (i % 12) * 0.5;
                plugin.fx().ring(w, eye[0], r, 16, plugin.fx().energy(p));
                plugin.fx().spark(w, eye[0].clone().add(new Vector(0, 1.5, 0)), 4, 0.6);
            }
        });
        sc.run(() -> {
            Kit.impact(ctx, BladeId.VORTH, eye[0], 5.5, ctx.baseDamage(14.0), 10, 1.1, 0.7);
            plugin.fx().shockwave(w, eye[0], 5.5, plugin.fx().energy(p));
            plugin.fx().sound(w, eye[0], "tornado_end", "xarvoth:tornado.end", 1.6f, 0.8f);
        });
        sc.waitIdle(v, z);
        sc.onEnd(() -> { v.clearMotions(); z.clearMotions(); });
        return Kit.begin(ctx, sc);
    }
}

package com.des.xarvoth.ability.impl;

import com.des.xarvoth.RavageMeter;
import com.des.xarvoth.XarvothPlugin;
import com.des.xarvoth.ability.AbilityCategory;
import com.des.xarvoth.ability.AbilityContext;
import com.des.xarvoth.blade.BladeId;
import com.des.xarvoth.blade.BladeUnit;
import com.des.xarvoth.blade.Motion;
import com.des.xarvoth.blade.Motions;
import com.des.xarvoth.blade.PlayerSession;
import com.des.xarvoth.blade.Script;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.List;

/**
 * CONVERGENCE 6 - ENDLESS PURSUIT. VORTH drives itself into the ground at the target as an anchor and its chain leashes the target
 * to that spot (a soft confinement). ZYRATH then hunts it relentlessly: strike, blink back, strike, each hit harder than the last,
 * every hit slowing the target. If the target dies, ZYRATH leaps along the chain of enemies near it and keeps going. Strike count
 * and total time are capped.
 */
public final class EndlessPursuit extends BaseAbility {
    public EndlessPursuit(XarvothPlugin plugin) { super(plugin, "endless_pursuit", "ENDLESS PURSUIT", AbilityCategory.CONVERGENCE); }

    @Override
    protected String start(AbilityContext ctx) {
        Player p = ctx.owner();
        PlayerSession s = ctx.session();
        String busy = Kit.requireIdle(s, BladeId.VORTH, BladeId.ZYRATH);
        if (busy != null) return busy;
        LivingEntity t = Kit.targetEntity(ctx, ctx.cfgD("range", 14.0));
        if (t == null) return "No target in range.";

        World w = p.getWorld();
        BladeUnit v = s.unit(BladeId.VORTH);
        BladeUnit z = s.unit(BladeId.ZYRATH);
        LivingEntity[] cur = {t};
        Vector anchor = Kit.ground(w, t.getLocation().toVector());
        double leash = ctx.cfgD("leash-radius", 9.0);
        boolean[] done = {false};

        Script sc = new Script();
        sc.run(() -> {
            v.queue(new Motions.Homing(() -> anchor.clone().add(new Vector(0, 0.4, 0)), 3.0, 0.8, 14));
            plugin.fx().sound(w, p.getLocation().toVector(), "pursuit_start", "xarvoth:pursuit.start", 1.3f, 1.0f);
        });
        sc.waitIdle(v);
        sc.run(() -> {
            v.queue(new Motions.Follow(() -> anchor.clone().add(new Vector(0, 0.4, 0)), n -> done[0]));
            sc.own(s.strand(() -> v.pos.clone(), () -> cur[0] != null && Kit.alive(cur[0]) ? Kit.center(cur[0]) : null, 1.15, 160, 7));
            z.queue(new Pursuit(ctx, cur, () -> done[0] = true));
        });
        sc.step(() -> { }, () -> {
            if (done[0] || !z.isBusy()) return true;
            if (Kit.alive(cur[0])) Kit.confine(cur[0], anchor, leash);
            return false;
        });
        sc.run(() -> plugin.fx().shockwave(w, anchor, 2.5, plugin.fx().energy(p)));
        sc.onEnd(() -> { done[0] = true; v.clearMotions(); z.clearMotions(); });
        return Kit.begin(ctx, sc);
    }

    private final class Pursuit extends Motion {
        private final AbilityContext ctx;
        private final LivingEntity[] cur;
        private final Runnable onDone;
        private final int strikes;
        private final double base;
        private int t;
        private int hits;
        private int cooldown;
        private Vector lastKnown;

        Pursuit(AbilityContext ctx, LivingEntity[] cur, Runnable onDone) {
            this.ctx = ctx;
            this.cur = cur;
            this.onDone = onDone;
            this.strikes = ctx.cfgI("strikes", 10);
            this.base = ctx.baseDamage(4.0);
            this.lastKnown = Kit.center(cur[0]);
        }

        @Override public boolean step() {
            t++;
            Player p = ctx.owner();
            if (t > 110 || hits >= strikes) return true;
            if (cooldown > 0) { cooldown--; u.pos.add(new Vector(0, 0.05, 0)); return false; }

            if (!Kit.alive(cur[0])) {                       // chain jump: leap to the nearest other enemy
                List<LivingEntity> next = Kit.around(ctx, lastKnown, 12.0, 1, false);
                if (next.isEmpty()) return true;
                cur[0] = next.get(0);
                plugin.fx().sound(p.getWorld(), u.pos, "pursuit_jump", "xarvoth:pursuit.jump", 1.0f, 1.2f);
            }
            lastKnown = Kit.center(cur[0]);
            Vector d = lastKnown.clone().subtract(u.pos);
            double dist = d.length();
            if (dist <= 1.2) {
                double dmg = base * (1.0 + 0.1 * hits) * BladeId.ZYRATH.damageMul;
                Vector away = dist > 1e-4 ? d.clone().normalize() : new Vector(1, 0, 0);
                if (ctx.hit(BladeId.ZYRATH, cur[0], dmg, RavageMeter.Source.BLADE_HIT, away.clone().multiply(0.2).setY(0.1))) {
                    plugin.restraints().slow(cur[0], 20, 1);
                    plugin.fx().slash(p.getWorld(), lastKnown, d, 2.2, plugin.fx().energy(p));
                    plugin.fx().sound(p.getWorld(), lastKnown, "blade_hit", "xarvoth:blade.hit", 0.9f, 1.0f + hits * 0.05f);
                }
                hits++;
                cooldown = 3;
                Vector back = lastKnown.clone().subtract(away.multiply(3.0)).add(new Vector(0, 0.6, 0));
                if (!com.des.xarvoth.Targeting.blockedBetween(p.getWorld(), lastKnown, back)) { u.pos.copy(back); u.prev.copy(back); }
                return hits >= strikes;
            }
            u.pos.add(d.multiply(Math.min(1.9, dist - 0.4) / dist));
            plugin.fx().dust(p.getWorld(), u.pos, 1, 0.05, 1.0f, plugin.fx().energy(p));
            return false;
        }

        @Override public void onFinish() { onDone.run(); }
    }
}

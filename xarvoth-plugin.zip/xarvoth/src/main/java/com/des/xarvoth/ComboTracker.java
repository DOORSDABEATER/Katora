package com.des.xarvoth;

import com.des.xarvoth.ability.AbilityCategory;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Flow combos: using an ability from a DIFFERENT authority than the previous one, inside the time window,
 * extends a flow chain (blade -> chain -> blade ...). Each link adds a configurable damage bonus,
 * capped by combo.max-chain, so combos reward switching instead of spamming one button.
 */
public final class ComboTracker {
    public record Flow(int links, double multiplier) {}

    private static final class State {
        AbilityCategory last;
        long expires;
        int links;
    }

    private final XarvothPlugin plugin;
    private final Map<UUID, State> states = new HashMap<>();

    public ComboTracker(XarvothPlugin plugin) { this.plugin = plugin; }

    /** What flow would using {@code cat} right now produce? Does not change state. */
    public Flow peek(Player p, AbilityCategory cat) {
        State s = states.get(p.getUniqueId());
        int links = 0;
        if (s != null && s.last != null && System.currentTimeMillis() <= s.expires && s.last != cat) {
            links = Math.min(s.links + 1, Math.max(0, plugin.cfg().i("combo.max-chain", 5) - 1));
        }
        return new Flow(links, 1.0 + links * plugin.cfg().d("combo.bonus-per-link", 0.08));
    }

    public void record(Player p, AbilityCategory cat, Flow flow) {
        State s = states.computeIfAbsent(p.getUniqueId(), k -> new State());
        s.last = cat;
        s.links = flow.links();
        s.expires = System.currentTimeMillis() + plugin.cfg().i("combo.window-ms", 4000);
    }

    public void forget(UUID id) { states.remove(id); }
}

package com.des.xarvoth.ability;

import com.des.xarvoth.ComboTracker;
import com.des.xarvoth.XarvothPlugin;
import com.des.xarvoth.blade.PlayerSession;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;

/** The activation pipeline: holding check, debounce, cooldown, combo flow, activate, then cost + feedback. */
public final class AbilityService {
    private final XarvothPlugin plugin;
    private final Map<UUID, Integer> lastUse = new HashMap<>();

    public AbilityService(XarvothPlugin plugin) { this.plugin = plugin; }

    public void use(Player p) {
        PlayerSession s = plugin.blades().session(p);
        if (s == null || !s.isHolding() || !p.isValid() || p.isDead()) return;

        int now = Bukkit.getCurrentTick();
        Integer last = lastUse.get(p.getUniqueId());
        if (last != null && now - last < 3) return;     // one click must never start two casts
        lastUse.put(p.getUniqueId(), now);

        if (s.hasExclusive()) { deny(p, "&c\u2716 A technique is still unfolding."); return; }

        Ability a = plugin.selection().selected(p);
        if (a == null) { deny(p, "&7No abilities installed."); return; }

        long remaining = plugin.cooldowns().remainingMs(p.getUniqueId(), a.id());
        if (remaining > 0) {
            deny(p, "&8[&b" + a.category().label() + "&8] &f" + a.displayName() + " &c" + String.format(Locale.ROOT, "%.1fs", remaining / 1000.0));
            return;
        }

        ComboTracker.Flow flow = plugin.combos().peek(p, a.category());
        AbilityContext ctx = new AbilityContext(plugin, p, a, s, flow);
        String fail;
        try {
            fail = a.activate(ctx);
        } catch (RuntimeException ex) {
            plugin.getLogger().log(Level.SEVERE, "Ability " + a.id() + " threw during activation", ex);
            s.interrupt();
            fail = "Ability error (see console).";
        }
        if (fail != null) { deny(p, "&c\u2716 " + fail); return; }

        plugin.cooldowns().start(p.getUniqueId(), a.id(), plugin.cfg().cooldownMs(a.id()));
        plugin.combos().record(p, a.category(), flow);
        String chain = flow.links() > 0 ? " &b\u26A1x" + (flow.links() + 1) : "";
        plugin.hud().flash(p, "&8[&b" + a.category().label() + "&8] &f&l" + a.displayName() + chain, 900);
    }

    public void activateRavage(Player p) {
        PlayerSession s = plugin.blades().session(p);
        if (s == null || !s.isHolding()) return;
        String err = plugin.meter().activate(p);
        if (err != null) { deny(p, "&c\u2716 " + err); return; }
        plugin.fx().ravageBurst(p);
        plugin.hud().flash(p, "&f&l\u26A1 RAVAGE ENCHANTMENT", 2000);
    }

    /** Sneak + left click: abort whatever the blades are doing and swing them home. */
    public void recall(Player p) {
        PlayerSession s = plugin.blades().session(p);
        if (s == null || !s.isHolding() || !s.anyOut()) return;
        s.interrupt();
        plugin.fx().sound(p.getWorld(), p.getLocation().toVector(), "recall", "minecraft:item.trident.return", 1.0f, 1.2f);
        plugin.hud().flash(p, "&7Blades recalled.", 900);
    }

    private void deny(Player p, String msg) {
        plugin.hud().flash(p, msg, 1000);
        plugin.fx().tell(p, "denied", "minecraft:block.note_block.bass", 0.7f, 0.8f);
    }

    public void forget(UUID id) { lastUse.remove(id); }
}

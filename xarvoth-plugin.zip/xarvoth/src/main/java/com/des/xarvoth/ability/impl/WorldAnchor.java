package com.des.xarvoth.ability.impl;

import com.des.xarvoth.RavageMeter;
import com.des.xarvoth.Targeting;
import com.des.xarvoth.XarvothPlugin;
import com.des.xarvoth.ability.AbilityCategory;
import com.des.xarvoth.ability.AbilityContext;
import com.des.xarvoth.blade.BladeId;
import com.des.xarvoth.blade.BladeUnit;
import com.des.xarvoth.blade.Motions;
import com.des.xarvoth.blade.PlayerSession;
import com.des.xarvoth.blade.Script;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.Locale;

/**
 * CHAIN 2 - WORLD ANCHOR. ZYRATH is thrown as a hook; what it bites decides the effect:
 *  - a surface: the chain goes taut and drags the WIELDER to it (grapple). Sneak releases early. Fall damage is cancelled at the end.
 *  - an enemy: the chain is pinned to the ground under it and tethers it there (leash radius, hard tick cap from RestraintService).
 */
public final class WorldAnchor extends BaseAbility {
    public WorldAnchor(XarvothPlugin plugin) { super(plugin, "world_anchor", "WORLD ANCHOR", AbilityCategory.CHAIN); }

    @Override
    protected String start(AbilityContext ctx) {
        Player p = ctx.owner();
        PlayerSession s = ctx.session();
        BladeUnit z = s.unit(BladeId.ZYRATH);
        if (z.isBusy()) return "ZYRATH is already out.";
        double range = Math.min(ctx.cfgD("range", 20.0), plugin.cfg().d("chain.max-length", 24.0) - 2.0);
        Targeting.Aim a = Targeting.aim(p, range);
        if (a == null) return "Nothing to anchor to.";
        return a.entity() != null ? tether(ctx, z, a.entity()) : grapple(ctx, z, a.point().clone());
    }

    private String grapple(AbilityContext ctx, BladeUnit z, Vector pt) {
        Player p = ctx.owner();
        if (p.getEyeLocation().toVector().distance(pt) < 4.0) return "Too close to anchor.";
        int maxTicks = ctx.cfgI("grapple-max-ticks", 30);
        double speed = ctx.cfgD("grapple-speed", 1.5);
        boolean[] end = {false};
        int[] age = {0};

        Script sc = new Script();
        sc.step(() -> {
            z.queue(new Motions.Homing(() -> pt, 3.0, 0.8, 16).stopOnBlock());
            plugin.fx().sound(p.getWorld(), p.getLocation().toVector(), "anchor_throw", "xarvoth:anchor.throw", 1.2f, 1.0f);
        }, () -> !z.isBusy());
        sc.step(() -> {
            if (z.pos.distance(pt) > 2.5) { sc.stop(); return; }
            z.queue(new Motions.Follow(() -> pt, t -> end[0]));
            plugin.fx().sound(p.getWorld(), pt, "anchor_bite", "xarvoth:anchor.bite", 1.2f, 0.9f);
            plugin.fx().spark(p.getWorld(), pt, 20, 0.3);
        }, () -> {
            age[0]++;
            Vector to = pt.clone().subtract(p.getLocation().toVector().add(new Vector(0, 1.0, 0)));
            double d = to.length();
            if (d < 2.5 || age[0] > maxTicks || (p.isSneaking() && age[0] > 4) || !p.isValid()) { end[0] = true; return true; }
            p.setVelocity(to.multiply(Math.min(speed, 0.5 + d * 0.06) / d));
            p.setFallDistance(0);
            return false;
        });
        sc.run(() -> {
            p.setFallDistance(0);
            p.setVelocity(p.getVelocity().multiply(0.6).add(new Vector(0, 0.35, 0)));
        });
        sc.onEnd(() -> { end[0] = true; z.clearMotions(); });
        return Kit.begin(ctx, sc);
    }

    private String tether(AbilityContext ctx, BladeUnit z, LivingEntity t) {
        Player p = ctx.owner();
        if (!plugin.damage().canTarget(p, t)) return "That target cannot be bound.";
        if (!plugin.restraints().canRestrain(t)) return "The chains cannot hold that.";
        long immune = plugin.restraints().immuneRemainingMs(t);
        if (immune > 0) return "Target is resisting the chains (" + String.format(Locale.ROOT, "%.1fs", immune / 1000.0) + ").";

        World w = p.getWorld();
        double radius = ctx.cfgD("tether-radius", 2.2);
        boolean[] arrived = {false};
        int[] granted = {0};
        int[] age = {0};
        Vector[] anchor = {null};

        Script sc = new Script();
        sc.step(() -> {
            z.queue(new Motions.Homing(() -> Kit.alive(t) ? Kit.center(t) : null, 2.8, 0.9, 14).stopOnBlock().onArrive(() -> arrived[0] = true));
            plugin.fx().sound(w, p.getLocation().toVector(), "anchor_throw", "xarvoth:anchor.throw", 1.2f, 1.0f);
        }, () -> !z.isBusy());
        sc.step(() -> {
            double dmg = ctx.baseDamage(3.0) * BladeId.ZYRATH.damageMul;
            if (!arrived[0] || !ctx.hit(BladeId.ZYRATH, t, dmg, RavageMeter.Source.CHAIN_HIT, null)) { sc.stop(); return; }
            granted[0] = plugin.restraints().grant(t, ctx.cfgI("tether-ticks", 60), false);
            if (granted[0] <= 0) { sc.stop(); return; }
            anchor[0] = Kit.ground(w, t.getLocation().toVector());
            ctx.gain(RavageMeter.Source.CAPTURE, t);
            sc.own(ctx.session().strand(() -> anchor[0], () -> Kit.alive(t) ? Kit.center(t) : anchor[0], 1.05, granted[0] + 10, 6));
            z.queue(new Motions.Follow(() -> Kit.alive(t) ? Kit.center(t) : null, n -> n >= granted[0]));
            plugin.fx().sound(w, anchor[0], "anchor_bite", "xarvoth:anchor.bite", 1.3f, 0.8f);
            plugin.fx().shockwave(w, anchor[0], 1.8, plugin.fx().energy(p));
        }, () -> {
            age[0]++;
            if (!Kit.alive(t)) return true;
            if (Kit.confine(t, anchor[0], radius)) plugin.fx().dust(w, Kit.center(t), 2, 0.2, 1.2f, plugin.fx().energy(p));
            return age[0] >= granted[0];
        });
        sc.onEnd(z::clearMotions);
        return Kit.begin(ctx, sc);
    }
}

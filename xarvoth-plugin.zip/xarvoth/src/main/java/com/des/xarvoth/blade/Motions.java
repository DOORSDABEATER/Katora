package com.des.xarvoth.blade;

import org.bukkit.Bukkit;
import org.bukkit.util.Vector;

import java.util.function.Supplier;

public final class Motions {
    private Motions() {}

    /** Per-tick callback used for hit detection and trails. */
    public interface Hook { void step(BladeUnit u, int t); }

    public enum Easing {
        LINEAR, IN, OUT, IN_OUT;

        double apply(double k) {
            k = Math.max(0, Math.min(1, k));
            return switch (this) {
                case LINEAR -> k;
                case IN -> k * k;
                case OUT -> 1 - (1 - k) * (1 - k);
                case IN_OUT -> k * k * (3 - 2 * k);
            };
        }
    }

    /** Swing the blade back to its hip anchor on a smooth arc. */
    public static Motion recall(BladeUnit u) {
        double dist = u.pos.distance(u.session().holster(u.id, Bukkit.getCurrentTick()));
        int ticks = (int) Math.max(4, Math.min(22, dist / 1.6));
        return new Arc(() -> u.session().holster(u.id, Bukkit.getCurrentTick()), new Vector(0, 0, 0), ticks, Easing.IN_OUT);
    }

    /** Quadratic bezier from where the blade is now to a (possibly moving) end point. */
    public static final class Arc extends Motion {
        private final Supplier<Vector> end;
        private final Vector bulge;
        private final int ticks;
        private final Easing easing;
        private Hook hook;
        private boolean stopOnBlock;
        private Runnable finish;
        private Vector start;
        private int t;

        public Arc(Supplier<Vector> end, Vector bulge, int ticks, Easing easing) {
            this.end = end;
            this.bulge = bulge;
            this.ticks = Math.max(1, ticks);
            this.easing = easing;
        }

        public Arc hook(Hook h) { this.hook = h; return this; }
        public Arc stopOnBlock() { this.stopOnBlock = true; return this; }
        public Arc then(Runnable r) { this.finish = r; return this; }

        @Override public void onStart() { start = u.pos.clone(); }

        @Override public boolean step() {
            t++;
            double k = easing.apply(t / (double) ticks);
            Vector e = end.get();
            Vector mid = start.clone().add(e).multiply(0.5).add(bulge);
            double ik = 1 - k;
            Vector p = start.clone().multiply(ik * ik).add(mid.multiply(2 * ik * k)).add(e.clone().multiply(k * k));
            if (stopOnBlock) {
                Vector hit = u.blockHit(p);
                if (hit != null) {
                    u.pos.copy(hit);
                    u.impactSpark();
                    if (hook != null) hook.step(u, t);
                    return true;
                }
            }
            u.pos.copy(p);
            if (hook != null) hook.step(u, t);
            return t >= ticks;
        }

        @Override public void onFinish() { if (finish != null) finish.run(); }
    }

    /** Hover in place (charging / telegraph). */
    public static final class Hold extends Motion {
        private final int ticks;
        private Hook hook;
        private int t;

        public Hold(int ticks) { this.ticks = Math.max(1, ticks); }

        public Hold hook(Hook h) { this.hook = h; return this; }

        @Override public boolean step() {
            t++;
            u.pos.setY(u.pos.getY() + Math.sin(t * 0.9) * 0.04);
            if (hook != null) hook.step(u, t);
            return t >= ticks;
        }
    }

    /** Fly straight at a (possibly moving) point at a fixed speed. */
    public static final class Homing extends Motion {
        private final Supplier<Vector> target;
        private final double speed;
        private final double arrive;
        private final int maxTicks;
        private boolean stopOnBlock;
        private Runnable onArrive;
        private Runnable onFail;
        private Hook hook;
        private boolean arrived;
        private int t;

        public Homing(Supplier<Vector> target, double speed, double arrive, int maxTicks) {
            this.target = target;
            this.speed = speed;
            this.arrive = arrive;
            this.maxTicks = Math.max(1, maxTicks);
        }

        public Homing stopOnBlock() { this.stopOnBlock = true; return this; }
        public Homing onArrive(Runnable r) { this.onArrive = r; return this; }
        public Homing onFail(Runnable r) { this.onFail = r; return this; }
        public Homing hook(Hook h) { this.hook = h; return this; }

        @Override public boolean step() {
            t++;
            Vector tgt = target.get();
            if (tgt == null) return true;
            Vector d = tgt.clone().subtract(u.pos);
            double dist = d.length();
            if (dist <= arrive) { arrived = true; return true; }
            Vector np = u.pos.clone().add(d.multiply(Math.min(speed, dist - arrive * 0.5) / dist));
            if (stopOnBlock) {
                Vector hit = u.blockHit(np);
                if (hit != null) {
                    u.pos.copy(hit);
                    u.impactSpark();
                    return true;
                }
            }
            u.pos.copy(np);
            if (hook != null) hook.step(u, t);
            return t >= maxTicks;
        }

        @Override public void onFinish() {
            if (arrived) { if (onArrive != null) onArrive.run(); }
            else if (onFail != null) onFail.run();
        }
    }

    /** Stick the blade to a (possibly moving) point until the condition says stop. */
    public static final class Follow extends Motion {
        private final Supplier<Vector> point;
        private final java.util.function.IntPredicate done;
        private int t;

        public Follow(Supplier<Vector> point, java.util.function.IntPredicate done) {
            this.point = point;
            this.done = done;
        }

        @Override public boolean step() {
            t++;
            Vector p = point.get();
            if (p == null) return true;
            u.pos.copy(p);
            return done.test(t);
        }
    }

    /** Drive the blade along a scripted path (position as a function of tick), smoothed so it flies instead of teleporting. */
    public static final class Path extends Motion {
        private final java.util.function.IntFunction<Vector> path;
        private final int ticks;
        private final double smooth;
        private Hook hook;
        private Runnable finish;
        private int t;

        public Path(java.util.function.IntFunction<Vector> path, int ticks, double smooth) {
            this.path = path;
            this.ticks = Math.max(1, ticks);
            this.smooth = smooth;
        }

        public Path hook(Hook h) { this.hook = h; return this; }
        public Path then(Runnable r) { this.finish = r; return this; }

        @Override public boolean step() {
            t++;
            Vector target = path.apply(t);
            if (target != null) u.pos.add(target.subtract(u.pos).multiply(smooth));
            if (hook != null) hook.step(u, t);
            return t >= ticks;
        }

        @Override public void onFinish() { if (finish != null) finish.run(); }
    }
}

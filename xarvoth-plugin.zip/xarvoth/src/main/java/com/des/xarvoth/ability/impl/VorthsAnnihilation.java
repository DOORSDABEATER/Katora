package com.des.xarvoth.ability.impl;

import com.des.xarvoth.Fx;
import com.des.xarvoth.RavageMeter;
import com.des.xarvoth.Targeting;
import com.des.xarvoth.XarvothPlugin;
import com.des.xarvoth.ability.Ability;
import com.des.xarvoth.ability.AbilityCategory;
import com.des.xarvoth.ability.AbilityContext;
import com.des.xarvoth.blade.BladeId;
import com.des.xarvoth.blade.BladeUnit;
import com.des.xarvoth.blade.Motions;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * BLADE AUTHORITY 1 - VORTH'S ANNIHILATION.
 * VORTH rises over the wielder (a readable telegraph), hangs charged, then crashes down on the aimed point.
 * Wide crushing area damage with falloff, radial knockback, hard target limit.
 */
public final class VorthsAnnihilation implements Ability {
    public static final String ID = "vorths_annihilation";
    private final XarvothPlugin plugin;

    public VorthsAnnihilation(XarvothPlugin plugin) { this.plugin = plugin; }

    @Override public String id() { return ID; }
    @Override public String displayName() { return "VORTH'S ANNIHILATION"; }
    @Override public AbilityCategory category() { return AbilityCategory.BLADE; }

    @Override
    public String activate(AbilityContext ctx) {
        Player p = ctx.owner();
        BladeUnit vorth = ctx.session().unit(BladeId.VORTH);
        if (vorth.isBusy()) return "VORTH is already out.";

        double maxLen = plugin.cfg().d("chain.max-length", 24.0);
        double range = Math.min(ctx.cfgD("range", 18.0), maxLen - 4.0);
        Targeting.Aim aim = Targeting.aim(p, range);
        if (aim == null) return "No target in range.";

        final Vector impact = aim.entity() != null ? aim.entity().getLocation().toVector() : aim.point().clone();
        final Vector apex = p.getLocation().toVector().add(new Vector(0, 3.6, 0)).add(ctx.session().forward().multiply(0.8));
        final World w = p.getWorld();
        final Color col = plugin.fx().energy(p);

        plugin.fx().rune(p, w, Kit.ground(w, impact), ctx.cfgD("radius", 4.5), 26);
        plugin.fx().sound(w, p.getLocation().toVector(), "vorth_charge", "minecraft:block.beacon.power_select", 1.3f, 0.6f);

        vorth.queue(new Motions.Arc(() -> apex.clone(), new Vector(0, 0, 0), 9, Motions.Easing.OUT)
                .hook((u, t) -> plugin.fx().spark(w, u.pos, 2, 0.2)));
        vorth.queue(new Motions.Hold(6).hook((u, t) -> {
            plugin.fx().ring(w, u.pos, 0.6 + t * 0.12, 12, col);
            plugin.fx().dust(w, u.pos, 3, 0.25, 1.6f, col);
        }));
        vorth.queue(new Motions.Arc(() -> impact.clone().add(new Vector(0, 0.5, 0)), new Vector(0, 0, 0), 6, Motions.Easing.IN)
                .hook((u, t) -> plugin.fx().dust(w, u.pos, 4, 0.15, 1.8f, col))
                .then(() -> slam(ctx, impact)));
        return null;
    }

    private void slam(AbilityContext ctx, Vector c) {
        Player p = ctx.owner();
        if (!p.isOnline()) return;
        World w = p.getWorld();
        double radius = ctx.cfgD("radius", 4.5);
        int limit = ctx.cfgI("target-limit", 8);
        double base = ctx.baseDamage(14.0) * BladeId.VORTH.damageMul;

        List<LivingEntity> targets = new ArrayList<>();
        for (LivingEntity e : w.getNearbyLivingEntities(new Location(w, c.getX(), c.getY(), c.getZ()), radius)) {
            if (plugin.damage().canTarget(p, e)) targets.add(e);
        }
        targets.sort(Comparator.comparingDouble(e -> e.getLocation().toVector().distanceSquared(c)));
        if (targets.size() > limit) targets = new ArrayList<>(targets.subList(0, limit));

        for (LivingEntity e : targets) {
            double d = e.getLocation().toVector().distance(c);
            double falloff = 1.0 - 0.4 * Math.min(1.0, d / radius);
            Vector kb = e.getLocation().toVector().subtract(c).setY(0);
            kb = kb.lengthSquared() > 1e-4 ? kb.normalize().multiply(0.9) : new Vector(0, 0, 0);
            kb.setY(0.55);
            ctx.hit(BladeId.VORTH, e, base * falloff, RavageMeter.Source.BLADE_HIT, kb);
        }

        plugin.fx().shockwave(w, c, radius, plugin.fx().energy(p));
        plugin.fx().sound(w, c, "vorth_slam", "minecraft:entity.generic.explode", 1.6f, 0.6f);
    }
}

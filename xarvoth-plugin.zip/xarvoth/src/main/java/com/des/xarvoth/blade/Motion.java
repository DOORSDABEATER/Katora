package com.des.xarvoth.blade;

/**
 * One step of a blade's scripted movement. A blade runs one Motion at a time from its queue.
 * Motions move {@code u.pos}; the blade renders itself, its chain and handles tether/cleanup.
 */
public abstract class Motion {
    protected BladeUnit u;

    void bind(BladeUnit unit) { this.u = unit; }

    /** Called once, right before the first step. */
    public void onStart() {}

    /** Advance one tick. Return true when finished. */
    public abstract boolean step();

    /** Finished normally. */
    public void onFinish() {}

    /** Interrupted (recall, death, weapon swapped away...). */
    public void onCancel() {}
}

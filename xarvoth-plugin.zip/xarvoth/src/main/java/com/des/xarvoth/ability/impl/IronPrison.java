package com.des.xarvoth.ability.impl;

import com.des.xarvoth.RavageMeter;
import com.des.xarvoth.Targeting;
import com.des.xarvoth.XarvothPlugin;
import com.des.xarvoth.ability.AbilityCategory;
import com.des.xarvoth.ability.AbilityContext;
import com.des.xarvoth.blade.PlayerSession;
import com.des.xarvoth.blade.Script;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;

/**
 * CHAIN 3 - IRON PRISON. A cage of eight chain bars and a top ring rises from the ground around the aimed point. Enemies inside
 * (up to a limit, only those RestraintService grants time on) are confined to it for a capped duration; anything pressing against
 * the bars is bitten by them on a fixed beat. Nothing is rooted - they can move, they just cannot leave.
 */
public final class IronPrison extends BaseAbility {
    private static final int BARS = 8;

    public IronPrison(XarvothPlugin plugin) { super(plugin, "iron_prison", "IRON PRISON", AbilityCategory.CHAIN); }

    @Override
    protected String start(AbilityContext ctx) {
        Player p = ctx.owner();
        PlayerSession s = ctx.session();
        World w = p.getWorld();
        double range = Math.min(ctx.cfgD("range", 18.0), plugin.cfg().d("chain.max-length", 24.0) - 2.0);
        Targeting.Aim aim = Targeting.aim(p, range);
        Vector center = aim != null && aim.entity() != null ? Kit.ground(w, aim.entity().getLocation().toVector()) : Kit.aimGround(ctx, range);
        double radius = ctx.cfgD("radius", 3.2);
        int dur = Math.min(ctx.cfgI("duration-ticks", 60), plugin.cfg().i("restraint.max-ticks", 60));

        List<LivingEntity> held = new ArrayList<>();
        for (LivingEntity e : Kit.around(ctx, center, radius + 0.8, ctx.cfgI("target-limit", 6), false)) {
            if (plugin.restraints().grant(e, dur, false) > 0) held.add(e);
        }
        if (held.isEmpty()) return "Nothing to imprison.";

        double height = 3.4;
        Script sc = new Script();
        sc.run(() -> {
            Vector[] base = new Vector[BARS];
            Vector[] top = new Vector[BARS];
            for (int i = 0; i < BARS; i++) {
                double a = Math.PI * 2 * i / BARS;
                base[i] = Kit.ground(w, center.clone().add(new Vector(Math.cos(a) * radius, 0, Math.sin(a) * radius)));
                top[i] = base[i].clone().add(new Vector(0, height, 0));
            }
            for (int i = 0; i < BARS; i++) {
                final int k = i;
                sc.own(s.strand(() -> base[k], () -> top[k], 1.0, dur + 20, 4));
                sc.own(s.strand(() -> top[k], () -> top[(k + 1) % BARS], 1.05, dur + 20, 3));
            }
            double dmg = ctx.baseDamage(3.0);
            for (LivingEntity e : held) {
                ctx.hit(null, e, dmg, RavageMeter.Source.CHAIN_HIT, new Vector(0, 0.1, 0));
                ctx.gain(RavageMeter.Source.CAPTURE, e);
            }
            plugin.fx().rune(p, w, center, radius + 0.5, dur);
            plugin.fx().sound(w, center, "prison_rise", "xarvoth:prison.rise", 1.4f, 0.9f);
            plugin.fx().shockwave(w, center, radius, plugin.fx().energy(p));
        });
        sc.during(dur, i -> {
            for (LivingEntity e : held) {
                if (!Kit.alive(e)) continue;
                Kit.confine(e, center.clone().add(new Vector(0, 1.0, 0)), radius - 0.4);
                double horiz = e.getLocation().toVector().subtract(center).setY(0).length();
                if (i % 10 == 9 && horiz > radius - 0.9) {
                    ctx.hit(null, e, ctx.baseDamage(3.0) * 0.8, RavageMeter.Source.CHAIN_HIT, Kit.kb(e.getLocation().toVector(), center, 0.5, 0.15));
                    plugin.fx().spark(w, Kit.center(e), 10, 0.3);
                }
            }
        });
        sc.run(() -> plugin.fx().sound(w, center, "prison_break", "xarvoth:prison.break", 1.2f, 1.0f));
        return Kit.begin(ctx, sc);
    }
}

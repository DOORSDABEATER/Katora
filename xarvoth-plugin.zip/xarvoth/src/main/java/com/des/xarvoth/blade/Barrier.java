package com.des.xarvoth.blade;

/** Lets independent blade motions meet: the action fires exactly once, when the last party arrives. */
public final class Barrier {
    private int waiting;
    private final Runnable action;

    public Barrier(int parties, Runnable action) {
        this.waiting = parties;
        this.action = action;
    }

    public void arrive() {
        if (--waiting == 0) action.run();
    }
}

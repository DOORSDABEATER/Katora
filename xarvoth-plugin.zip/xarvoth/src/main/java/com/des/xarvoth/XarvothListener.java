package com.des.xarvoth;

import com.des.xarvoth.ability.Ability;
import com.des.xarvoth.blade.PlayerSession;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

/**
 * Controls (all inside the weapon, nothing global):
 *   Right click           use selected ability
 *   F (swap hands)        next authority
 *   Sneak + scroll        next / previous ability in the authority
 *   Sneak + F             activate RAVAGE ENCHANTMENT when the meter is full
 *   Sneak + left click    recall blades
 * Everything is only active while a GENUINE, owner-matched XARVOTH is in the main hand, so other weapons are untouched.
 */
public final class XarvothListener implements Listener {
    private final XarvothPlugin plugin;

    public XarvothListener(XarvothPlugin plugin) { this.plugin = plugin; }

    // ------------------------------------------------------------ input

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Player p = e.getPlayer();
        ItemStack it = e.getItem();
        if (it == null || !plugin.ownership().looksLikeXarvoth(it)) return;

        Action a = e.getAction();
        boolean right = a == Action.RIGHT_CLICK_AIR || a == Action.RIGHT_CLICK_BLOCK;
        boolean left = a == Action.LEFT_CLICK_AIR || a == Action.LEFT_CLICK_BLOCK;

        if (!plugin.ownership().validate(it, p)) {
            if (right) plugin.hud().flash(p, "&8The chains do not answer you.", 1500);
            return;
        }
        if (left) {
            if (!plugin.cfg().b("controls.recall-requires-sneak", true) || p.isSneaking()) plugin.abilityService().recall(p);
            return;
        }
        if (!right) return;
        if (a == Action.RIGHT_CLICK_BLOCK && e.getClickedBlock() != null
                && e.getClickedBlock().getType().isInteractable() && !p.isSneaking()) return;   // never steal chest / door clicks
        e.setCancelled(true);
        plugin.abilityService().use(p);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onSwap(PlayerSwapHandItemsEvent e) {
        Player p = e.getPlayer();
        ItemStack held = e.getOffHandItem();          // the item leaving the main hand is the one being "swapped"
        if (!plugin.ownership().validate(held, p)) return;
        e.setCancelled(true);
        if (p.isSneaking()) {
            plugin.abilityService().activateRavage(p);
        } else {
            announce(p, plugin.selection().cycleCategory(p));
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onHeld(PlayerItemHeldEvent e) {
        Player p = e.getPlayer();
        ItemStack prev = p.getInventory().getItem(e.getPreviousSlot());
        if (plugin.cfg().b("controls.sneak-scroll", true) && p.isSneaking() && plugin.ownership().validate(prev, p)) {
            e.setCancelled(true);
            int d = Math.floorMod(e.getNewSlot() - e.getPreviousSlot(), 9);
            announce(p, plugin.selection().cycleAbility(p, d <= 4 ? 1 : -1));
            return;
        }
        plugin.blades().refreshSoon(p);
    }

    private void announce(Player p, Ability a) {
        if (a == null) return;
        plugin.fx().tell(p, "select", "minecraft:ui.button.click", 0.8f, 1.4f);
        long cd = plugin.cooldowns().remainingMs(p.getUniqueId(), a.id());
        plugin.hud().flash(p, "&8[&b" + a.category().label() + "&8] &f&l" + a.displayName()
                + (cd > 0 ? " &c" + String.format(java.util.Locale.ROOT, "%.1fs", cd / 1000.0) : " &aREADY"), 1200);
    }

    /** Unbreakable Reprisal: an active effect may consume damage aimed at the wielder. */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onIncoming(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        PlayerSession s = plugin.blades().session(p);
        if (s != null && s.interceptIncoming(e)) e.setCancelled(true);
    }

    // ------------------------------------------------------------ lifecycle / cleanup

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        plugin.loadPlayer(e.getPlayer());
        plugin.blades().refreshSoon(e.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        plugin.savePlayer(p);
        plugin.blades().destroy(p);
        plugin.hud().hide(p);
        plugin.forgetPlayer(p);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        plugin.blades().destroy(e.getEntity());
        plugin.hud().hide(e.getEntity());
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent e) {
        plugin.blades().destroy(e.getPlayer());
        plugin.hud().hide(e.getPlayer());
        plugin.blades().refreshSoon(e.getPlayer());
    }

    @EventHandler
    public void onTeleport(PlayerTeleportEvent e) {
        Player p = e.getPlayer();
        PlayerSession s = plugin.blades().session(p);
        if (s == null) return;
        if (e.getTo() == null || e.getFrom().getWorld() != e.getTo().getWorld()) {
            plugin.blades().destroy(p);
        } else if (e.getFrom().distanceSquared(e.getTo()) > 400.0) {
            s.snapAll();                                  // a long jump must not drag blades across the map
        }
    }
}

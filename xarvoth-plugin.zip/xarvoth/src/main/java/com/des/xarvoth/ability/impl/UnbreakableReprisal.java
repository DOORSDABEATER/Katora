package com.des.xarvoth.ability.impl;

import com.des.xarvoth.RavageMeter;
import com.des.xarvoth.XarvothPlugin;
import com.des.xarvoth.ability.AbilityCategory;
import com.des.xarvoth.ability.AbilityContext;
import com.des.xarvoth.blade.BladeId;
import com.des.xarvoth.blade.BladeUnit;
import com.des.xarvoth.blade.Effect;
import com.des.xarvoth.blade.Motions;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.util.Vector;

/**
 * CHAIN 6 - UNBREAKABLE REPRISAL. A short guard window: four chains wrap the wielder. The first incoming hits from a living
 * attacker or a projectile's shooter (up to the intercept limit) are absorbed - the damage event is cancelled - and answered:
 * the attacker is lashed, knocked back and struck by a retaliation scaled from the config, then VORTH drops on it and ZYRATH
 * follows up if they are free. Every counter feeds the meter through the COUNTER source. The window is short and each counter
 * is on a cooldown, so it can't be held up forever.
 */
public final class UnbreakableReprisal extends BaseAbility {
    public UnbreakableReprisal(XarvothPlugin plugin) { super(plugin, "unbreakable_reprisal", "UNBREAKABLE REPRISAL", AbilityCategory.CHAIN); }

    @Override
    protected String start(AbilityContext ctx) {
        return Kit.begin(ctx, new Guard(ctx));
    }

    private final class Guard extends Effect {
        private final AbilityContext ctx;
        private final int window;
        private final int maxIntercepts;
        private int intercepts;
        private int endAt;

        Guard(AbilityContext ctx) {
            this.ctx = ctx;
            this.window = ctx.cfgI("window-ticks", 30);
            this.maxIntercepts = ctx.cfgI("max-intercepts", 2);
            this.endAt = window;
        }

        @Override public void onStart() {
            Player p = owner();
            for (int k = 0; k < 4; k++) {
                final int kk = k;
                BladeId hand = k % 2 == 0 ? BladeId.VORTH : BladeId.ZYRATH;
                session.strand(() -> session.handAnchor(hand), () -> ring(p, kk), 1.05, window + 20, 5);
            }
            plugin.fx().sound(p.getWorld(), p.getLocation().toVector(), "reprisal_guard", "xarvoth:reprisal.guard", 1.2f, 1.0f);
        }

        private Vector ring(Player p, int k) {
            double ang = age * 0.25 + k * Math.PI / 2;
            return p.getLocation().toVector().add(new Vector(Math.cos(ang) * 1.7, 0.9 + Math.sin(age * 0.2 + k) * 0.4, Math.sin(ang) * 1.7));
        }

        @Override public boolean tick(int age) {
            Player p = owner();
            plugin.fx().dust(p.getWorld(), p.getLocation().toVector().add(new Vector(0, 1.0, 0)), 1, 0.7, 1.0f, plugin.fx().energy(p));
            return age >= endAt;
        }

        @Override public boolean onIncoming(EntityDamageByEntityEvent e) {
            if (intercepts >= maxIntercepts || age >= window) return false;
            Player p = owner();
            LivingEntity attacker = resolve(e.getDamager());
            if (attacker == null || attacker.equals(p) || !plugin.damage().canTarget(p, attacker)) return false;
            intercepts++;
            if (intercepts >= maxIntercepts) endAt = Math.min(endAt, age + 8);
            Bukkit.getScheduler().runTask(plugin, () -> counter(attacker));   // never damage from inside the damage event
            return true;
        }

        private LivingEntity resolve(Entity damager) {
            if (damager instanceof Projectile pr && pr.getShooter() instanceof LivingEntity le) return le;
            return damager instanceof LivingEntity le ? le : null;
        }

        private void counter(LivingEntity attacker) {
            Player p = owner();
            if (!p.isOnline() || !p.isValid() || !Kit.alive(attacker)) return;
            World w = p.getWorld();
            Vector at = Kit.center(attacker);
            plugin.fx().sound(w, p.getLocation().toVector(), "reprisal_block", "xarvoth:reprisal.block", 1.4f, 1.0f);
            plugin.fx().spark(w, p.getLocation().toVector().add(new Vector(0, 1.0, 0)), 30, 0.6);
            session.strand(() -> session.handAnchor(BladeId.ZYRATH), () -> Kit.alive(attacker) ? Kit.center(attacker) : at, 1.0, 14, 6);

            double dmg = ctx.baseDamage(10.0);
            Vector kb = Kit.kb(p.getLocation().toVector(), at, 1.1, 0.4);
            if (ctx.hit(null, attacker, dmg, RavageMeter.Source.COUNTER, kb)) {
                plugin.restraints().slow(attacker, 30, 1);
                plugin.fx().slash(w, at, at.clone().subtract(p.getLocation().toVector()), 3.0, plugin.fx().energy(p));
            }
            BladeUnit v = session.unit(BladeId.VORTH);
            BladeUnit z = session.unit(BladeId.ZYRATH);
            if (!v.isBusy()) {
                Vector[] last = {at};
                v.queue(new Motions.Arc(() -> { if (Kit.alive(attacker)) last[0] = Kit.center(attacker).add(new Vector(0, 3.5, 0)); return last[0].clone(); }, Kit.ZERO.clone(), 6, Motions.Easing.OUT));
                v.queue(new Motions.Arc(() -> Kit.alive(attacker) ? Kit.center(attacker) : last[0].clone(), Kit.ZERO.clone(), 4, Motions.Easing.IN)
                        .then(() -> {
                            if (Kit.alive(attacker)) ctx.hit(BladeId.VORTH, attacker, dmg * 0.8 * BladeId.VORTH.damageMul, RavageMeter.Source.BLADE_HIT, new Vector(0, 0.3, 0));
                            plugin.fx().shockwave(w, Kit.ground(w, last[0]), 2.2, plugin.fx().energy(p));
                        }));
            }
            if (!z.isBusy()) {
                for (int i = 0; i < 2; i++) {
                    z.queue(new Motions.Homing(() -> Kit.alive(attacker) ? Kit.center(attacker) : null, 2.8, 1.1, 10)
                            .onArrive(() -> ctx.hit(BladeId.ZYRATH, attacker, dmg * 0.4 * BladeId.ZYRATH.damageMul, RavageMeter.Source.BLADE_HIT, null)));
                }
            }
        }
    }
}

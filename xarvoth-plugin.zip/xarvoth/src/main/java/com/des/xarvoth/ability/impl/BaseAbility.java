package com.des.xarvoth.ability.impl;

import com.des.xarvoth.XarvothPlugin;
import com.des.xarvoth.ability.Ability;
import com.des.xarvoth.ability.AbilityCategory;
import com.des.xarvoth.ability.AbilityContext;

/** Boilerplate for abilities: identity lives here, behaviour lives in start(). */
public abstract class BaseAbility implements Ability {
    protected final XarvothPlugin plugin;
    private final String id;
    private final String name;
    private final AbilityCategory category;

    protected BaseAbility(XarvothPlugin plugin, String id, String name, AbilityCategory category) {
        this.plugin = plugin;
        this.id = id;
        this.name = name;
        this.category = category;
    }

    @Override public final String id() { return id; }
    @Override public final String displayName() { return name; }
    @Override public final AbilityCategory category() { return category; }

    @Override public final String activate(AbilityContext ctx) { return start(ctx); }

    /** @return null if started, otherwise a short failure reason. Must not leave anything running on failure. */
    protected abstract String start(AbilityContext ctx);
}

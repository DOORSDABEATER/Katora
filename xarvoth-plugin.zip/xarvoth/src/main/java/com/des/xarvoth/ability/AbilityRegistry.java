package com.des.xarvoth.ability;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Only abilities that are fully implemented are registered, so the selection UI never offers something that does nothing. */
public final class AbilityRegistry {
    private final Map<String, Ability> byId = new LinkedHashMap<>();

    public void register(Ability a) { byId.put(a.id(), a); }

    public Ability get(String id) { return id == null ? null : byId.get(id); }

    public List<Ability> byCategory(AbilityCategory c) {
        List<Ability> out = new ArrayList<>();
        for (Ability a : byId.values()) if (a.category() == c) out.add(a);
        return out;
    }

    public List<AbilityCategory> activeCategories() {
        List<AbilityCategory> out = new ArrayList<>();
        for (AbilityCategory c : AbilityCategory.values()) if (!byCategory(c).isEmpty()) out.add(c);
        return out;
    }

    public int size() { return byId.size(); }
}

package com.des.xarvoth.ability.impl;

import com.des.xarvoth.RavageMeter;
import com.des.xarvoth.XarvothPlugin;
import com.des.xarvoth.ability.AbilityCategory;
import com.des.xarvoth.ability.AbilityContext;
import com.des.xarvoth.blade.Barrier;
import com.des.xarvoth.blade.BladeId;
import com.des.xarvoth.blade.BladeUnit;
import com.des.xarvoth.blade.Motions;
import com.des.xarvoth.blade.PlayerSession;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

/**
 * BLADE 6 - HOLLOW EXECUTION. One target. ZYRATH opens it with three slashes from three angles while VORTH rises over it and
 * hangs there, the ground marked. When both are ready VORTH drops the execution: damage scales with how hurt the target is,
 * and a non-player target under the execute threshold takes a large multiplier. Players are never "executed", only hit harder
 * for missing health (and the global max-hit-damage cap still applies).
 */
public final class HollowExecution extends BaseAbility {
    public HollowExecution(XarvothPlugin plugin) { super(plugin, "hollow_execution", "HOLLOW EXECUTION", AbilityCategory.BLADE); }

    @Override
    protected String start(AbilityContext ctx) {
        Player p = ctx.owner();
        PlayerSession s = ctx.session();
        String busy = Kit.requireIdle(s, BladeId.VORTH, BladeId.ZYRATH);
        if (busy != null) return busy;
        LivingEntity t = Kit.targetEntity(ctx, ctx.cfgD("range", 16.0));
        if (t == null) return "No target in range.";

        World w = p.getWorld();
        BladeUnit v = s.unit(BladeId.VORTH);
        BladeUnit z = s.unit(BladeId.ZYRATH);
        double slashDmg = ctx.baseDamage(6.0);
        Vector[] last = {Kit.center(t)};
        java.util.function.Supplier<Vector> tc = () -> {
            if (Kit.alive(t)) last[0] = Kit.center(t);
            return last[0].clone();
        };
        Barrier fin = new Barrier(2, () -> execute(ctx, t, tc.get(), last));

        for (int i = 0; i < 3; i++) {
            final int k = i;
            z.queue(new Motions.Homing(() -> Kit.alive(t) ? Kit.center(t) : null, 2.9, 1.1, 10)
                    .onArrive(() -> slash(ctx, t, slashDmg, k)));
            z.queue(new Motions.Arc(() -> tc.get().add(new Vector(Math.cos(k * 2.1) * 2.6, 0.5, Math.sin(k * 2.1) * 2.6)),
                    Kit.ZERO.clone(), 3, Motions.Easing.OUT));
        }
        z.queue(new Motions.Arc(() -> z.pos.clone().add(new Vector(0, 1, 0)), Kit.ZERO.clone(), 2, Motions.Easing.OUT).then(fin::arrive));

        v.queue(new Motions.Arc(() -> tc.get().add(new Vector(0, 5.5, 0)), Kit.ZERO.clone(), 10, Motions.Easing.OUT));
        v.queue(new Motions.Hold(8).hook((b, tk) -> {
            Vector g = Kit.ground(w, tc.get());
            plugin.fx().ring(w, g, 2.4 - tk * 0.2, 20, plugin.fx().energy(p));
            plugin.fx().dust(w, b.pos, 3, 0.2, 1.7f, plugin.fx().energy(p));
        }));
        v.queue(new Motions.Arc(() -> tc.get(), Kit.ZERO.clone(), 4, Motions.Easing.IN).then(fin::arrive));

        plugin.fx().rune(p, w, Kit.ground(w, tc.get()), 2.8, 40);
        plugin.fx().sound(w, p.getLocation().toVector(), "exec_mark", "xarvoth:exec.mark", 1.2f, 1.0f);
        return null;
    }

    private void slash(AbilityContext ctx, LivingEntity t, double dmg, int k) {
        Player p = ctx.owner();
        if (!Kit.alive(t) || !p.isOnline()) return;
        Vector c = Kit.center(t);
        ctx.hit(BladeId.ZYRATH, t, dmg * BladeId.ZYRATH.damageMul, RavageMeter.Source.BLADE_HIT, new Vector(0, 0.05, 0));
        plugin.fx().slash(p.getWorld(), c, new Vector(Math.cos(k * 2.1), 0.4 * (k - 1), Math.sin(k * 2.1)), 2.6, plugin.fx().energy(p));
        plugin.fx().sound(p.getWorld(), c, "blade_hit", "xarvoth:blade.hit", 0.9f, 1.0f + k * 0.2f);
    }

    private void execute(AbilityContext ctx, LivingEntity t, Vector at, Vector[] last) {
        Player p = ctx.owner();
        if (!p.isOnline()) return;
        World w = p.getWorld();
        Cfg cfg = new Cfg(ctx);
        if (Kit.alive(t)) {
            AttributeInstance max = t.getAttribute(Attribute.MAX_HEALTH);
            double maxHp = max != null ? max.getValue() : Math.max(1.0, t.getHealth());
            double frac = Math.max(0.0, Math.min(1.0, t.getHealth() / maxHp));
            double mult = 1.0 + (1.0 - frac) * cfg.missingBonus;
            if (!(t instanceof Player) && frac <= cfg.threshold) mult *= cfg.executeMult;
            ctx.hit(BladeId.VORTH, t, ctx.baseDamage(24.0) * mult * BladeId.VORTH.damageMul, RavageMeter.Source.BLADE_HIT, new Vector(0, 0.3, 0));
        }
        for (LivingEntity e : Kit.around(ctx, at, 3.0, 5, false)) {
            if (e.equals(t)) continue;
            ctx.hit(BladeId.VORTH, e, ctx.baseDamage(24.0) * 0.3, RavageMeter.Source.BLADE_HIT, Kit.kb(at, e.getLocation().toVector(), 0.7, 0.4));
        }
        plugin.fx().shockwave(w, Kit.ground(w, at), 3.0, plugin.fx().energy(p));
        w.strikeLightningEffect(new Location(w, at.getX(), at.getY(), at.getZ()));
        plugin.fx().beam(p, w, Kit.ground(w, at), 12.0, 1.0, 10);
        plugin.fx().sound(w, at, "exec_final", "xarvoth:exec.final", 1.8f, 0.8f);
    }

    private static final class Cfg {
        final double missingBonus;
        final double threshold;
        final double executeMult;

        Cfg(AbilityContext ctx) {
            missingBonus = ctx.cfgD("missing-health-bonus", 1.0);
            threshold = ctx.cfgD("execute-threshold", 0.25);
            executeMult = ctx.cfgD("execute-multiplier", 2.5);
        }
    }
}

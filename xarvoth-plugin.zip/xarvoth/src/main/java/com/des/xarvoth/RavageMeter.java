package com.des.xarvoth;

import org.bukkit.NamespacedKey;
import org.bukkit.GameMode;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Boss;
import org.bukkit.entity.Enemy;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * RAVAGE ENCHANTMENT. Meter only moves through landed, server-confirmed damage on eligible victims.
 * There is no passive gain. Every victim can only feed the meter a capped amount per time window,
 * and passive/harmless targets (armor stands, animals, villagers...) give nothing by default.
 */
public final class RavageMeter {
    public enum Source { BLADE_HIT, CHAIN_HIT, COMBO, CAPTURE, PULL, AERIAL, COORDINATED, COUNTER }

    private static final class State {
        double value;
        long empoweredUntil;
        boolean readyAnnounced;
        boolean endPending;
        final Map<UUID, double[]> budget = new HashMap<>(); // victim -> {gainedInWindow, windowStartMs}
    }

    private final XarvothPlugin plugin;
    private final Map<UUID, State> states = new HashMap<>();
    private final NamespacedKey kValue, kLeft;

    public RavageMeter(XarvothPlugin plugin) {
        this.plugin = plugin;
        this.kValue = new NamespacedKey(plugin, "ravage");
        this.kLeft = new NamespacedKey(plugin, "ravage_left");
    }

    private State st(UUID id) { return states.computeIfAbsent(id, k -> new State()); }

    private long durationMs() { return plugin.cfg().i("ravage.empower-duration-ticks", 600) * 50L; }

    public double value(Player p) { return st(p.getUniqueId()).value; }

    public boolean isEmpowered(Player p) {
        State s = states.get(p.getUniqueId());
        return s != null && s.empoweredUntil > System.currentTimeMillis();
    }

    public long remainingMs(Player p) {
        State s = states.get(p.getUniqueId());
        return s == null ? 0 : Math.max(0, s.empoweredUntil - System.currentTimeMillis());
    }

    /** 0..1 for the UI: meter fill while charging, remaining fraction while empowered. */
    public double displayFraction(Player p) {
        if (isEmpowered(p)) return Math.min(1.0, remainingMs(p) / (double) durationMs());
        return Math.min(1.0, st(p.getUniqueId()).value / 100.0);
    }

    public boolean isReady(Player p) { return !isEmpowered(p) && st(p.getUniqueId()).value >= 100.0; }

    private double defaultGain(Source s) {
        return switch (s) {
            case BLADE_HIT, CHAIN_HIT -> 2.0;
            case COMBO, COORDINATED -> 4.0;
            case CAPTURE -> 5.0;
            case PULL -> 3.0;
            case AERIAL -> 2.5;
            case COUNTER -> 8.0;
        };
    }

    private boolean eligible(Player owner, LivingEntity v) {
        if (v.equals(owner) || v.isInvulnerable() || v instanceof ArmorStand) return false;
        if (v instanceof Player p) return p.getGameMode() == GameMode.SURVIVAL || p.getGameMode() == GameMode.ADVENTURE;
        if (v instanceof Enemy || v instanceof Boss) return true;
        return plugin.cfg().b("ravage.allow-passive-targets", false);
    }

    /** Call only after damage actually landed. */
    public void gain(Player owner, LivingEntity victim, Source src) {
        Cfg cfg = plugin.cfg();
        if (!cfg.b("ravage.enabled", true)) return;
        if (isEmpowered(owner) && !cfg.b("ravage.gain-while-empowered", false)) return;
        if (!eligible(owner, victim)) return;

        State s = st(owner.getUniqueId());
        long now = System.currentTimeMillis();
        double amount = cfg.d("ravage.gain." + src.name().toLowerCase(Locale.ROOT), defaultGain(src));
        double cap = cfg.d("ravage.per-victim-cap", 25.0);
        long windowMs = (long) (cfg.d("ravage.per-victim-window-seconds", 30) * 1000);

        double[] b = s.budget.computeIfAbsent(victim.getUniqueId(), k -> new double[]{0, now});
        if (now - (long) b[1] > windowMs) { b[0] = 0; b[1] = now; }
        double room = cap - b[0];
        if (room <= 0) return;
        amount = Math.min(amount, room);
        b[0] += amount;

        s.value = Math.min(100.0, s.value + amount);
        if (s.value >= 100.0 && !s.readyAnnounced) {
            s.readyAnnounced = true;
            plugin.hud().flash(owner, "&b&lRAVAGE ENCHANTMENT READY &7- &fSneak + F", 2500);
            plugin.fx().tell(owner, "ravage_ready", "minecraft:block.beacon.power_select", 1.0f, 1.6f);
        }
    }

    /** @return null on success, otherwise the reason it failed. */
    public String activate(Player p) {
        State s = st(p.getUniqueId());
        if (isEmpowered(p)) return "Already empowered.";
        if (s.value < 100.0) return "Ravage not ready (" + (int) s.value + "%).";
        s.value = 0;
        s.readyAnnounced = false;
        s.endPending = true;
        s.empoweredUntil = System.currentTimeMillis() + durationMs();
        return null;
    }

    /** True exactly once after an empowerment runs out. */
    public boolean pollEnded(Player p) {
        State s = states.get(p.getUniqueId());
        if (s == null || !s.endPending || s.empoweredUntil > System.currentTimeMillis()) return false;
        s.endPending = false;
        return true;
    }

    public void set(Player p, double v) {
        State s = st(p.getUniqueId());
        s.value = Math.max(0, Math.min(100, v));
        s.readyAnnounced = s.value >= 100;
    }

    public void prune() {
        long now = System.currentTimeMillis();
        long windowMs = (long) (plugin.cfg().d("ravage.per-victim-window-seconds", 30) * 1000);
        for (State s : states.values()) {
            Iterator<double[]> it = s.budget.values().iterator();
            while (it.hasNext()) if (now - (long) it.next()[1] > windowMs) it.remove();
        }
    }

    public void load(Player p) {
        State s = st(p.getUniqueId());
        Double v = p.getPersistentDataContainer().get(kValue, PersistentDataType.DOUBLE);
        Long left = p.getPersistentDataContainer().get(kLeft, PersistentDataType.LONG);
        s.value = v == null ? 0 : Math.max(0, Math.min(100, v));
        s.readyAnnounced = s.value >= 100;
        if (left != null && left > 0) {
            s.empoweredUntil = System.currentTimeMillis() + left;
            s.endPending = true;
        } else {
            s.empoweredUntil = 0;
        }
    }

    public void save(Player p) {
        State s = states.get(p.getUniqueId());
        if (s == null) return;
        p.getPersistentDataContainer().set(kValue, PersistentDataType.DOUBLE, s.value);
        long left = Math.max(0, s.empoweredUntil - System.currentTimeMillis());
        if (left > 0) p.getPersistentDataContainer().set(kLeft, PersistentDataType.LONG, left);
        else p.getPersistentDataContainer().remove(kLeft);
    }

    public void forget(UUID id) { states.remove(id); }
}

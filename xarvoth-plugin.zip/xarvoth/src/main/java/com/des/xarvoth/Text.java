package com.des.xarvoth;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

public final class Text {
    private static final LegacyComponentSerializer L = LegacyComponentSerializer.legacyAmpersand();

    private Text() {}

    public static Component c(String s) { return L.deserialize(s); }

    public static Component item(String s) { return c(s).decoration(TextDecoration.ITALIC, false); }
}

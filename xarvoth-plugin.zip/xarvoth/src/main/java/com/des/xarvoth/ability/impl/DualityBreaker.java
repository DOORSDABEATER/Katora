package com.des.xarvoth.ability.impl;

import com.des.xarvoth.RavageMeter;
import com.des.xarvoth.XarvothPlugin;
import com.des.xarvoth.ability.AbilityCategory;
import com.des.xarvoth.ability.AbilityContext;
import com.des.xarvoth.blade.BladeId;
import com.des.xarvoth.blade.BladeUnit;
import com.des.xarvoth.blade.Hitbook;
import com.des.xarvoth.blade.Motions;
import com.des.xarvoth.blade.PlayerSession;
import com.des.xarvoth.blade.Script;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * CONVERGENCE 4 - DUALITY BREAKER. Chains drag a group of enemies into a tight line in front of the wielder while the blades take
 * their flanks. Then the two-part break: VORTH's wide, heavy slash from one flank marks everything it touches as BROKEN; moments
 * later ZYRATH's fast reverse slash from the other flank hits broken targets for a large bonus.
 */
public final class DualityBreaker extends BaseAbility {
    public DualityBreaker(XarvothPlugin plugin) { super(plugin, "duality_breaker", "DUALITY BREAKER", AbilityCategory.CONVERGENCE); }

    @Override
    protected String start(AbilityContext ctx) {
        Player p = ctx.owner();
        PlayerSession s = ctx.session();
        String busy = Kit.requireIdle(s, BladeId.VORTH, BladeId.ZYRATH);
        if (busy != null) return busy;
        World w = p.getWorld();
        double range = Math.min(ctx.cfgD("range", 12.0), plugin.cfg().d("chain.max-length", 24.0) - 6.0);
        List<LivingEntity> victims = Kit.around(ctx, p.getLocation().toVector(), range, ctx.cfgI("target-limit", 6), true);
        if (victims.isEmpty()) return "No targets in sight.";

        Vector g = Kit.ground(w, p.getLocation().toVector().add(s.forward().multiply(4.5)));
        Vector right = s.right();
        BladeUnit v = s.unit(BladeId.VORTH);
        BladeUnit z = s.unit(BladeId.ZYRATH);
        Set<UUID> broken = new HashSet<>();
        double vDmg = ctx.baseDamage(13.0);
        double zDmg = ctx.baseDamage(8.0);
        double bonus = ctx.cfgD("broken-multiplier", 1.6);

        Script sc = new Script();
        sc.run(() -> {
            int n = 0;
            for (LivingEntity e : victims) {
                if (n++ < 4) sc.own(s.strand(() -> s.handAnchor(BladeId.VORTH), () -> Kit.alive(e) ? Kit.center(e) : g, 1.0, 60, 6));
                ctx.hit(null, e, ctx.baseDamage(2.0), RavageMeter.Source.CHAIN_HIT, null);
            }
            v.queue(new Motions.Arc(() -> g.clone().add(right.clone().multiply(4.5)).add(new Vector(0, 2.2, 0)), Kit.ZERO.clone(), 10, Motions.Easing.OUT));
            z.queue(new Motions.Arc(() -> g.clone().add(right.clone().multiply(-4.5)).add(new Vector(0, 1.0, 0)), Kit.ZERO.clone(), 10, Motions.Easing.OUT));
            plugin.fx().sound(w, p.getLocation().toVector(), "duality_gather", "xarvoth:duality.gather", 1.3f, 1.0f);
        });
        sc.during(12, i -> {
            for (LivingEntity e : victims) if (Kit.alive(e)) Kit.pull(e, g, 1.1);
        });
        sc.waitIdle(v, z);
        sc.run(() -> {
            v.queue(new Motions.Arc(() -> g.clone().add(right.clone().multiply(-4.5)).add(new Vector(0, 0.4, 0)), new Vector(0, 2.5, 0), 6, Motions.Easing.IN)
                    .hook((u, t) -> {
                        plugin.fx().dust(w, u.pos, 3, 0.15, 1.8f, plugin.fx().energy(p));
                        for (LivingEntity e : u.sweep(BladeId.VORTH.hitRadius * 1.5)) {
                            if (!plugin.damage().canTarget(p, e) || !broken.add(e.getUniqueId())) continue;
                            if (ctx.hit(BladeId.VORTH, e, vDmg * BladeId.VORTH.damageMul, RavageMeter.Source.BLADE_HIT, Kit.kb(g, e.getLocation().toVector(), 0.5, 0.3))) {
                                plugin.fx().slash(w, Kit.center(e), right, 3.4, plugin.fx().energy(p));
                                plugin.fx().sound(w, Kit.center(e), "duality_break", "xarvoth:duality.break", 1.2f, 0.7f);
                            } else broken.remove(e.getUniqueId());
                        }
                    }));
        });
        sc.waitTicks(3);
        sc.run(() -> {
            Hitbook zBook = new Hitbook();
            z.queue(new Motions.Arc(() -> g.clone().add(right.clone().multiply(4.5)).add(new Vector(0, 1.6, 0)), new Vector(0, -1.5, 0), 4, Motions.Easing.IN)
                    .hook((u, t) -> {
                        plugin.fx().dust(w, u.pos, 3, 0.12, 1.2f, plugin.fx().energy(p));
                        for (LivingEntity e : u.sweep(BladeId.ZYRATH.hitRadius * 1.6)) {
                            if (!plugin.damage().canTarget(p, e) || !zBook.first(e.getUniqueId())) continue;
                            double m = broken.contains(e.getUniqueId()) ? bonus : 1.0;
                            if (ctx.hit(BladeId.ZYRATH, e, zDmg * m * BladeId.ZYRATH.damageMul, RavageMeter.Source.BLADE_HIT, Kit.kb(g, e.getLocation().toVector(), 0.9, 0.35))) {
                                plugin.fx().slash(w, Kit.center(e), right.clone().multiply(-1), 3.0, plugin.fx().energy(p));
                                plugin.fx().sound(w, Kit.center(e), "blade_hit", "xarvoth:blade.hit", 1.0f, m > 1 ? 0.7f : 1.4f);
                            }
                        }
                    }));
        });
        sc.waitIdle(v, z);
        sc.run(() -> {
            plugin.fx().shockwave(w, g, 3.0, plugin.fx().energy(p));
            plugin.fx().sound(w, g, "duality_final", "xarvoth:duality.final", 1.4f, 1.0f);
        });
        sc.onEnd(() -> { v.clearMotions(); z.clearMotions(); });
        return Kit.begin(ctx, sc);
    }
}

package com.des.xarvoth.ability.impl;

import com.des.xarvoth.RavageMeter;
import com.des.xarvoth.XarvothPlugin;
import com.des.xarvoth.ability.AbilityCategory;
import com.des.xarvoth.ability.AbilityContext;
import com.des.xarvoth.blade.BladeId;
import com.des.xarvoth.blade.BladeUnit;
import com.des.xarvoth.blade.ChainStrand;
import com.des.xarvoth.blade.Motions;
import com.des.xarvoth.blade.PlayerSession;
import com.des.xarvoth.blade.Script;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;

/**
 * CONVERGENCE 8 - FRACTURE OF THE BOUND. Up to five enemies are tied together in a chain of chains, ordered from the one you aim
 * at outward. VORTH drops on the first. Then the fracture runs the length of the chain: each link shatters in turn, ZYRATH
 * rips to the next victim and the broken link detonates on it, each blast weaker than the last. A final blast at the centre ends it.
 */
public final class FractureOfTheBound extends BaseAbility {
    public FractureOfTheBound(XarvothPlugin plugin) { super(plugin, "fracture_of_the_bound", "FRACTURE OF THE BOUND", AbilityCategory.CONVERGENCE); }

    @Override
    protected String start(AbilityContext ctx) {
        Player p = ctx.owner();
        PlayerSession s = ctx.session();
        String busy = Kit.requireIdle(s, BladeId.VORTH, BladeId.ZYRATH);
        if (busy != null) return busy;
        LivingEntity first = Kit.targetEntity(ctx, ctx.cfgD("range", 16.0));
        if (first == null) return "No target in range.";

        List<LivingEntity> pool = Kit.around(ctx, Kit.center(first), ctx.cfgD("link-radius", 9.0), 12, false);
        pool.remove(first);
        List<LivingEntity> order = new ArrayList<>();
        order.add(first);
        int max = ctx.cfgI("target-limit", 5);
        while (order.size() < max && !pool.isEmpty()) {                       // greedy nearest-neighbour ordering
            Vector from = Kit.center(order.get(order.size() - 1));
            LivingEntity best = null;
            double bd = Double.MAX_VALUE;
            for (LivingEntity e : pool) {
                double d = Kit.center(e).distanceSquared(from);
                if (d < bd) { bd = d; best = e; }
            }
            order.add(best);
            pool.remove(best);
        }
        if (order.size() < 2) return "A fracture needs at least two targets.";

        World w = p.getWorld();
        BladeUnit v = s.unit(BladeId.VORTH);
        BladeUnit z = s.unit(BladeId.ZYRATH);
        double base = ctx.baseDamage(10.0);
        List<ChainStrand> edges = new ArrayList<>();

        Script sc = new Script();
        sc.run(() -> {
            for (int i = 0; i < order.size() - 1; i++) {
                LivingEntity a = order.get(i), b = order.get(i + 1);
                edges.add(sc.own(s.strand(() -> Kit.alive(a) ? Kit.center(a) : null, () -> Kit.alive(b) ? Kit.center(b) : null, 1.1, 120, 5)));
            }
            for (LivingEntity e : order) ctx.gain(RavageMeter.Source.CAPTURE, e);
            Vector[] last = {Kit.center(first)};
            v.queue(new Motions.Arc(() -> { if (Kit.alive(first)) last[0] = Kit.center(first); return last[0].clone().add(new Vector(0, 6.0, 0)); }, Kit.ZERO.clone(), 9, Motions.Easing.OUT));
            v.queue(new Motions.Arc(() -> { if (Kit.alive(first)) last[0] = Kit.center(first); return last[0].clone(); }, Kit.ZERO.clone(), 4, Motions.Easing.IN)
                    .then(() -> {
                        if (Kit.alive(first)) ctx.hit(BladeId.VORTH, first, base * 1.2 * BladeId.VORTH.damageMul, RavageMeter.Source.BLADE_HIT, new Vector(0, 0.3, 0));
                        plugin.fx().shockwave(w, Kit.ground(w, last[0]), 2.6, plugin.fx().energy(p));
                        plugin.fx().sound(w, last[0], "fracture_start", "xarvoth:fracture.start", 1.5f, 0.9f);
                    }));
        });
        sc.waitIdle(v);
        for (int i = 1; i < order.size(); i++) {
            final int k = i;
            LivingEntity tk = order.get(k);
            sc.run(() -> z.queue(new Motions.Homing(() -> Kit.alive(tk) ? Kit.center(tk) : null, 3.2, 1.1, 10).onArrive(() -> fracture(ctx, edges, order, k, base))));
            sc.waitIdle(z);
            sc.waitTicks(2);
        }
        sc.run(() -> {
            Vector c = new Vector();
            int n = 0;
            for (LivingEntity e : order) if (Kit.alive(e)) { c.add(Kit.center(e)); n++; }
            if (n == 0) return;
            c.multiply(1.0 / n);
            Kit.impact(ctx, BladeId.VORTH, c, 4.0, base * 0.6, 8, 0.8, 0.5);
            plugin.fx().shockwave(w, c, 4.0, plugin.fx().energy(p));
            plugin.fx().sound(w, c, "fracture_end", "xarvoth:fracture.end", 1.6f, 0.8f);
        });
        sc.onEnd(() -> { v.clearMotions(); z.clearMotions(); });
        return Kit.begin(ctx, sc);
    }

    private void fracture(AbilityContext ctx, List<ChainStrand> edges, List<LivingEntity> order, int k, double base) {
        Player p = ctx.owner();
        if (!p.isOnline()) return;
        LivingEntity e = order.get(k);
        double decay = Math.pow(0.85, k);
        if (k - 1 < edges.size()) {
            plugin.fx().spark(p.getWorld(), Kit.center(e), 18, 0.4);
            edges.get(k - 1).close();
        }
        if (Kit.alive(e)) ctx.hit(BladeId.ZYRATH, e, base * decay * BladeId.ZYRATH.damageMul, RavageMeter.Source.BLADE_HIT, new Vector(0, 0.2, 0));
        Vector at = Kit.center(e);
        for (LivingEntity o : Kit.around(ctx, at, 2.4, 5, false)) {
            if (o.equals(e)) continue;
            ctx.hit(BladeId.ZYRATH, o, base * 0.5 * decay, RavageMeter.Source.COMBO, Kit.kb(at, o.getLocation().toVector(), 0.7, 0.4));
        }
        plugin.fx().shockwave(p.getWorld(), Kit.ground(p.getWorld(), at), 2.4, plugin.fx().energy(p));
        plugin.fx().sound(p.getWorld(), at, "fracture_link", "xarvoth:fracture.link", 1.2f, 1.0f + k * 0.1f);
    }
}

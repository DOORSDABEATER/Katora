"""Model-based VFX for the XARVOTH pack. Fade-out is done with frames: every effect has 4 stages (bright -> dark) selecting a
different column of a palette texture, and the plugin swaps the item_model as the effect ages. Geometry is axis-aligned boxes only."""
import json, math, os
from PIL import Image

FACES = ('north', 'east', 'south', 'west', 'up', 'down')

# row: 0 core, 1 main energy, 2 silver, 3 dark accent ; column = fade stage 0..3
ROWS = {
    False: [(235, 248, 255), (40, 140, 255), (190, 198, 215), (18, 30, 70)],
    True:  [(255, 255, 255), (170, 215, 255), (240, 246, 255), (70, 110, 190)],
}
FADE_TO = (4, 8, 24)

def vfx_texture(emp):
    img = Image.new('RGBA', (16, 16))
    for stage in range(4):
        for row in range(4):
            base = ROWS[emp][row]; k = stage * 0.27
            c = tuple(int(base[i] * (1 - k) + FADE_TO[i] * k) for i in range(3))
            for y in range(4):
                for x in range(4): img.putpixel((stage * 4 + x, row * 4 + y), c + (255,))
    return img

def vbox(x0, y0, z0, x1, y1, z1, row, stage):
    uv = [stage * 4, row * 4, stage * 4 + 4, row * 4 + 4]
    return {'from': [round(x0, 3), round(y0, 3), round(z0, 3)], 'to': [round(x1, 3), round(y1, 3), round(z1, 3)],
            'faces': {f: {'uv': list(uv), 'texture': '#0'} for f in FACES}}

def g_slash(f):
    e = []
    for i in range(13):
        a = math.radians(-60 + i * 10)
        cx = 8 + 9.5 * math.sin(a); cz = 8 + 9.5 * math.cos(a) - 7.5
        w = 0.7 + 3.0 * math.cos(a * 1.5) ** 2
        e.append(vbox(cx - 1.2, 7.7, cz - w / 2, cx + 1.2, 8.3, cz + w / 2, 1, f))
        e.append(vbox(cx - 0.75, 8.3, cz - w / 4, cx + 0.75, 8.6, cz + w / 4, 0, f))
    return e

def g_shock(f):
    e = []
    for i in range(24):
        a = math.radians(i * 15); cx = 8 + 7.4 * math.cos(a); cz = 8 + 7.4 * math.sin(a)
        e.append(vbox(cx - 1.1, 0.0, cz - 1.1, cx + 1.1, 0.5, cz + 1.1, 1, f))
    for i in range(24):
        a = math.radians(i * 15 + 7.5); cx = 8 + 6.1 * math.cos(a); cz = 8 + 6.1 * math.sin(a)
        e.append(vbox(cx - 0.5, 0.5, cz - 0.5, cx + 0.5, 0.9, cz + 0.5, 0, f))
    return e

def g_beam(f):
    return [vbox(6, 0, 6, 10, 16, 10, 0, f), vbox(4.5, 0, 4.5, 11.5, 16, 11.5, 1, f),
            vbox(2, 0, 7.4, 14, 16, 8.6, 1, f), vbox(7.4, 0, 2, 8.6, 16, 14, 1, f),
            vbox(3.5, 0, 3.5, 12.5, 1.2, 12.5, 2, f), vbox(5.5, 14.8, 5.5, 10.5, 16, 10.5, 2, f)]

def g_burst(f):
    e = [vbox(7, 7, 7, 9, 9, 9, 0, f), vbox(0, 7.5, 7.5, 16, 8.5, 8.5, 1, f), vbox(7.5, 0, 7.5, 8.5, 16, 8.5, 1, f), vbox(7.5, 7.5, 0, 8.5, 8.5, 16, 1, f)]
    for s in (1, -1):
        for i in range(1, 6):
            d = i * 1.4
            e.append(vbox(8 + s * d - 0.5, 8 + d - 0.5, 7.7, 8 + s * d + 0.5, 8 + d + 0.5, 8.3, 0 if i < 3 else 1, f))
            e.append(vbox(8 + s * d - 0.5, 8 - d - 0.5, 7.7, 8 + s * d + 0.5, 8 - d + 0.5, 8.3, 0 if i < 3 else 1, f))
    return e

def g_rune(f):
    e = []
    for i in range(24):
        a = math.radians(i * 15); cx = 8 + 7.4 * math.cos(a); cz = 8 + 7.4 * math.sin(a)
        e.append(vbox(cx - 0.9, 0, cz - 0.9, cx + 0.9, 0.4, cz + 0.9, 1, f))
    for i in range(18):
        a = math.radians(i * 20); cx = 8 + 5.0 * math.cos(a); cz = 8 + 5.0 * math.sin(a)
        e.append(vbox(cx - 0.6, 0.1, cz - 0.6, cx + 0.6, 0.5, cz + 0.6, 2, f))
    for i in range(12):
        a = math.radians(i * 30 + 15); cx = 8 + 7.9 * math.cos(a); cz = 8 + 7.9 * math.sin(a)
        e.append(vbox(cx - 0.4, 0.2, cz - 0.4, cx + 0.4, 0.8, cz + 0.4, 0, f))
    e += [vbox(1.5, 0.1, 7.6, 14.5, 0.5, 8.4, 1, f), vbox(7.6, 0.1, 1.5, 8.4, 0.5, 14.5, 1, f), vbox(6.6, 0.1, 6.6, 9.4, 0.7, 9.4, 0, f)]
    for k in (1, 2, 3):
        e.append(vbox(8 + k * 1.3 - 0.4, 0.1, 8 + k * 1.3 - 0.4, 8 + k * 1.3 + 0.4, 0.5, 8 + k * 1.3 + 0.4, 2, f))
        e.append(vbox(8 - k * 1.3 - 0.4, 0.1, 8 + k * 1.3 - 0.4, 8 - k * 1.3 + 0.4, 0.5, 8 + k * 1.3 + 0.4, 2, f))
        e.append(vbox(8 + k * 1.3 - 0.4, 0.1, 8 - k * 1.3 - 0.4, 8 + k * 1.3 + 0.4, 0.5, 8 - k * 1.3 + 0.4, 2, f))
        e.append(vbox(8 - k * 1.3 - 0.4, 0.1, 8 - k * 1.3 - 0.4, 8 - k * 1.3 + 0.4, 0.5, 8 - k * 1.3 + 0.4, 2, f))
    return e

def g_crack(f):
    e = []
    import random
    r = random.Random(41)
    for d in range(9):
        a = math.radians(d * 40 + r.uniform(-10, 10)); x, z = 8.0, 8.0
        for step in range(8):
            a += math.radians(r.uniform(-28, 28)); x += math.cos(a) * 0.95; z += math.sin(a) * 0.95
            if not (0.8 < x < 15.2 and 0.8 < z < 15.2): break
            w = 0.7 - step * 0.05
            e.append(vbox(x - w, 0, z - w, x + w, 0.25, z + w, 3, f))
            if step % 2 == 0: e.append(vbox(x - w * 0.5, 0.25, z - w * 0.5, x + w * 0.5, 0.4, z + w * 0.5, 1, f))
    e.append(vbox(6.8, 0, 6.8, 9.2, 0.3, 9.2, 3, f)); e.append(vbox(7.4, 0.3, 7.4, 8.6, 0.5, 8.6, 1, f))
    return e

def g_aura(v):
    e = []
    for k in range(8):
        a = math.radians(k * 45 + (22.5 if v else 0)); cx = 8 + 5.4 * math.cos(a); cz = 8 + 5.4 * math.sin(a)
        h = 10.5 + 4 * ((k + v) % 2)
        for j, (y0, y1, wd) in enumerate([(2, 5, 1.6), (5, 9, 1.2), (9, h, 0.8)]):
            e.append(vbox(cx - wd / 2, y0, cz - wd / 2, cx + wd / 2, y1, cz + wd / 2, 0 if j == 2 else 1, 0))
    return e

def ghost_from(elements, stage):
    out = []
    for el in elements:
        uv = [stage * 4, 4, stage * 4 + 4, 8]
        out.append({'from': el['from'], 'to': el['to'], 'faces': {f: {'uv': list(uv), 'texture': '#0'} for f in FACES}})
    return out

def model_json(elements, tex):
    return {'textures': {'0': tex, 'particle': tex}, 'elements': elements}

def build(ns, write_json, vorth_elements, zyrath_elements):
    tex = os.path.join(ns, 'textures', 'item'); os.makedirs(tex, exist_ok=True)
    vfx_texture(False).save(os.path.join(tex, 'vfx.png')); vfx_texture(True).save(os.path.join(tex, 'vfx_empowered.png'))
    defs = []
    for name, gen in (('slash', g_slash), ('shock', g_shock), ('beam', g_beam), ('burst', g_burst), ('rune', g_rune), ('crack', g_crack)):
        for f in range(4): defs.append(('vfx_%s_%d' % (name, f), gen(f)))
    for bname, els in (('vorth', vorth_elements), ('zyrath', zyrath_elements)):
        for f in range(3): defs.append(('vfx_ghost_%s_%d' % (bname, f), ghost_from(els, f + 1)))
    for v in range(2): defs.append(('vfx_aura_%d' % v, g_aura(v)))
    for emp in (False, True):
        suffix = '_empowered' if emp else ''; t = 'xarvoth:item/vfx' + suffix
        for name, els in defs:
            write_json(os.path.join(ns, 'models', 'item', name + suffix + '.json'), model_json(els, t))
            write_json(os.path.join(ns, 'items', name + suffix + '.json'), {'model': {'type': 'minecraft:model', 'model': 'xarvoth:item/' + name + suffix}})
    return len(defs) * 2

#!/usr/bin/env python3
"""Builds the XARVOTH resource pack from scratch: textures, models, item definitions, synthesized sounds, HUD font.
Everything is generated here, so every asset is original and nothing is a placeholder. Needs: numpy, scipy, pillow, ffmpeg (libvorbis).
Run:  python3 tools/build_pack.py     ->  resourcepack/   (+ prints a config 'sounds:' block into build/config_sounds.yml)
"""
import json, os, subprocess, sys, wave, shutil
import numpy as np
from scipy import signal
from scipy.io import wavfile
from PIL import Image, ImageDraw

sys.path.insert(0, os.path.dirname(__file__))
from sounds_table import T
import vfx_pack

ROOT = os.path.join(os.path.dirname(__file__), '..')
PACK = os.path.join(ROOT, 'resourcepack')
NS = os.path.join(PACK, 'assets', 'xarvoth')
BUILD = os.path.join(ROOT, 'build')
SR = 44100

def mk(*p):
    path = os.path.join(*p)
    os.makedirs(os.path.dirname(path) if os.path.splitext(path)[1] else path, exist_ok=True)
    return path

# ====================================================================== AUDIO
def N(d): return int(SR * d)
def tt(d): return np.arange(N(d)) / SR
def noise(d, r): return r.standard_normal(N(d))
def expd(d, k): return np.exp(-tt(d) * k)
def butter(x, kind, f, order=2):
    f = min(max(f, 20.0), SR / 2 - 100)
    b, a = signal.butter(order, f / (SR / 2), kind)
    return signal.lfilter(b, a, x)
def band(x, lo, hi):
    lo = min(max(lo, 20.0), SR / 2 - 200); hi = min(max(hi, lo + 50), SR / 2 - 100)
    b, a = signal.butter(2, [lo / (SR / 2), hi / (SR / 2)], 'band')
    return signal.lfilter(b, a, x)
def sweep(f0, f1, d):
    f = np.geomspace(f0, f1, N(d))
    return np.sin(2 * np.pi * np.cumsum(f) / SR)
def partials(freqs, decays, amps, d):
    t = tt(d); out = np.zeros_like(t)
    for f, k, a in zip(freqs, decays, amps): out += a * np.sin(2 * np.pi * f * t) * np.exp(-t * k)
    return out
def pad(x, n):
    return np.pad(x, (0, max(0, n - len(x))))[:n] if len(x) != n else x
def mix(d, *layers):
    out = np.zeros(N(d))
    for off, x, g in layers:
        s = int(off * SR)
        if s >= len(out): continue
        seg = x[:len(out) - s]
        out[s:s + len(seg)] += g * seg
    return out
def fade(x, a=0.004, r=0.03):
    x = x.copy(); na = max(1, int(a * SR)); nr = max(1, int(r * SR))
    x[:na] *= np.linspace(0, 1, na); x[-nr:] *= np.linspace(1, 0, nr); return x
def norm(x, peak=0.89):
    m = np.max(np.abs(x)) or 1.0
    return x / m * peak

def r_click(d, p, r):
    return expd(d, 90) * (np.sin(2 * np.pi * 1900 * p * tt(d)) + 0.4 * noise(d, r))
def r_hit(d, p, r):
    t = tt(d)
    return (partials([1300 * p, 2100 * p, 3300 * p, 4700 * p], [20, 24, 32, 44], [1, .7, .5, .4], d)
            + 1.3 * butter(noise(d, r), 'high', 1800) * expd(d, 70) + 1.2 * np.sin(2 * np.pi * 140 * p * t) * expd(d, 30))
def r_clang(d, p, r):
    return (partials([520 * p, 870 * p, 1390 * p, 2210 * p, 3470 * p], [3.4, 4.4, 6, 8, 11], [1, .8, .6, .4, .3], d)
            + 0.8 * butter(noise(d, r), 'high', 2500) * expd(d, 50))
def clink(d, p, r):
    return partials([3200 * p, 4600 * p, 6100 * p], [38, 52, 70], [1, .7, .5], d) + 0.5 * butter(noise(d, r), 'high', 5000) * expd(d, 120)
def r_chain(d, p, r, rate=(7, 7), n=None):
    out = np.zeros(N(d)); n = n or int(d * (rate[0] + rate[1]) / 2 * 1.0) + 3
    ts = np.sort(r.uniform(0, d * 0.85, n))
    for tm in ts:
        c = clink(0.14, p * r.uniform(0.85, 1.25), r); s = int(tm * SR); out[s:s + len(c)] += (0.4 + 0.6 * r.random()) * c[:len(out) - s]
    return out
def r_chainpull(d, p, r):
    out = np.zeros(N(d)); tm = 0.0; gap = 0.14
    while tm < d * 0.9:
        c = clink(0.14, p * (0.8 + tm / d * 0.9) * r.uniform(0.9, 1.1), r); s = int(tm * SR); out[s:s + len(c)] += c[:len(out) - s] * (0.4 + tm / d * 0.8)
        tm += gap; gap = max(0.035, gap * 0.9)
    return out + 0.5 * r_whoosh(d, p * 0.8, r) * np.linspace(0, 1, N(d))
def r_whoosh(d, p, r):
    n = N(d); out = np.zeros(n); centers = np.geomspace(300 * p, 3600 * p, 9)
    x = np.arange(n) / n
    for i, c in enumerate(centers):
        b = band(noise(d, r), c * 0.7, c * 1.4); g = np.exp(-((x - (0.15 + 0.7 * i / 8)) ** 2) / 0.012); out += b * g
    return out * np.sin(np.pi * np.clip(x, 0, 1)) ** 0.5
def r_whoosh_r(d, p, r): return r_whoosh(d, p, r)[::-1]
def r_charge(d, p, r):
    t = tt(d); trem = 0.65 + 0.35 * np.sin(2 * np.pi * (6 + 14 * t / d) * t)
    return (sweep(120 * p, 760 * p, d) * trem + 0.4 * sweep(240 * p, 1500 * p, d) + 0.3 * butter(noise(d, r), 'low', 900) * (t / d)) * np.linspace(0.15, 1, N(d)) ** 1.3
def r_boom(d, p, r):
    return (1.4 * sweep(95 * p, 28, d) * expd(d, 2.0) + 1.0 * butter(noise(d, r), 'low', 320 * p) * expd(d, 2.4)
            + 0.5 * partials([60 * p, 90 * p], [1.4, 2], [1, .6], d))
def r_slam(d, p, r):
    return mix(d, (0, r_boom(d, p, r), 1.0), (0, r_clang(min(d, 1.0), p * 0.8, r), 0.5), (0.0, butter(noise(d, r), 'high', 1500) * expd(d, 40), 0.7))
def r_megaboom(d, p, r):
    crack = np.zeros(N(d))
    for tm in r.uniform(0.0, d * 0.5, 14):
        s = int(tm * SR); burst = butter(noise(0.12, r), 'high', 2500) * expd(0.12, 40); crack[s:s + len(burst)] += burst[:len(crack) - s]
    return mix(d, (0, r_boom(d, p * 0.9, r), 1.0), (0, r_slam(min(d, 1.8), p, r), 0.7), (0.05, crack, 0.6),
               (0.0, 0.8 * sweep(55, 22, d) * expd(d, 1.2), 1.0))
def r_rise(d, p, r):
    t = tt(d); sh = sum(np.sin(2 * np.pi * np.cumsum(np.geomspace(90 * p, 900 * p, N(d))) * k / SR) * (0.6 / k) for k in (1, 2, 3))
    return (sh + 0.5 * butter(noise(d, r), 'band' if False else 'high', 800) * (t / d) ** 2) * np.linspace(0.1, 1, N(d)) ** 1.5
def r_fall(d, p, r):
    t = tt(d)
    return (sweep(700 * p, 70, d) * expd(d, 1.6) + 0.4 * butter(noise(d, r), 'low', 700) * expd(d, 2.5))
def r_drone(d, p, r):
    t = tt(d); out = np.zeros_like(t)
    for det in (-0.012, 0, 0.011, 0.5):
        f = 55 * p * (1 + det); out += signal.sawtooth(2 * np.pi * np.cumsum(np.full_like(t, f)) / SR) * 0.4
    out = butter(out, 'low', 600 + 800 * 0.3) * (0.7 + 0.3 * np.sin(2 * np.pi * 0.7 * t))
    return out * np.sin(np.pi * np.clip(t / d, 0, 1)) ** 0.6 + 0.3 * r_rise(d, p * 0.6, r) * 0.3
def r_chime(d, p, r):
    return partials([880 * p, 1320 * p, 1760 * p, 2640 * p], [2.4, 2.8, 3.4, 4.2], [1, .6, .4, .25], d)
def r_shimmer(d, p, r):
    t = tt(d); x = partials([1760 * p, 2349 * p, 3136 * p, 4186 * p], [1.6, 2, 2.4, 3], [1, .7, .5, .4], d) * (0.6 + 0.4 * np.sin(2 * np.pi * 9 * t))
    return x * np.sin(np.pi * np.clip(t / d, 0, 1))
def r_zap(d, p, r):
    n = N(d); gate = (r.random(n // 200 + 2) > 0.45).astype(float).repeat(200)[:n]
    e = band(noise(d, r), 1500 * p, 7000 * p) * gate * expd(d, 4)
    return e * 1.6 + sweep(3200 * p, 400 * p, d) * expd(d, 14) * 0.6
def r_clangzap(d, p, r): return r_clang(d, p, r) + 0.7 * r_zap(d, p, r)
def r_shatter(d, p, r):
    out = 1.0 * butter(noise(d, r), 'high', 1500) * expd(d, 5)
    for tm in r.uniform(0, d * 0.5, 22):
        c = clink(0.2, p * r.uniform(0.6, 1.8), r); s = int(tm * SR); out[s:s + len(c)] += 0.6 * c[:len(out) - s]
    return out
def r_bind(d, p, r): return mix(d, (0, r_chain(min(d, 0.7), p, r, n=7), 0.9), (0.18, r_boom(d - 0.18, p * 1.1, r), 0.5), (0.15, r_clang(min(d - 0.15, 0.9), p * 0.7, r), 0.5))
def r_bindrise(d, p, r): return mix(d, (0, r_rise(d, p * 0.8, r), 0.6), (0, r_chain(d * 0.7, p, r, n=int(d * 8)), 0.8), (d * 0.6, r_boom(d * 0.4, p, r), 0.7))
def r_crosscut(d, p, r):
    return mix(d, (0, r_whoosh(0.5, p, r), 0.8), (0.12, r_whoosh(0.5, p * 1.3, r), 0.8), (0.28, r_hit(0.5, p * 0.8, r), 1.0), (0.3, r_clang(d - 0.3, p * 0.7, r), 0.6))
def r_scan(d, p, r):
    t = tt(d); steps = np.floor(t / d * 8); f = 500 * p * (1.19 ** steps)
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * (0.5 + 0.5 * np.sign(np.sin(2 * np.pi * 16 * t))) * 0.6 + 0.4 * r_zap(d, p * 0.7, r)
def r_buzz(d, p, r): return signal.square(2 * np.pi * 95 * p * tt(d)) * 0.4 * expd(d, 9) + 0.3 * butter(noise(d, r), 'low', 500) * expd(d, 12)
def r_stake(d, p, r): return mix(d, (0, r_slam(d, p, r), 1.0), (0.02, r_clang(d, p * 1.2, r), 0.6), (0, r_hit(0.3, p, r), 0.8))
def r_ignite(d, p, r):
    return mix(d, (0, r_rise(d * 0.6, p, r), 0.7), (d * 0.45, r_boom(d * 0.55, p, r), 0.9), (d * 0.5, r_chime(d * 0.5, p * 1.4, r), 0.6), (d * 0.45, r_zap(d * 0.5, p, r), 0.5))
def r_chainhit(d, p, r): return mix(d, (0, r_hit(0.4, p * 0.9, r), 0.9), (0.03, r_chain(0.45, p, r, n=5), 0.8))

REC = {'hit': r_hit, 'clang': r_clang, 'chainhit': r_chainhit, 'whoosh': r_whoosh, 'whoosh_r': r_whoosh_r, 'charge': r_charge,
       'slam': r_slam, 'boom': r_boom, 'megaboom': r_megaboom, 'chain': r_chain, 'chainpull': r_chainpull, 'bind': r_bind,
       'bindrise': r_bindrise, 'rise': r_rise, 'fall': r_fall, 'drone': r_drone, 'ignite': r_ignite, 'chime': r_chime,
       'shimmer': r_shimmer, 'zap': r_zap, 'clangzap': r_clangzap, 'shatter': r_shatter, 'crosscut': r_crosscut,
       'scan': r_scan, 'buzz': r_buzz, 'click': r_click, 'stake': r_stake}
BIG = {'megaboom', 'boom', 'drone', 'rise', 'ignite'}

def render_sounds():
    sounds = {}
    config_lines = []
    for key, (event, recipe, dur, pitch, variants) in T.items():
        files = []
        for v in range(variants):
            r = np.random.default_rng(abs(hash((event, v))) % (2 ** 32) if False else (sum(map(ord, event)) * 977 + v * 131) % (2 ** 31))
            p = pitch * float(r.uniform(0.95, 1.06))
            x = REC[recipe](dur, p, r)
            x = fade(pad(x, N(dur)), 0.004, min(0.08, dur * 0.2))
            x = norm(x)
            rel = event.replace('.', '/') + '_%d' % (v + 1)
            wav = os.path.join(BUILD, 'wav', rel + '.wav'); ogg = os.path.join(NS, 'sounds', rel + '.ogg')
            os.makedirs(os.path.dirname(wav), exist_ok=True); os.makedirs(os.path.dirname(ogg), exist_ok=True)
            wavfile.write(wav, SR, (x * 32767).astype(np.int16))
            subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', wav, '-ac', '1', '-ar', str(SR), '-c:a', 'libvorbis', '-q:a', '5', ogg], check=True)
            files.append({'name': 'xarvoth:' + rel, 'volume': 1.0, 'pitch': 1.0, **({'attenuation_distance': 64} if recipe in BIG else {})})
        sounds[event] = {'sounds': files}
        config_lines.append('  %s: "xarvoth:%s"' % (key, event))
    with open(mk(NS, 'sounds.json'), 'w') as f: json.dump(sounds, f, indent=1)
    os.makedirs(BUILD, exist_ok=True)
    with open(os.path.join(BUILD, 'config_sounds.yml'), 'w') as f: f.write('sounds:\n' + '\n'.join(config_lines) + '\n')
    return len(sounds)

# ====================================================================== TEXTURES
MAT = {'O': 0, 'S': 1, 'B': 2, 'W': 3}
BASE = {
    'O': [(8, 8, 14), (17, 17, 26), (28, 28, 42), (42, 42, 62)],
    'S': [(112, 118, 134), (160, 167, 182), (203, 209, 222), (232, 236, 245)],
    'B': [(16, 74, 176), (34, 128, 244), (84, 182, 255), (150, 216, 255)],
    'W': [(190, 224, 255), (222, 240, 255), (244, 251, 255), (255, 255, 255)],
}
EMP = {
    'O': [(12, 26, 66), (22, 44, 98), (36, 66, 130), (56, 92, 160)],
    'S': [(180, 200, 232), (214, 228, 248), (238, 246, 255), (255, 255, 255)],
    'B': [(90, 176, 255), (140, 206, 255), (190, 230, 255), (230, 246, 255)],
    'W': [(230, 244, 255), (244, 250, 255), (255, 255, 255), (255, 255, 255)],
}

def palette_texture(pal, seed):
    r = np.random.default_rng(seed); img = Image.new('RGBA', (16, 16))
    for m, key in enumerate('OSBW'):
        for s in range(4):
            c = pal[key][s]
            for y in range(4):
                for x in range(4):
                    j = int(r.integers(-6, 7)) if key in 'OS' else int(r.integers(-3, 4))
                    img.putpixel((m * 4 + x, s * 4 + y), tuple(max(0, min(255, v + j)) for v in c) + (255,))
    return img

def weapon_sprite(pal):
    im = Image.new('RGBA', (32, 32), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    O, S, B, W = pal['O'][1], pal['S'][2], pal['B'][1], pal['W'][2]
    # VORTH: thick blade, upper left diagonal
    d.line([(7, 24), (25, 6)], fill=O, width=5); d.line([(6, 25), (24, 5)], fill=S, width=1); d.line([(9, 26), (27, 8)], fill=S, width=1)
    d.line([(12, 21), (22, 11)], fill=B, width=1)
    # ZYRATH: slim blade, lower right diagonal
    d.line([(10, 28), (28, 12)], fill=O, width=3); d.line([(9, 29), (27, 13)], fill=S, width=1); d.line([(13, 26), (25, 15)], fill=B, width=1)
    # hilt + guard
    d.line([(3, 29), (8, 24)], fill=O, width=3); d.line([(5, 21), (11, 27)], fill=S, width=2); d.rectangle([2, 28, 4, 30], fill=S)
    # hanging chain
    for i, (x, y) in enumerate([(1, 25), (1, 22), (2, 19), (4, 17)]): d.rectangle([x, y, x + 1, y + 1], fill=B if i % 2 == 0 else S)
    d.point([(27, 5), (28, 11), (7, 28)], fill=W)
    return im

def icon_set(pal):
    """9x9 HUD glyphs: 4 category icons and 5 meter cell states. One row, each cell 9 wide."""
    cells = []
    C = pal['B'][2]; S = pal['S'][2]; W = pal['W'][2]
    def new(): return Image.new('RGBA', (9, 9), (0, 0, 0, 0))
    a = new(); d = ImageDraw.Draw(a); d.line([(1, 7), (7, 1)], fill=S, width=1); d.line([(2, 8), (8, 2)], fill=C); d.point([(0, 8), (1, 8)], fill=W); cells.append(a)        # blade
    a = new(); d = ImageDraw.Draw(a)
    for (x, y) in [(0, 6), (2, 4), (4, 2), (6, 0)]: d.rectangle([x, y, x + 2, y + 2], outline=S)
    cells.append(a)                                                                                                                                                    # chain
    a = new(); d = ImageDraw.Draw(a); d.line([(0, 0), (8, 8)], fill=S); d.line([(8, 0), (0, 8)], fill=C); d.rectangle([3, 3, 5, 5], fill=W); cells.append(a)                # convergence
    a = new(); d = ImageDraw.Draw(a); d.polygon([(0, 7), (1, 2), (3, 5), (4, 0), (5, 5), (7, 2), (8, 7)], fill=W, outline=C); cells.append(a)                            # ultimate crown
    for fill in range(5):                                                                                                                                              # meter cells
        a = new(); d = ImageDraw.Draw(a); d.rectangle([0, 2, 8, 6], outline=pal['S'][0])
        w = int(round(7 * fill / 4))
        if w > 0: d.rectangle([1, 3, w, 5], fill=C if fill < 4 else W)
        cells.append(a)
    sheet = Image.new('RGBA', (9 * len(cells), 9), (0, 0, 0, 0))
    for i, c in enumerate(cells): sheet.paste(c, (9 * i, 0))
    return sheet

def make_textures():
    tex = mk(NS, 'textures', 'item')
    for name, pal, seed in (('palette', BASE, 11), ('palette_empowered', EMP, 12)):
        palette_texture(pal, seed).save(os.path.join(tex, name + '.png'))
    weapon_sprite(BASE).save(os.path.join(tex, 'weapon.png')); weapon_sprite(EMP).save(os.path.join(tex, 'weapon_empowered.png'))
    font = mk(NS, 'textures', 'font'); icon_set(BASE).save(os.path.join(font, 'hud.png'))
    emblem = Image.new('RGBA', (64, 64), (8, 8, 14, 255)); d = ImageDraw.Draw(emblem)
    d.line([(12, 52), (52, 12)], fill=BASE['S'][2], width=6); d.line([(14, 54), (54, 14)], fill=BASE['B'][1], width=2)
    d.line([(12, 12), (52, 52)], fill=BASE['S'][1], width=4); d.rectangle([28, 28, 36, 36], fill=BASE['W'][2])
    emblem.save(os.path.join(PACK, 'pack.png'))

# ====================================================================== MODELS
FACES = ('north', 'east', 'south', 'west', 'up', 'down')
def box(x0, y0, z0, x1, y1, z1, mat, shade=1):
    m = MAT[mat]; uv = [m * 4, shade * 4, m * 4 + 4, shade * 4 + 4]
    return {'from': [x0, y0, z0], 'to': [x1, y1, z1], 'faces': {f: {'uv': list(uv), 'texture': '#0'} for f in FACES}}

def vorth():
    e = [box(6.4, 0, 6.4, 9.6, 1.6, 9.6, 'S', 1), box(7.2, .4, 9.5, 8.8, 1.2, 9.9, 'B', 2), box(7.2, .4, 6.1, 8.8, 1.2, 6.5, 'B', 2),
         box(7, 1.6, 7, 9, 6.2, 9, 'O', 1), box(6.7, 2.6, 6.7, 9.3, 3.2, 9.3, 'S', 1), box(6.7, 4.4, 6.7, 9.3, 5.0, 9.3, 'S', 1),
         box(3.2, 6.2, 6.2, 12.8, 7.6, 9.8, 'S', 2), box(2.0, 6.5, 6.8, 3.2, 7.3, 9.2, 'S', 0), box(12.8, 6.5, 6.8, 14.0, 7.3, 9.2, 'S', 0),
         box(7.3, 7.6, 6.9, 8.7, 8.6, 9.1, 'B', 2),
         box(5.6, 7.6, 7.2, 10.4, 9.4, 8.8, 'O', 1), box(5.2, 9.4, 7.2, 10.8, 11.6, 8.8, 'O', 1),
         box(4.8, 11.6, 7.2, 11.2, 14.0, 8.8, 'O', 2), box(5.6, 14.0, 7.4, 10.6, 15.4, 8.6, 'O', 1), box(7.2, 15.4, 7.6, 9.6, 16.0, 8.4, 'S', 2),
         box(10.4, 7.6, 7.0, 11.0, 9.4, 9.0, 'S', 2), box(10.8, 9.4, 7.0, 11.4, 11.6, 9.0, 'S', 2), box(11.2, 11.6, 7.0, 11.8, 14.0, 9.0, 'S', 2), box(10.6, 14.0, 7.2, 11.2, 15.4, 8.8, 'S', 2),
         box(5.0, 7.6, 7.0, 5.6, 9.4, 9.0, 'S', 1), box(4.6, 9.4, 7.0, 5.2, 11.6, 9.0, 'S', 1), box(4.2, 11.6, 7.0, 4.8, 14.0, 9.0, 'S', 1), box(5.0, 14.0, 7.2, 5.6, 15.4, 8.8, 'S', 1),
         box(11.0, 10.0, 7.4, 12.0, 10.7, 8.6, 'S', 3), box(11.4, 12.4, 7.4, 12.4, 13.1, 8.6, 'S', 3), box(11.8, 14.4, 7.5, 12.6, 15.0, 8.5, 'S', 3),
         box(3.6, 11.4, 7.4, 4.6, 12.1, 8.6, 'S', 3), box(4.0, 13.2, 7.4, 4.9, 13.9, 8.6, 'S', 3),
         box(7.3, 8.0, 6.9, 8.7, 15.0, 7.2, 'B', 2), box(7.3, 8.0, 8.8, 8.7, 15.0, 9.1, 'B', 2),
         box(7.7, 9.0, 6.8, 8.3, 9.6, 7.0, 'W', 2), box(7.7, 11.0, 6.8, 8.3, 11.6, 7.0, 'W', 2), box(7.7, 13.0, 6.8, 8.3, 13.6, 7.0, 'W', 2),
         box(7.7, 9.0, 9.0, 8.3, 9.6, 9.2, 'W', 2), box(7.7, 11.0, 9.0, 8.3, 11.6, 9.2, 'W', 2), box(7.7, 13.0, 9.0, 8.3, 13.6, 9.2, 'W', 2)]
    return e

def zyrath():
    e = [box(6.8, 0, 6.8, 9.2, 1.4, 9.2, 'S', 1), box(7.5, .3, 9.1, 8.5, 1.1, 9.4, 'B', 2), box(7.5, .3, 6.6, 8.5, 1.1, 6.9, 'B', 2),
         box(7.2, 1.4, 7.2, 8.8, 6.0, 8.8, 'O', 1), box(6.9, 2.8, 6.9, 9.1, 3.3, 9.1, 'S', 1), box(6.9, 4.4, 6.9, 9.1, 4.9, 9.1, 'S', 1),
         box(4.6, 6.0, 7.0, 11.4, 7.0, 9.0, 'S', 2), box(3.4, 6.6, 7.3, 4.6, 7.6, 8.7, 'S', 0), box(11.4, 6.6, 7.3, 12.6, 7.6, 8.7, 'S', 0),
         box(2.8, 7.4, 7.5, 3.6, 8.4, 8.5, 'S', 1), box(12.4, 7.4, 7.5, 13.2, 8.4, 8.5, 'S', 1),
         # curved, slender blade: each slab shifts toward +x
         box(7.0, 7.0, 7.6, 9.2, 9.0, 8.4, 'O', 1), box(7.3, 9.0, 7.6, 9.5, 11.0, 8.4, 'O', 2), box(7.7, 11.0, 7.6, 9.8, 13.0, 8.4, 'O', 1),
         box(8.3, 13.0, 7.7, 10.1, 14.6, 8.3, 'O', 2), box(9.1, 14.6, 7.8, 10.5, 15.6, 8.2, 'O', 1), box(9.8, 15.6, 7.9, 10.8, 16.0, 8.1, 'S', 3),
         box(9.2, 7.0, 7.4, 9.7, 9.0, 8.6, 'S', 2), box(9.5, 9.0, 7.4, 10.0, 11.0, 8.6, 'S', 2), box(9.8, 11.0, 7.4, 10.3, 13.0, 8.6, 'S', 3),
         box(10.1, 13.0, 7.5, 10.6, 14.6, 8.5, 'S', 3), box(10.5, 14.6, 7.6, 10.9, 15.6, 8.4, 'S', 3),
         box(6.8, 7.0, 7.5, 7.0, 9.0, 8.5, 'S', 1), box(7.1, 9.0, 7.5, 7.3, 11.0, 8.5, 'S', 1), box(7.5, 11.0, 7.5, 7.7, 13.0, 8.5, 'S', 1),
         box(7.8, 7.4, 7.4, 8.4, 14.0, 7.65, 'B', 2), box(8.1, 7.4, 8.35, 8.7, 14.0, 8.6, 'B', 2),
         box(7.9, 8.4, 7.3, 8.3, 8.9, 7.45, 'W', 2), box(8.3, 10.6, 7.3, 8.7, 11.1, 7.45, 'W', 2), box(8.7, 12.4, 7.3, 9.1, 12.9, 7.45, 'W', 2)]
    return e

def chain_link():
    return [box(5.5, 14, 7, 10.5, 16, 9, 'S', 1), box(5.5, 0, 7, 10.5, 2, 9, 'S', 1), box(5.5, 0, 7, 7.5, 16, 9, 'S', 0), box(8.5, 0, 7, 10.5, 16, 9, 'S', 0),
            box(7.4, 7, 7.4, 8.6, 9, 8.6, 'B', 2)]

def model(elements, tex):
    return {'textures': {'0': tex, 'particle': tex}, 'elements': elements,
            'display': {'fixed': {'rotation': [0, 0, 0], 'translation': [0, 0, 0], 'scale': [1, 1, 1]}}}

def write_json(path, obj):
    with open(mk(path), 'w') as f: json.dump(obj, f, indent=1)

def make_models():
    for key, els in (('vorth', vorth()), ('zyrath', zyrath()), ('chain_link', chain_link())):
        for emp in (False, True):
            suffix = '_empowered' if emp else ''
            write_json(os.path.join(NS, 'models', 'item', key + suffix + '.json'), model(els, 'xarvoth:item/palette' + suffix))
            write_json(os.path.join(NS, 'items', key + suffix + '.json'), {'model': {'type': 'minecraft:model', 'model': 'xarvoth:item/' + key + suffix}})
    for emp in (False, True):
        suffix = '_empowered' if emp else ''
        write_json(os.path.join(NS, 'models', 'item', 'weapon' + suffix + '.json'),
                   {'parent': 'minecraft:item/handheld', 'textures': {'layer0': 'xarvoth:item/weapon' + suffix}})
        write_json(os.path.join(NS, 'items', 'weapon' + suffix + '.json'), {'model': {'type': 'minecraft:model', 'model': 'xarvoth:item/weapon' + suffix}})

def make_font_and_meta():
    chars = ''.join(chr(0xE000 + i) for i in range(4)) + ''.join(chr(0xE010 + i) for i in range(5))
    # bitmap providers need one chars row per provider; the sheet is a single row of nine 9x9 cells
    write_json(os.path.join(NS, 'font', 'hud.json'), {'providers': [{'type': 'bitmap', 'file': 'xarvoth:font/hud.png', 'height': 9, 'ascent': 8,
                                                                   'chars': [chr(0xE000) + chr(0xE001) + chr(0xE002) + chr(0xE003) + chr(0xE010) + chr(0xE011) + chr(0xE012) + chr(0xE013) + chr(0xE014)]}]})
    write_json(os.path.join(PACK, 'pack.mcmeta'), {'pack': {'description': '§bXARVOTH §7- The Godrend Chains', 'min_format': [88, 0], 'max_format': [88, 0]}})

if __name__ == '__main__':
    if os.path.isdir(PACK): shutil.rmtree(PACK)
    make_textures(); make_models(); make_font_and_meta()
    print('vfx models:', vfx_pack.build(NS, write_json, vorth(), zyrath()))
    n = render_sounds()
    print('pack built:', n, 'sound events')
